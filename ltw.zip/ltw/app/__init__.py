"""Khởi tạo ứng dụng Flask (Application Factory)."""
import logging
import os
from logging.handlers import RotatingFileHandler

from flask import Flask
from werkzeug.exceptions import HTTPException

from config import Config

from .extensions import cors, db, jwt
from .utils.responses import error, success


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Ưu tiên ghi đè DATABASE_URL từ môi trường nếu có
    if os.getenv("DATABASE_URL"):
        app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")

    # Trả JSON tiếng Việt không bị mã hóa \uXXXX và giữ nguyên thứ tự khóa
    app.json.ensure_ascii = False
    app.json.sort_keys = False

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    jwt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})

    _register_jwt_callbacks()
    _register_blueprints(app)
    _register_error_handlers(app)
    _register_security_headers(app)
    _setup_logging(app)

    @app.get("/")
    def index():
        return success({
            "name": "Library Management Web API",
            "version": "1.0.0",
            "docs": "Xem README.md và docs/API_DOCUMENTATION.md",
            "health": "/api/system/health",
        }, "Web API quản lý hệ thống sách thư viện")

    return app


def _register_blueprints(app):
    from .routes.ai import bp as ai_bp
    from .routes.auth import bp as auth_bp
    from .routes.authors import bp as authors_bp
    from .routes.books import bp as books_bp
    from .routes.borrows import bp as borrows_bp
    from .routes.categories import bp as categories_bp
    from .routes.resources import bp as resources_bp
    from .routes.roles import bp as roles_bp
    from .routes.system import bp as system_bp
    from .routes.users import bp as users_bp

    for bp in (auth_bp, users_bp, roles_bp, categories_bp, authors_bp, books_bp,
               resources_bp, borrows_bp, ai_bp, system_bp):
        app.register_blueprint(bp)


def _register_jwt_callbacks():
    from .models import TokenBlocklist, User

    @jwt.user_lookup_loader
    def load_user(_jwt_header, jwt_data):
        user = db.session.get(User, int(jwt_data["sub"]))
        if user and user.is_active:
            return user
        return None

    @jwt.user_lookup_error_loader
    def user_lookup_error(_jwt_header, _jwt_data):
        return error("Tài khoản không tồn tại hoặc đã bị vô hiệu hóa", 401)

    @jwt.token_in_blocklist_loader
    def is_token_revoked(_jwt_header, jwt_payload):
        return db.session.query(TokenBlocklist.id).filter_by(jti=jwt_payload["jti"]).first() is not None

    @jwt.expired_token_loader
    def expired_token(_jwt_header, _jwt_payload):
        return error("Token đã hết hạn, vui lòng đăng nhập lại hoặc làm mới token", 401)

    @jwt.invalid_token_loader
    def invalid_token(reason):
        return error(f"Token không hợp lệ: {reason}", 401)

    @jwt.unauthorized_loader
    def missing_token(reason):
        return error("Bạn cần đăng nhập để sử dụng chức năng này (thiếu Bearer token)", 401)

    @jwt.revoked_token_loader
    def revoked_token(_jwt_header, _jwt_payload):
        return error("Token đã bị thu hồi (đã đăng xuất)", 401)

    @jwt.needs_fresh_token_loader
    def needs_fresh(_jwt_header, _jwt_payload):
        return error("Yêu cầu token mới, vui lòng đăng nhập lại", 401)


def _register_error_handlers(app):
    messages = {
        400: "Yêu cầu không hợp lệ",
        401: "Chưa xác thực",
        403: "Không có quyền truy cập",
        404: "Không tìm thấy tài nguyên",
        405: "Phương thức không được hỗ trợ",
        413: "Tệp tải lên vượt quá dung lượng cho phép",
        500: "Lỗi máy chủ nội bộ",
    }

    @app.errorhandler(HTTPException)
    def handle_http(e):
        return error(messages.get(e.code, e.name), e.code)

    @app.errorhandler(Exception)
    def handle_exception(e):
        if isinstance(e, HTTPException):
            return handle_http(e)
        db.session.rollback()
        app.logger.exception("Lỗi chưa xử lý: %s", e)
        return error(messages[500], 500)


def _register_security_headers(app):
    @app.after_request
    def add_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Cache-Control", "no-store")
        return response


def _setup_logging(app):
    os.makedirs(app.config["LOG_DIR"], exist_ok=True)
    handler = RotatingFileHandler(
        os.path.join(app.config["LOG_DIR"], "app.log"),
        maxBytes=2 * 1024 * 1024, backupCount=5, encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    handler.setLevel(logging.INFO)
    app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)
