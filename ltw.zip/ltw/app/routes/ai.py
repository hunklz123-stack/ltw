"""Các API tính năng nâng cao tích hợp AI."""
from flask import Blueprint, current_app, request
from flask_jwt_extended import current_user

from ..extensions import db
from ..models import SearchHistory
from ..services import ai_service
from ..utils.audit import log_action
from ..utils.decorators import login_required, staff_required
from ..utils.responses import error, success
from ..utils.validators import get_json_body, to_int

bp = Blueprint("ai", __name__, url_prefix="/api/ai")


@bp.get("/status")
@login_required
def status():
    return success({
        "local_nlp": True,
        "gemini_enabled": ai_service.gemini_available(),
        "gemini_model": current_app.config["GEMINI_MODEL"] if ai_service.gemini_available() else None,
        "features": ["smart-search", "recommendations", "chat", "suggest-category"],
    })


@bp.post("/smart-search")
@login_required
def smart_search():
    """Tìm kiếm sách bằng ngôn ngữ tự nhiên. Body: {"query": "...", "limit": 10}."""
    data = get_json_body()
    query = (data.get("query") or "").strip()
    if not query:
        return error("Vui lòng nhập câu truy vấn (query)")
    if len(query) > 500:
        return error("Câu truy vấn quá dài (tối đa 500 ký tự)")
    limit = min(max(to_int(data.get("limit"), 10), 1), 50)
    db.session.add(SearchHistory(user_id=current_user.id, search_text=query))
    db.session.commit()
    result = ai_service.smart_search(query, limit=limit)
    return success(result, f"Tìm thấy {result['total']} kết quả phù hợp")


@bp.get("/recommendations")
@login_required
def recommendations():
    """Gợi ý sách cá nhân hóa dựa trên lịch sử mượn và lịch sử tìm kiếm."""
    limit = min(max(to_int(request.args.get("limit"), 10), 1), 50)
    return success(ai_service.recommend_books(current_user, limit=limit), "Gợi ý sách cho bạn")


@bp.post("/chat")
@login_required
def chat():
    """Chatbot thư viện. Body: {"message": "..."}."""
    message = (get_json_body().get("message") or "").strip()
    if not message:
        return error("Vui lòng nhập nội dung câu hỏi (message)")
    if len(message) > 1000:
        return error("Câu hỏi quá dài (tối đa 1000 ký tự)")
    result = ai_service.chatbot(message, current_user)
    log_action("AI_CHAT", "AI", None, {"intent": result["intent"], "source": result["source"]})
    return success(result)


@bp.post("/suggest-category")
@staff_required
def suggest_category():
    """Gợi ý thể loại & từ khóa từ tên sách/mô tả. Body: {"title": "...", "description": "..."}."""
    data = get_json_body()
    title = (data.get("title") or "").strip()
    if not title:
        return error("Vui lòng nhập tên sách (title)")
    return success(ai_service.suggest_category(title, data.get("description") or ""),
                   "Gợi ý phân loại sách")
