"""Quản lý tác giả."""
from datetime import datetime

from flask import Blueprint, request

from ..extensions import db
from ..models import Author, Book
from ..utils.audit import log_action
from ..utils.decorators import login_required, staff_required
from ..utils.responses import error, paginated, success
from ..utils.validators import clean_str, get_json_body, require_fields, to_int

bp = Blueprint("authors", __name__, url_prefix="/api/authors")


def _apply(author, data):
    if "name" in data:
        name = clean_str(data["name"], 150)
        if not name:
            return "Tên tác giả không được để trống"
        author.name = name
    if "biography" in data:
        author.biography = clean_str(data["biography"])
    if "nationality" in data:
        author.nationality = clean_str(data["nationality"], 100)
    if "birth_year" in data:
        year = to_int(data["birth_year"])
        if data["birth_year"] not in (None, "") and (year is None or year < 0 or year > datetime.now().year):
            return "Năm sinh không hợp lệ"
        author.birth_year = year
    return None


@bp.get("")
@login_required
def list_authors():
    query = Author.query
    q = request.args.get("q", "").strip()
    if q:
        query = query.filter(Author.name.ilike(f"%{q}%"))
    if request.args.get("nationality"):
        query = query.filter(Author.nationality.ilike(f"%{request.args['nationality']}%"))
    return paginated(query.order_by(Author.name), lambda a: a.to_dict(with_count=True))


@bp.get("/<int:author_id>")
@login_required
def get_author(author_id):
    author = db.session.get(Author, author_id)
    if not author:
        return error("Không tìm thấy tác giả", 404)
    data = author.to_dict(with_count=True)
    data["books"] = [b.to_brief() | {"status": b.status, "available_quantity": b.available_quantity}
                     for b in author.books.order_by(Book.title).all()]
    return success(data)


@bp.post("")
@staff_required
def create_author():
    data = get_json_body()
    missing = require_fields(data, ["name"])
    if missing:
        return error("Thiếu tên tác giả", 400, {"missing_fields": missing})
    author = Author()
    err = _apply(author, data)
    if err:
        return error(err)
    db.session.add(author)
    db.session.commit()
    log_action("CREATE", "Author", author.id, {"name": author.name})
    return success(author.to_dict(), "Thêm tác giả thành công", 201)


@bp.put("/<int:author_id>")
@staff_required
def update_author(author_id):
    author = db.session.get(Author, author_id)
    if not author:
        return error("Không tìm thấy tác giả", 404)
    data = get_json_body()
    err = _apply(author, data)
    if err:
        return error(err)
    db.session.commit()
    log_action("UPDATE", "Author", author.id, data)
    return success(author.to_dict(with_count=True), "Cập nhật tác giả thành công")


@bp.delete("/<int:author_id>")
@staff_required
def delete_author(author_id):
    author = db.session.get(Author, author_id)
    if not author:
        return error("Không tìm thấy tác giả", 404)
    force = request.args.get("force", "false").lower() == "true"
    count = author.books.count()
    if count and not force:
        return error(f"Tác giả đang gắn với {count} đầu sách. Thêm ?force=true để xóa "
                     "(chỉ gỡ liên kết, không xóa sách)", 409)
    name = author.name
    db.session.delete(author)  # bản ghi BookAuthors được xóa tự động
    db.session.commit()
    log_action("DELETE", "Author", author_id, {"name": name})
    return success(message="Xóa tác giả thành công")
