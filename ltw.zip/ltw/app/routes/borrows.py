"""Phiếu mượn - trả sách (chức năng mở rộng - bảng BorrowRecords)."""
from datetime import timedelta

from flask import Blueprint, current_app, request
from flask_jwt_extended import current_user

from ..extensions import db
from ..models import BORROW_STATUSES, Book, BorrowRecord, User, now
from ..utils.audit import log_action
from ..utils.decorators import login_required, staff_required
from ..utils.responses import error, paginated, success
from ..utils.validators import clean_str, get_json_body, require_fields, to_int

bp = Blueprint("borrows", __name__, url_prefix="/api/borrows")


def _filter_status(query, status):
    if status == "overdue":
        return query.filter(BorrowRecord.status == "borrowing", BorrowRecord.due_date < now())
    if status == "borrowing":
        return query.filter(BorrowRecord.status == "borrowing", BorrowRecord.due_date >= now())
    if status in BORROW_STATUSES:
        return query.filter(BorrowRecord.status == status)
    return query


@bp.get("")
@login_required
def list_borrows():
    """Thủ thư/Admin xem tất cả phiếu; sinh viên chỉ xem phiếu của mình."""
    query = BorrowRecord.query
    if current_user.is_staff:
        if to_int(request.args.get("user_id")) is not None:
            query = query.filter(BorrowRecord.user_id == to_int(request.args["user_id"]))
    else:
        query = query.filter(BorrowRecord.user_id == current_user.id)
    if to_int(request.args.get("book_id")) is not None:
        query = query.filter(BorrowRecord.book_id == to_int(request.args["book_id"]))
    query = _filter_status(query, request.args.get("status"))
    return paginated(query.order_by(BorrowRecord.borrow_date.desc(), BorrowRecord.id.desc()),
                     lambda r: r.to_dict())


@bp.get("/my")
@login_required
def my_borrows():
    query = _filter_status(BorrowRecord.query.filter(BorrowRecord.user_id == current_user.id),
                           request.args.get("status"))
    return paginated(query.order_by(BorrowRecord.borrow_date.desc(), BorrowRecord.id.desc()),
                     lambda r: r.to_dict())


@bp.get("/overdue")
@staff_required
def overdue():
    query = _filter_status(BorrowRecord.query, "overdue").order_by(BorrowRecord.due_date, BorrowRecord.id)
    return paginated(query, lambda r: r.to_dict())


@bp.get("/<int:record_id>")
@login_required
def get_borrow(record_id):
    record = db.session.get(BorrowRecord, record_id)
    if not record or (not current_user.is_staff and record.user_id != current_user.id):
        return error("Không tìm thấy phiếu mượn", 404)
    return success(record.to_dict())


@bp.post("")
@staff_required
def create_borrow():
    """Lập phiếu mượn. Body: user_id, book_id, days (tùy chọn), note."""
    data = get_json_body()
    missing = require_fields(data, ["user_id", "book_id"])
    if missing:
        return error("Thiếu thông tin bắt buộc", 400, {"missing_fields": missing})
    user = db.session.get(User, to_int(data["user_id"]))
    if not user or not user.is_active:
        return error("Người mượn không tồn tại hoặc đã bị vô hiệu hóa", 404)
    book = db.session.get(Book, to_int(data["book_id"]))
    if not book:
        return error("Không tìm thấy sách", 404)
    if book.status == "discontinued":
        return error("Sách đã ngừng lưu hành")
    if book.available_quantity <= 0:
        return error("Sách đã hết, không còn bản nào để cho mượn", 409)

    active = BorrowRecord.query.filter(BorrowRecord.user_id == user.id, BorrowRecord.status == "borrowing")
    if active.filter(BorrowRecord.due_date < now()).count() > 0:
        return error("Người dùng đang có sách quá hạn chưa trả, không thể mượn thêm", 409)
    max_books = current_app.config["MAX_BORROW_BOOKS"]
    if active.count() >= max_books:
        return error(f"Người dùng đã mượn tối đa {max_books} cuốn", 409)
    if active.filter(BorrowRecord.book_id == book.id).count() > 0:
        return error("Người dùng đang mượn cuốn sách này", 409)

    days = to_int(data.get("days"), current_app.config["BORROW_DAYS"])
    if days <= 0 or days > 90:
        return error("Số ngày mượn phải từ 1 đến 90")
    record = BorrowRecord(user_id=user.id, book_id=book.id, borrow_date=now(),
                          due_date=now() + timedelta(days=days), status="borrowing",
                          note=clean_str(data.get("note"), 500), processed_by=current_user.id)
    book.available_quantity -= 1
    book.refresh_status()
    db.session.add(record)
    db.session.commit()
    log_action("BORROW", "BorrowRecord", record.id, {"user_id": user.id, "book_id": book.id})
    return success(record.to_dict(), "Lập phiếu mượn thành công", 201)


@bp.put("/<int:record_id>/return")
@staff_required
def return_book(record_id):
    """Trả sách. Body (tùy chọn): condition (tình trạng sách khi trả), lost (true nếu mất sách), note."""
    record = db.session.get(BorrowRecord, record_id)
    if not record:
        return error("Không tìm thấy phiếu mượn", 404)
    if record.status != "borrowing":
        return error("Phiếu mượn này đã được xử lý trả/mất trước đó", 409)
    data = get_json_body()
    book = record.book
    was_overdue = record.is_overdue
    record.return_date = now()
    if data.get("lost") is True:
        record.status = "lost"
        book.quantity = max(book.quantity - 1, 0)  # mất sách: giảm tổng số bản
    else:
        record.status = "returned"
        book.available_quantity = min(book.available_quantity + 1, book.quantity)
        if data.get("condition") in ("new", "good", "worn", "damaged"):
            book.condition = data["condition"]
    if data.get("note"):
        record.note = clean_str(((record.note or "") + " | " + data["note"]).strip(" |"), 500)
    book.refresh_status()
    db.session.commit()
    log_action("RETURN", "BorrowRecord", record.id, {"status": record.status, "was_overdue": was_overdue})
    message = "Ghi nhận mất sách thành công" if record.status == "lost" else "Trả sách thành công"
    if was_overdue:
        message += " (phiếu đã quá hạn)"
    return success(record.to_dict(), message)


@bp.put("/<int:record_id>/extend")
@staff_required
def extend(record_id):
    """Gia hạn phiếu mượn. Body: days (mặc định = BORROW_DAYS)."""
    record = db.session.get(BorrowRecord, record_id)
    if not record:
        return error("Không tìm thấy phiếu mượn", 404)
    if record.status != "borrowing":
        return error("Chỉ gia hạn được phiếu đang mượn", 409)
    if record.is_overdue:
        return error("Phiếu đã quá hạn, không thể gia hạn", 409)
    max_ext = current_app.config["MAX_EXTEND_TIMES"]
    if record.extend_count >= max_ext:
        return error(f"Đã gia hạn tối đa {max_ext} lần", 409)
    days = to_int(get_json_body().get("days"), current_app.config["BORROW_DAYS"])
    if days <= 0 or days > 30:
        return error("Số ngày gia hạn phải từ 1 đến 30")
    record.due_date = record.due_date + timedelta(days=days)
    record.extend_count += 1
    db.session.commit()
    log_action("EXTEND", "BorrowRecord", record.id, {"days": days})
    return success(record.to_dict(), "Gia hạn thành công")
