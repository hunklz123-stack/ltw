"""Quản lý sách: thêm, sửa, xóa, tìm kiếm, số lượng, tình trạng, thống kê kho (M09)."""
from datetime import datetime

from flask import Blueprint, request
from flask_jwt_extended import current_user
from sqlalchemy import func, or_

from ..extensions import db
from ..models import (BOOK_CONDITIONS, BOOK_STATUSES, Author, Book, BorrowRecord, Category,
                      Resource, SearchHistory)
from ..utils.audit import log_action
from ..utils.decorators import login_required, staff_required
from ..utils.responses import error, paginated, success
from ..utils.validators import clean_str, get_json_body, parse_bool, require_fields, to_int

bp = Blueprint("books", __name__, url_prefix="/api/books")

SORT_FIELDS = {
    "title": Book.title,
    "publish_year": Book.publish_year,
    "created_at": Book.created_at,
    "quantity": Book.quantity,
    "available_quantity": Book.available_quantity,
    "id": Book.id,
}


def _resolve_authors(data):
    """Nhận author_ids (danh sách id) và/hoặc authors (danh sách tên - tự tạo nếu chưa có)."""
    authors = []
    ids = data.get("author_ids")
    if ids is not None:
        if not isinstance(ids, list):
            return None, "author_ids phải là một danh sách"
        ids = [to_int(i) for i in ids]
        found = Author.query.filter(Author.id.in_(ids)).all() if ids else []
        missing = set(ids) - {a.id for a in found}
        if missing:
            return None, f"Không tìm thấy tác giả có id: {sorted(i for i in missing if i is not None)}"
        authors.extend(found)
    names = data.get("authors")
    if names is not None:
        if not isinstance(names, list):
            return None, "authors phải là một danh sách tên tác giả"
        for name in names:
            name = clean_str(name, 150)
            if not name:
                continue
            author = Author.query.filter(Author.name == name).first()
            if not author:
                author = Author(name=name)
                db.session.add(author)
            if author not in authors:
                authors.append(author)
    return authors, None


def _apply_fields(book, data, is_create=False):
    """Gán & kiểm tra dữ liệu sách. Trả về thông báo lỗi hoặc None."""
    if "isbn" in data:
        isbn = clean_str(data["isbn"], 20)
        if not isbn:
            return "ISBN không được để trống"
        exists = Book.query.filter(Book.isbn == isbn)
        if book.id:
            exists = exists.filter(Book.id != book.id)
        if exists.first():
            return "ISBN đã tồn tại"
        book.isbn = isbn
    if "title" in data:
        title = clean_str(data["title"], 255)
        if not title:
            return "Tên sách không được để trống"
        book.title = title
    for field, max_len in (("description", None), ("publisher", 150), ("language", 50),
                           ("location", 50), ("cover_image", 500)):
        if field in data:
            setattr(book, field, clean_str(data[field], max_len))
    if "keywords" in data:
        kw = data["keywords"]
        if isinstance(kw, list):
            kw = ", ".join(str(k).strip() for k in kw if str(k).strip())
        book.keywords = clean_str(kw, 500)
    if "publish_year" in data:
        year = to_int(data["publish_year"])
        if data["publish_year"] not in (None, "") and (year is None or year < 0 or year > datetime.now().year + 1):
            return "Năm xuất bản không hợp lệ"
        book.publish_year = year
    if "pages" in data:
        pages = to_int(data["pages"])
        if data["pages"] not in (None, "") and (pages is None or pages <= 0):
            return "Số trang không hợp lệ"
        book.pages = pages
    if "category_id" in data:
        cid = to_int(data["category_id"])
        if cid is not None and not db.session.get(Category, cid):
            return "Thể loại không tồn tại"
        book.category_id = cid
    if "condition" in data:
        if data["condition"] not in BOOK_CONDITIONS:
            return f"Tình trạng sách phải thuộc: {', '.join(BOOK_CONDITIONS)}"
        book.condition = data["condition"]
    if "status" in data:
        if data["status"] not in BOOK_STATUSES:
            return f"Trạng thái phải thuộc: {', '.join(BOOK_STATUSES)}"
        book.status = data["status"]
    if "quantity" in data:
        qty = to_int(data["quantity"])
        if qty is None or qty < 0:
            return "Số lượng phải là số nguyên không âm"
        borrowed = 0 if is_create else book.borrowed_quantity
        if qty < borrowed:
            return f"Số lượng mới ({qty}) nhỏ hơn số sách đang được mượn ({borrowed})"
        book.quantity = qty
        book.available_quantity = qty - borrowed
    if "authors" in data or "author_ids" in data:
        authors, err = _resolve_authors(data)
        if err:
            return err
        book.authors = authors
    return None


def _visible_resources(book):
    query = book.resources
    if not current_user.is_staff:
        query = query.filter(Resource.access_level == "public")
    return [r.to_dict() for r in query.order_by(Resource.id).all()]


# ------------------------------------------------------------------ Tra cứu
@bp.get("")
@login_required
def list_books():
    """Tìm kiếm sách theo tên, tác giả, thể loại và nhiều tiêu chí khác."""
    args = request.args
    query = Book.query

    q = args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        query = query.filter(or_(
            Book.title.ilike(like), Book.isbn.ilike(like), Book.keywords.ilike(like),
            Book.publisher.ilike(like), Book.description.ilike(like),
            Book.authors.any(Author.name.ilike(like)),
            Book.category.has(Category.name.ilike(like)),
        ))
    if args.get("title"):
        query = query.filter(Book.title.ilike(f"%{args['title'].strip()}%"))
    if args.get("isbn"):
        query = query.filter(Book.isbn == args["isbn"].strip())
    if args.get("author"):
        query = query.filter(Book.authors.any(Author.name.ilike(f"%{args['author'].strip()}%")))
    if to_int(args.get("author_id")) is not None:
        query = query.filter(Book.authors.any(Author.id == to_int(args["author_id"])))
    if to_int(args.get("category_id")) is not None:
        query = query.filter(Book.category_id == to_int(args["category_id"]))
    if args.get("category"):
        query = query.filter(Book.category.has(Category.name.ilike(f"%{args['category'].strip()}%")))
    if args.get("publisher"):
        query = query.filter(Book.publisher.ilike(f"%{args['publisher'].strip()}%"))
    if args.get("language"):
        query = query.filter(Book.language.ilike(f"%{args['language'].strip()}%"))
    if to_int(args.get("year_from")) is not None:
        query = query.filter(Book.publish_year >= to_int(args["year_from"]))
    if to_int(args.get("year_to")) is not None:
        query = query.filter(Book.publish_year <= to_int(args["year_to"]))
    if args.get("status") in BOOK_STATUSES:
        query = query.filter(Book.status == args["status"])
    if args.get("condition") in BOOK_CONDITIONS:
        query = query.filter(Book.condition == args["condition"])
    if parse_bool(args.get("available")):
        query = query.filter(Book.available_quantity > 0, Book.status != "discontinued")

    sort = args.get("sort", "-id")
    desc = sort.startswith("-")
    column = SORT_FIELDS.get(sort.lstrip("-"), Book.id)
    query = query.order_by(column.desc() if desc else column.asc(), Book.id.desc())

    # Lưu lịch sử tìm kiếm phục vụ gợi ý cá nhân hóa
    keyword = q or args.get("title") or args.get("author") or args.get("category")
    if keyword:
        db.session.add(SearchHistory(user_id=current_user.id, search_text=keyword[:500]))
        db.session.commit()

    return paginated(query, lambda b: b.to_dict())


@bp.get("/<int:book_id>")
@login_required
def get_book(book_id):
    book = db.session.get(Book, book_id)
    if not book:
        return error("Không tìm thấy sách", 404)
    data = book.to_dict()
    data["resources"] = _visible_resources(book)
    data["total_borrows"] = book.borrow_records.count()
    return success(data)


@bp.get("/isbn/<string:isbn>")
@login_required
def get_book_by_isbn(isbn):
    book = Book.query.filter(Book.isbn == isbn.strip()).first()
    if not book:
        return error("Không tìm thấy sách với ISBN này", 404)
    return success(book.to_dict())


@bp.get("/statistics")
@staff_required
def statistics():
    """Thống kê kho sách (quản lý tài sản thư viện)."""
    totals = db.session.query(
        func.count(Book.id), func.coalesce(func.sum(Book.quantity), 0),
        func.coalesce(func.sum(Book.available_quantity), 0),
    ).one()
    by_category = db.session.query(
        Category.name, func.count(Book.id), func.coalesce(func.sum(Book.quantity), 0)
    ).outerjoin(Book, Book.category_id == Category.id).group_by(Category.name).order_by(Category.name).all()
    uncategorized = Book.query.filter(Book.category_id.is_(None)).count()
    by_status = db.session.query(Book.status, func.count(Book.id)).group_by(Book.status).all()
    by_condition = db.session.query(Book.condition, func.count(Book.id)).group_by(Book.condition).all()
    low_stock = Book.query.filter(Book.available_quantity <= 1, Book.status != "discontinued") \
        .order_by(Book.available_quantity, Book.title).limit(20).all()
    top_rows = db.session.query(BorrowRecord.book_id, func.count(BorrowRecord.id)) \
        .group_by(BorrowRecord.book_id).order_by(func.count(BorrowRecord.id).desc()).limit(10).all()
    top_map = {b.id: b for b in Book.query.filter(Book.id.in_([r[0] for r in top_rows])).all()} \
        if top_rows else {}
    top_borrowed = [(top_map[bid], cnt) for bid, cnt in top_rows if bid in top_map]

    return success({
        "total_titles": totals[0],
        "total_copies": int(totals[1]),
        "available_copies": int(totals[2]),
        "borrowed_copies": int(totals[1]) - int(totals[2]),
        "by_category": [{"category": n, "titles": c, "copies": int(q)} for n, c, q in by_category]
                       + ([{"category": "(Chưa phân loại)", "titles": uncategorized}] if uncategorized else []),
        "by_status": {s: c for s, c in by_status},
        "by_condition": {s: c for s, c in by_condition},
        "low_stock": [b.to_brief() | {"available_quantity": b.available_quantity, "quantity": b.quantity}
                      for b in low_stock],
        "top_borrowed": [b.to_brief() | {"borrow_count": cnt} for b, cnt in top_borrowed],
    })


# ------------------------------------------------------------------ Cập nhật
@bp.post("")
@staff_required
def create_book():
    data = get_json_body()
    missing = require_fields(data, ["isbn", "title"])
    if missing:
        return error("Thiếu thông tin bắt buộc", 400, {"missing_fields": missing})
    data.setdefault("quantity", 0)
    book = Book(created_by=current_user.id, language="Tiếng Việt")
    err = _apply_fields(book, data, is_create=True)
    if err:
        db.session.rollback()
        return error(err)
    book.refresh_status()
    db.session.add(book)
    db.session.commit()
    log_action("CREATE", "Book", book.id, {"isbn": book.isbn, "title": book.title})
    return success(book.to_dict(), "Thêm sách thành công", 201)


@bp.put("/<int:book_id>")
@staff_required
def update_book(book_id):
    book = db.session.get(Book, book_id)
    if not book:
        return error("Không tìm thấy sách", 404)
    data = get_json_body()
    if "available_quantity" in data:
        return error("Không sửa trực tiếp available_quantity; hãy cập nhật quantity hoặc dùng phiếu mượn/trả")
    err = _apply_fields(book, data)
    if err:
        db.session.rollback()
        return error(err)
    book.refresh_status()
    db.session.commit()
    log_action("UPDATE", "Book", book.id, data)
    return success(book.to_dict(), "Cập nhật sách thành công")


@bp.patch("/<int:book_id>/quantity")
@staff_required
def update_quantity(book_id):
    """Nhập thêm / thanh lý bản sách. Body: {"quantity": 10} hoặc {"change": +3 / -2}."""
    book = db.session.get(Book, book_id)
    if not book:
        return error("Không tìm thấy sách", 404)
    data = get_json_body()
    if "change" in data:
        change = to_int(data["change"])
        if change is None:
            return error("change phải là số nguyên")
        new_qty = book.quantity + change
    elif "quantity" in data:
        new_qty = to_int(data["quantity"])
        if new_qty is None:
            return error("quantity phải là số nguyên")
    else:
        return error("Truyền quantity (số lượng mới) hoặc change (số lượng tăng/giảm)")
    if new_qty < 0:
        return error("Số lượng không được âm")
    borrowed = book.borrowed_quantity
    if new_qty < borrowed:
        return error(f"Số lượng mới ({new_qty}) nhỏ hơn số sách đang được mượn ({borrowed})")
    old_qty = book.quantity
    book.quantity = new_qty
    book.available_quantity = new_qty - borrowed
    book.refresh_status()
    db.session.commit()
    log_action("UPDATE_QUANTITY", "Book", book.id,
               {"from": old_qty, "to": new_qty, "reason": data.get("reason")})
    return success(book.to_dict(), "Cập nhật số lượng sách thành công")


@bp.patch("/<int:book_id>/status")
@staff_required
def update_status(book_id):
    """Cập nhật trạng thái lưu hành và/hoặc tình trạng vật lý của sách."""
    book = db.session.get(Book, book_id)
    if not book:
        return error("Không tìm thấy sách", 404)
    data = get_json_body()
    if "status" not in data and "condition" not in data:
        return error("Truyền status và/hoặc condition")
    if "status" in data:
        if data["status"] not in BOOK_STATUSES:
            return error(f"Trạng thái phải thuộc: {', '.join(BOOK_STATUSES)}")
        book.status = data["status"]
        if book.status != "discontinued":
            book.refresh_status()
    if "condition" in data:
        if data["condition"] not in BOOK_CONDITIONS:
            return error(f"Tình trạng phải thuộc: {', '.join(BOOK_CONDITIONS)}")
        book.condition = data["condition"]
    db.session.commit()
    log_action("UPDATE_STATUS", "Book", book.id, data)
    return success(book.to_dict(), "Cập nhật trạng thái sách thành công")


@bp.delete("/<int:book_id>")
@staff_required
def delete_book(book_id):
    book = db.session.get(Book, book_id)
    if not book:
        return error("Không tìm thấy sách", 404)
    if book.borrow_records.count() > 0:
        return error("Sách đã có lịch sử mượn - trả, không thể xóa. Hãy chuyển trạng thái "
                     "'discontinued' (ngừng lưu hành) thay vì xóa", 409)
    Resource.query.filter(Resource.book_id == book_id).update({Resource.book_id: None})
    info = {"isbn": book.isbn, "title": book.title}
    db.session.delete(book)
    db.session.commit()
    log_action("DELETE", "Book", book_id, info)
    return success(message="Xóa sách thành công")
