"""Quản lý thể loại sách."""
from flask import Blueprint, request

from ..extensions import db
from ..models import Book, Category, Resource
from ..utils.audit import log_action
from ..utils.decorators import login_required, staff_required
from ..utils.responses import error, paginated, success
from ..utils.validators import clean_str, get_json_body, require_fields

bp = Blueprint("categories", __name__, url_prefix="/api/categories")


@bp.get("")
@login_required
def list_categories():
    query = Category.query
    q = request.args.get("q", "").strip()
    if q:
        query = query.filter(Category.name.ilike(f"%{q}%"))
    return paginated(query.order_by(Category.name), lambda c: c.to_dict(with_count=True))


@bp.get("/<int:category_id>")
@login_required
def get_category(category_id):
    category = db.session.get(Category, category_id)
    if not category:
        return error("Không tìm thấy thể loại", 404)
    return success(category.to_dict(with_count=True))


@bp.get("/<int:category_id>/books")
@login_required
def category_books(category_id):
    category = db.session.get(Category, category_id)
    if not category:
        return error("Không tìm thấy thể loại", 404)
    query = Book.query.filter(Book.category_id == category_id).order_by(Book.title)
    return paginated(query, lambda b: b.to_dict())


@bp.post("")
@staff_required
def create_category():
    data = get_json_body()
    missing = require_fields(data, ["name"])
    if missing:
        return error("Thiếu tên thể loại", 400, {"missing_fields": missing})
    name = clean_str(data["name"], 100)
    if Category.query.filter(Category.name == name).first():
        return error("Thể loại đã tồn tại", 409)
    category = Category(name=name, description=clean_str(data.get("description")))
    db.session.add(category)
    db.session.commit()
    log_action("CREATE", "Category", category.id, {"name": name})
    return success(category.to_dict(), "Thêm thể loại thành công", 201)


@bp.put("/<int:category_id>")
@staff_required
def update_category(category_id):
    category = db.session.get(Category, category_id)
    if not category:
        return error("Không tìm thấy thể loại", 404)
    data = get_json_body()
    if "name" in data:
        name = clean_str(data["name"], 100)
        if not name:
            return error("Tên thể loại không được để trống")
        if Category.query.filter(Category.name == name, Category.id != category_id).first():
            return error("Tên thể loại đã tồn tại", 409)
        category.name = name
    if "description" in data:
        category.description = clean_str(data["description"])
    db.session.commit()
    log_action("UPDATE", "Category", category.id, data)
    return success(category.to_dict(with_count=True), "Cập nhật thể loại thành công")


@bp.delete("/<int:category_id>")
@staff_required
def delete_category(category_id):
    category = db.session.get(Category, category_id)
    if not category:
        return error("Không tìm thấy thể loại", 404)
    force = request.args.get("force", "false").lower() == "true"
    book_count = category.books.count()
    if book_count and not force:
        return error(f"Thể loại đang có {book_count} đầu sách. Thêm ?force=true để xóa và "
                     "bỏ liên kết thể loại khỏi các sách này", 409)
    # Bỏ liên kết thay vì xóa dây chuyền
    Book.query.filter(Book.category_id == category_id).update({Book.category_id: None})
    Resource.query.filter(Resource.category_id == category_id).update({Resource.category_id: None})
    name = category.name
    db.session.delete(category)
    db.session.commit()
    log_action("DELETE", "Category", category_id, {"name": name})
    return success(message="Xóa thể loại thành công")
