"""Quản lý tài khoản người dùng - chỉ Quản trị viên (M20)."""
import secrets

from flask import Blueprint, request
from flask_jwt_extended import current_user
from sqlalchemy import or_

from ..extensions import db
from ..models import Role, User
from ..utils.audit import log_action
from ..utils.decorators import admin_required
from ..utils.responses import error, paginated, success
from ..utils.validators import (PHONE_RE, USERNAME_RE, clean_str, get_json_body, is_valid_email,
                                parse_bool, require_fields, validate_password)

bp = Blueprint("users", __name__, url_prefix="/api/users")


def _find_role(data):
    """Cho phép truyền role_id hoặc role (tên vai trò)."""
    if data.get("role_id") is not None:
        return db.session.get(Role, data.get("role_id"))
    if data.get("role"):
        return Role.query.filter_by(name=str(data["role"]).strip()).first()
    return None


@bp.get("")
@admin_required
def list_users():
    query = User.query.join(Role)
    q = request.args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        query = query.filter(or_(User.username.ilike(like), User.full_name.ilike(like),
                                 User.email.ilike(like), User.student_code.ilike(like)))
    if request.args.get("role"):
        query = query.filter(Role.name == request.args["role"])
    is_active = parse_bool(request.args.get("is_active"))
    if is_active is not None:
        query = query.filter(User.is_active == is_active)
    return paginated(query.order_by(User.id.desc()), lambda u: u.to_dict())


@bp.get("/<int:user_id>")
@admin_required
def get_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return error("Không tìm thấy người dùng", 404)
    data = user.to_dict()
    data["borrow_count"] = user.borrow_records.count()
    return success(data)


@bp.post("")
@admin_required
def create_user():
    data = get_json_body()
    missing = require_fields(data, ["username", "password", "full_name", "email"])
    if missing:
        return error("Thiếu thông tin bắt buộc", 400, {"missing_fields": missing})
    username = data["username"].strip()
    email = data["email"].strip().lower()
    phone = clean_str(data.get("phone"), 20)
    if not USERNAME_RE.match(username):
        return error("Tên đăng nhập chỉ gồm chữ, số, dấu '_' hoặc '.', dài 3-50 ký tự")
    if not is_valid_email(email):
        return error("Email không hợp lệ")
    if phone and not PHONE_RE.match(phone):
        return error("Số điện thoại không hợp lệ")
    pw_error = validate_password(data["password"])
    if pw_error:
        return error(pw_error)
    if User.query.filter_by(username=username).first():
        return error("Tên đăng nhập đã tồn tại", 409)
    if User.query.filter_by(email=email).first():
        return error("Email đã được sử dụng", 409)
    role = _find_role(data) or Role.query.filter_by(name="Student").first()
    if not role:
        return error("Vai trò không hợp lệ")

    user = User(username=username, full_name=clean_str(data["full_name"], 100), email=email,
                phone=phone, student_code=clean_str(data.get("student_code"), 20), role=role,
                is_active=parse_bool(data.get("is_active"), True))
    user.set_password(data["password"])
    db.session.add(user)
    db.session.commit()
    log_action("CREATE", "User", user.id, {"username": username, "role": role.name})
    return success(user.to_dict(), "Tạo tài khoản thành công", 201)


@bp.put("/<int:user_id>")
@admin_required
def update_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return error("Không tìm thấy người dùng", 404)
    data = get_json_body()

    if "full_name" in data:
        name = clean_str(data["full_name"], 100)
        if not name:
            return error("Họ tên không được để trống")
        user.full_name = name
    if "email" in data:
        email = (data["email"] or "").strip().lower()
        if not is_valid_email(email):
            return error("Email không hợp lệ")
        if User.query.filter(User.email == email, User.id != user.id).first():
            return error("Email đã được sử dụng", 409)
        user.email = email
    if "phone" in data:
        phone = clean_str(data["phone"], 20)
        if phone and not PHONE_RE.match(phone):
            return error("Số điện thoại không hợp lệ")
        user.phone = phone
    if "student_code" in data:
        user.student_code = clean_str(data["student_code"], 20)
    if "role_id" in data or "role" in data:
        role = _find_role(data)
        if not role:
            return error("Vai trò không hợp lệ")
        if user.id == current_user.id and role.name != user.role_name:
            return error("Không thể tự thay đổi vai trò của chính mình")
        user.role = role
    if "is_active" in data:
        active = parse_bool(data["is_active"], True)
        if user.id == current_user.id and not active:
            return error("Không thể tự vô hiệu hóa tài khoản của chính mình")
        user.is_active = active
    db.session.commit()
    log_action("UPDATE", "User", user.id, {k: v for k, v in data.items() if k != "password"})
    return success(user.to_dict(), "Cập nhật tài khoản thành công")


@bp.patch("/<int:user_id>/role")
@admin_required
def change_role(user_id):
    """Phân quyền: gán vai trò cho người dùng."""
    user = db.session.get(User, user_id)
    if not user:
        return error("Không tìm thấy người dùng", 404)
    role = _find_role(get_json_body())
    if not role:
        return error("Vai trò không hợp lệ (truyền role_id hoặc role: Admin/Librarian/Student)")
    if user.id == current_user.id:
        return error("Không thể tự thay đổi vai trò của chính mình")
    old = user.role_name
    user.role = role
    db.session.commit()
    log_action("CHANGE_ROLE", "User", user.id, {"from": old, "to": role.name})
    return success(user.to_dict(), f"Đã phân quyền '{role.display_name or role.name}' cho người dùng")


@bp.patch("/<int:user_id>/status")
@admin_required
def change_status(user_id):
    """Kích hoạt / vô hiệu hóa tài khoản, mở khóa tài khoản bị khóa do đăng nhập sai."""
    user = db.session.get(User, user_id)
    if not user:
        return error("Không tìm thấy người dùng", 404)
    data = get_json_body()
    if "is_active" not in data and not data.get("unlock"):
        return error("Truyền is_active (true/false) hoặc unlock: true")
    if "is_active" in data:
        active = parse_bool(data["is_active"], True)
        if user.id == current_user.id and not active:
            return error("Không thể tự vô hiệu hóa tài khoản của chính mình")
        user.is_active = active
    if parse_bool(data.get("unlock"), False):
        user.locked_until = None
        user.failed_login_attempts = 0
    db.session.commit()
    log_action("CHANGE_STATUS", "User", user.id, data)
    return success(user.to_dict(), "Cập nhật trạng thái tài khoản thành công")


@bp.post("/<int:user_id>/reset-password")
@admin_required
def reset_password(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return error("Không tìm thấy người dùng", 404)
    new_password = get_json_body().get("new_password")
    if new_password:
        pw_error = validate_password(new_password)
        if pw_error:
            return error(pw_error)
    else:
        new_password = "Lib" + secrets.token_hex(4) + "9"
    user.set_password(new_password)
    user.failed_login_attempts = 0
    user.locked_until = None
    db.session.commit()
    log_action("RESET_PASSWORD", "User", user.id)
    return success({"user_id": user.id, "new_password": new_password}, "Đặt lại mật khẩu thành công")


@bp.delete("/<int:user_id>")
@admin_required
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return error("Không tìm thấy người dùng", 404)
    if user.id == current_user.id:
        return error("Không thể tự xóa tài khoản của chính mình")
    if user.borrow_records.count() > 0:
        return error("Người dùng đã có lịch sử mượn sách, không thể xóa. "
                     "Hãy vô hiệu hóa tài khoản (PATCH /status) thay vì xóa", 409)
    username = user.username
    db.session.delete(user)
    db.session.commit()
    log_action("DELETE", "User", user_id, {"username": username})
    return success(message="Xóa tài khoản thành công")
