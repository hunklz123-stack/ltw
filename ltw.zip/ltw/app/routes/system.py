"""Bảo mật, sao lưu, vận hành & giám sát hệ thống (M21) - Quản trị viên."""
import json
import os
import re
from datetime import datetime, timedelta

from flask import Blueprint, Response, current_app, request
from sqlalchemy import func, text

from ..extensions import db
from ..models import (AuditLog, Author, Book, BorrowRecord, Category, Resource, Role, TokenBlocklist,
                      User, now)
from ..utils.audit import log_action
from ..utils.decorators import admin_required
from ..utils.responses import error, paginated, success
from ..utils.validators import parse_date, to_int

bp = Blueprint("system", __name__, url_prefix="/api/system")


@bp.get("/health")
def health():
    """Kiểm tra tình trạng hoạt động (không cần đăng nhập)."""
    try:
        db.session.execute(text("SELECT 1"))
        db_status = "ok"
    except Exception as exc:
        db.session.rollback()
        current_app.logger.error("Health check DB lỗi: %s", exc)
        db_status = "error"
    status = 200 if db_status == "ok" else 503
    return success({"status": "ok" if status == 200 else "degraded", "database": db_status,
                    "dialect": db.engine.dialect.name, "time": now().isoformat(timespec="seconds")},
                   "Hệ thống đang hoạt động" if status == 200 else "Không kết nối được CSDL", status)


@bp.get("/dashboard")
@admin_required
def dashboard():
    users_by_role = db.session.query(Role.name, func.count(User.id)) \
        .outerjoin(User, User.role_id == Role.id).group_by(Role.name).all()
    copies = db.session.query(func.coalesce(func.sum(Book.quantity), 0),
                              func.coalesce(func.sum(Book.available_quantity), 0)).one()
    since = now() - timedelta(days=7)
    activity = db.session.query(AuditLog.action, func.count(AuditLog.id)) \
        .filter(AuditLog.created_at >= since).group_by(AuditLog.action).all()
    return success({
        "users": {"total": User.query.count(), "active": User.query.filter_by(is_active=True).count(),
                  "locked": User.query.filter(User.locked_until > now()).count(),
                  "by_role": {r: c for r, c in users_by_role}},
        "books": {"titles": Book.query.count(), "copies": int(copies[0]), "available": int(copies[1]),
                  "categories": Category.query.count(), "authors": Author.query.count()},
        "resources": {"total": Resource.query.count(),
                      "downloads": int(db.session.query(func.coalesce(func.sum(Resource.download_count), 0)).scalar())},
        "borrows": {
            "borrowing": BorrowRecord.query.filter_by(status="borrowing").count(),
            "overdue": BorrowRecord.query.filter(BorrowRecord.status == "borrowing",
                                                 BorrowRecord.due_date < now()).count(),
            "returned": BorrowRecord.query.filter_by(status="returned").count(),
        },
        "activity_last_7_days": {a: c for a, c in activity},
        "failed_logins_last_7_days": AuditLog.query.filter(AuditLog.action == "LOGIN_FAILED",
                                                           AuditLog.created_at >= since).count(),
    })


@bp.get("/audit-logs")
@admin_required
def audit_logs():
    """Nhật ký hoạt động. Lọc: user_id, username, action, entity, from, to (YYYY-MM-DD)."""
    args = request.args
    query = AuditLog.query
    if to_int(args.get("user_id")) is not None:
        query = query.filter(AuditLog.user_id == to_int(args["user_id"]))
    if args.get("username"):
        query = query.filter(AuditLog.username.ilike(f"%{args['username']}%"))
    if args.get("action"):
        query = query.filter(AuditLog.action == args["action"].upper())
    if args.get("entity"):
        query = query.filter(AuditLog.entity == args["entity"])
    date_from, date_to = parse_date(args.get("from")), parse_date(args.get("to"))
    if date_from:
        query = query.filter(AuditLog.created_at >= date_from)
    if date_to:
        query = query.filter(AuditLog.created_at < date_to + timedelta(days=1))
    return paginated(query.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()), lambda l: l.to_dict())


@bp.post("/backup")
@admin_required
def backup_database():
    """Sao lưu toàn bộ CSDL SQL Server ra tệp .bak (BACKUP DATABASE)."""
    if db.engine.dialect.name != "mssql":
        return error("Sao lưu .bak chỉ hỗ trợ Microsoft SQL Server. Dùng GET /api/system/export để xuất JSON")
    db_name = db.session.execute(text("SELECT DB_NAME()")).scalar()
    db.session.commit()
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", db_name or ""):
        return error("Tên CSDL không hợp lệ để sao lưu", 500)
    backup_dir = current_app.config["BACKUP_DIR"].rstrip("\\/")
    if "'" in backup_dir:
        return error("Đường dẫn BACKUP_DIR không hợp lệ", 500)
    sep = "/" if "/" in backup_dir else "\\"
    file_path = f"{backup_dir}{sep}{db_name}_{datetime.now():%Y%m%d_%H%M%S}.bak"

    raw = db.engine.raw_connection()
    driver_conn = raw.driver_connection
    try:
        driver_conn.autocommit = True  # BACKUP không chạy được trong transaction
        cursor = driver_conn.cursor()
        cursor.execute(f"BACKUP DATABASE [{db_name}] TO DISK = N'{file_path}' "
                       f"WITH INIT, NAME = N'{db_name} full backup'")
        while cursor.nextset():  # đọc hết thông điệp để chắc chắn backup hoàn tất
            pass
        cursor.close()
    except Exception as exc:
        current_app.logger.exception("Sao lưu thất bại")
        log_action("BACKUP_FAILED", "System", None, {"file": file_path, "error": str(exc)[:500]})
        return error(f"Sao lưu thất bại: {exc}. Kiểm tra thư mục BACKUP_DIR tồn tại trên máy SQL Server "
                     "và tài khoản dịch vụ SQL Server có quyền ghi", 500)
    finally:
        driver_conn.autocommit = False
        raw.close()

    log_action("BACKUP", "System", None, {"file": file_path})
    return success({"file": file_path, "database": db_name, "created_at": now().isoformat(timespec="seconds")},
                   "Sao lưu cơ sở dữ liệu thành công", 201)


@bp.get("/backups")
@admin_required
def list_backups():
    """Liệt kê tệp sao lưu (khi API chạy cùng máy với SQL Server)."""
    backup_dir = current_app.config["BACKUP_DIR"]
    if not os.path.isdir(backup_dir):
        return success([], "Không truy cập được thư mục sao lưu từ máy chủ API")
    files = []
    for name in sorted(os.listdir(backup_dir), reverse=True):
        if name.lower().endswith(".bak"):
            path = os.path.join(backup_dir, name)
            files.append({"file": name, "size_bytes": os.path.getsize(path),
                          "modified": datetime.fromtimestamp(os.path.getmtime(path)).isoformat(timespec="seconds")})
    return success(files)


@bp.get("/export")
@admin_required
def export_data():
    """Xuất dữ liệu nghiệp vụ ra JSON (sao lưu logic, không chứa mật khẩu)."""
    payload = {
        "exported_at": now().isoformat(timespec="seconds"),
        "roles": [r.to_dict() for r in Role.query.order_by(Role.id).all()],
        "users": [u.to_dict() for u in User.query.order_by(User.id).all()],
        "categories": [c.to_dict() for c in Category.query.order_by(Category.id).all()],
        "authors": [a.to_dict() for a in Author.query.order_by(Author.id).all()],
        "books": [b.to_dict() for b in Book.query.order_by(Book.id).all()],
        "resources": [r.to_dict() for r in Resource.query.order_by(Resource.id).all()],
        "borrow_records": [r.to_dict() for r in BorrowRecord.query.order_by(BorrowRecord.id).all()],
    }
    log_action("EXPORT", "System")
    filename = f"library_export_{datetime.now():%Y%m%d_%H%M%S}.json"
    return Response(json.dumps(payload, ensure_ascii=False, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})


@bp.post("/cleanup-tokens")
@admin_required
def cleanup_tokens():
    """Dọn các token đã thu hồi quá hạn refresh (bảo trì định kỳ)."""
    cutoff = now() - current_app.config["JWT_REFRESH_TOKEN_EXPIRES"]
    deleted = TokenBlocklist.query.filter(TokenBlocklist.created_at < cutoff).delete()
    db.session.commit()
    log_action("CLEANUP_TOKENS", "System", None, {"deleted": deleted})
    return success({"deleted": deleted}, "Dọn dẹp token thành công")
