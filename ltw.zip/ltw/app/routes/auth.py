"""Xác thực: đăng ký, đăng nhập, làm mới token, đăng xuất, hồ sơ cá nhân (M20)."""
from datetime import timedelta

from flask import Blueprint, current_app
from flask_jwt_extended import (create_access_token, create_refresh_token, current_user,
                                decode_token, get_jwt, jwt_required)
from sqlalchemy import or_

from ..extensions import db
from ..models import ROLE_STUDENT, Role, TokenBlocklist, User, now
from ..utils.audit import log_action
from ..utils.decorators import login_required
from ..utils.responses import error, success
from ..utils.validators import (PHONE_RE, USERNAME_RE, clean_str, get_json_body, is_valid_email,
                                require_fields, validate_password)

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


def _issue_tokens(user):
    claims = {"role": user.role_name, "username": user.username}
    access = create_access_token(identity=str(user.id), additional_claims=claims)
    refresh = create_refresh_token(identity=str(user.id))
    return {
        "access_token": access,
        "refresh_token": refresh,
        "token_type": "Bearer",
        "expires_in": int(current_app.config["JWT_ACCESS_TOKEN_EXPIRES"].total_seconds()),
        "user": user.to_dict(),
    }


@bp.post("/register")
def register():
    """Sinh viên / bạn đọc tự đăng ký tài khoản (vai trò mặc định: Student)."""
    data = get_json_body()
    missing = require_fields(data, ["username", "password", "full_name", "email"])
    if missing:
        return error("Thiếu thông tin bắt buộc", 400, {"missing_fields": missing})

    username = data["username"].strip()
    email = data["email"].strip().lower()
    phone = clean_str(data.get("phone"), 20)

    if not USERNAME_RE.match(username):
        return error("Tên đăng nhập chỉ gồm chữ, số, dấu '_' hoặc '.', dài 3-50 ký tự")
    if not is_valid_email(email):
        return error("Email không hợp lệ")
    if phone and not PHONE_RE.match(phone):
        return error("Số điện thoại không hợp lệ")
    pw_error = validate_password(data["password"])
    if pw_error:
        return error(pw_error)
    if User.query.filter_by(username=username).first():
        return error("Tên đăng nhập đã tồn tại", 409)
    if User.query.filter_by(email=email).first():
        return error("Email đã được sử dụng", 409)

    role = Role.query.filter_by(name=ROLE_STUDENT).first()
    if not role:
        return error("Hệ thống chưa khởi tạo vai trò, hãy chạy init_db.py", 500)

    user = User(
        username=username,
        full_name=clean_str(data["full_name"], 100),
        email=email,
        phone=phone,
        student_code=clean_str(data.get("student_code"), 20),
        role=role,
    )
    user.set_password(data["password"])
    db.session.add(user)
    db.session.commit()
    log_action("REGISTER", "User", user.id, user=user)
    return success(user.to_dict(), "Đăng ký tài khoản thành công", 201)


@bp.post("/login")
def login():
    data = get_json_body()
    login_id = (data.get("username") or data.get("email") or "").strip()
    password = data.get("password") or ""
    if not login_id or not password:
        return error("Vui lòng nhập tên đăng nhập/email và mật khẩu")

    user = User.query.filter(or_(User.username == login_id, User.email == login_id.lower())).first()
    if not user:
        log_action("LOGIN_FAILED", "User", None, {"login": login_id})
        return error("Tên đăng nhập hoặc mật khẩu không đúng", 401)
    if not user.is_active:
        return error("Tài khoản đã bị vô hiệu hóa, vui lòng liên hệ quản trị viên", 403)
    if user.is_locked():
        minutes = max(1, int((user.locked_until - now()).total_seconds() // 60) + 1)
        return error(f"Tài khoản tạm khóa do đăng nhập sai nhiều lần. Thử lại sau {minutes} phút", 403)

    if not user.check_password(password):
        user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
        max_attempts = current_app.config["MAX_LOGIN_ATTEMPTS"]
        if user.failed_login_attempts >= max_attempts:
            user.locked_until = now() + timedelta(minutes=current_app.config["LOCK_MINUTES"])
            user.failed_login_attempts = 0
            db.session.commit()
            log_action("ACCOUNT_LOCKED", "User", user.id, user=user)
            return error(f"Sai mật khẩu {max_attempts} lần. Tài khoản bị khóa "
                         f"{current_app.config['LOCK_MINUTES']} phút", 403)
        db.session.commit()
        log_action("LOGIN_FAILED", "User", user.id, user=user)
        remaining = max_attempts - user.failed_login_attempts
        return error(f"Tên đăng nhập hoặc mật khẩu không đúng (còn {remaining} lần thử)", 401)

    user.failed_login_attempts = 0
    user.locked_until = None
    user.last_login = now()
    db.session.commit()
    log_action("LOGIN", "User", user.id, user=user)
    return success(_issue_tokens(user), "Đăng nhập thành công")


@bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    user = current_user
    access = create_access_token(identity=str(user.id),
                                 additional_claims={"role": user.role_name, "username": user.username})
    return success({"access_token": access, "token_type": "Bearer"}, "Làm mới token thành công")


@bp.post("/logout")
@jwt_required()
def logout():
    """Thu hồi access token hiện tại (và refresh token nếu gửi kèm trong body)."""
    db.session.add(TokenBlocklist(jti=get_jwt()["jti"]))
    refresh_token = get_json_body().get("refresh_token")
    if refresh_token:
        try:
            jti = decode_token(refresh_token)["jti"]
            if not TokenBlocklist.query.filter_by(jti=jti).first():
                db.session.add(TokenBlocklist(jti=jti))
        except Exception:
            pass
    db.session.commit()
    log_action("LOGOUT", "User", current_user.id)
    return success(message="Đăng xuất thành công")


@bp.get("/me")
@login_required
def me():
    return success(current_user.to_dict())


@bp.put("/me")
@login_required
def update_me():
    data = get_json_body()
    user = current_user
    if "full_name" in data:
        name = clean_str(data["full_name"], 100)
        if not name:
            return error("Họ tên không được để trống")
        user.full_name = name
    if "email" in data:
        email = (data["email"] or "").strip().lower()
        if not is_valid_email(email):
            return error("Email không hợp lệ")
        if User.query.filter(User.email == email, User.id != user.id).first():
            return error("Email đã được sử dụng", 409)
        user.email = email
    if "phone" in data:
        phone = clean_str(data["phone"], 20)
        if phone and not PHONE_RE.match(phone):
            return error("Số điện thoại không hợp lệ")
        user.phone = phone
    db.session.commit()
    log_action("UPDATE_PROFILE", "User", user.id)
    return success(user.to_dict(), "Cập nhật thông tin cá nhân thành công")


@bp.put("/change-password")
@login_required
def change_password():
    data = get_json_body()
    missing = require_fields(data, ["old_password", "new_password"])
    if missing:
        return error("Thiếu thông tin bắt buộc", 400, {"missing_fields": missing})
    user = current_user
    if not user.check_password(data["old_password"]):
        return error("Mật khẩu hiện tại không đúng", 400)
    pw_error = validate_password(data["new_password"])
    if pw_error:
        return error(pw_error)
    if data["old_password"] == data["new_password"]:
        return error("Mật khẩu mới phải khác mật khẩu cũ")
    user.set_password(data["new_password"])
    db.session.commit()
    log_action("CHANGE_PASSWORD", "User", user.id)
    return success(message="Đổi mật khẩu thành công")
