"""Quản lý tài nguyên học tập điện tử (M10 - LMS/LCMS)."""
import os
import uuid

from flask import Blueprint, current_app, request, send_from_directory
from flask_jwt_extended import current_user
from sqlalchemy import or_
from werkzeug.utils import secure_filename

from ..extensions import db
from ..models import ACCESS_LEVELS, RESOURCE_TYPES, Book, Category, Resource
from ..utils.audit import log_action
from ..utils.decorators import login_required, staff_required
from ..utils.responses import error, paginated, success
from ..utils.validators import clean_str, get_request_data, require_fields, to_int

bp = Blueprint("resources", __name__, url_prefix="/api/resources")


def _allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_EXTENSIONS"]


def _can_access(resource):
    return resource.access_level == "public" or current_user.is_staff


def _save_file(file):
    """Lưu tệp với tên ngẫu nhiên để tránh trùng lặp/ghi đè và path traversal."""
    original = file.filename
    ext = original.rsplit(".", 1)[1].lower()
    stored = f"{uuid.uuid4().hex}_{secure_filename(original) or 'file.' + ext}"
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], stored)
    file.save(path)
    return stored, original, os.path.getsize(path), file.mimetype


def _remove_file(stored):
    if stored:
        path = os.path.join(current_app.config["UPLOAD_FOLDER"], stored)
        if os.path.isfile(path):
            os.remove(path)


def _apply(resource, data):
    if "title" in data:
        title = clean_str(data["title"], 255)
        if not title:
            return "Tiêu đề không được để trống"
        resource.title = title
    if "description" in data:
        resource.description = clean_str(data["description"])
    if "resource_type" in data:
        if data["resource_type"] not in RESOURCE_TYPES:
            return f"Loại tài nguyên phải thuộc: {', '.join(RESOURCE_TYPES)}"
        resource.resource_type = data["resource_type"]
    if "access_level" in data:
        if data["access_level"] not in ACCESS_LEVELS:
            return f"Mức truy cập phải thuộc: {', '.join(ACCESS_LEVELS)}"
        resource.access_level = data["access_level"]
    if "url" in data:
        url = clean_str(data["url"], 1000)
        if url and not url.lower().startswith(("http://", "https://")):
            return "URL phải bắt đầu bằng http:// hoặc https://"
        resource.url = url
    if "book_id" in data:
        bid = to_int(data["book_id"])
        if bid is not None and not db.session.get(Book, bid):
            return "Sách liên kết không tồn tại"
        resource.book_id = bid
    if "category_id" in data:
        cid = to_int(data["category_id"])
        if cid is not None and not db.session.get(Category, cid):
            return "Thể loại không tồn tại"
        resource.category_id = cid
    return None


@bp.get("")
@login_required
def list_resources():
    args = request.args
    query = Resource.query
    if not current_user.is_staff:
        query = query.filter(Resource.access_level == "public")
    elif args.get("access_level") in ACCESS_LEVELS:
        query = query.filter(Resource.access_level == args["access_level"])
    q = args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Resource.title.ilike(like), Resource.description.ilike(like)))
    if args.get("type") in RESOURCE_TYPES:
        query = query.filter(Resource.resource_type == args["type"])
    if to_int(args.get("book_id")) is not None:
        query = query.filter(Resource.book_id == to_int(args["book_id"]))
    if to_int(args.get("category_id")) is not None:
        query = query.filter(Resource.category_id == to_int(args["category_id"]))
    return paginated(query.order_by(Resource.created_at.desc(), Resource.id.desc()), lambda r: r.to_dict())


@bp.get("/<int:resource_id>")
@login_required
def get_resource(resource_id):
    resource = db.session.get(Resource, resource_id)
    if not resource or not _can_access(resource):
        return error("Không tìm thấy tài nguyên hoặc bạn không có quyền truy cập", 404)
    return success(resource.to_dict())


@bp.get("/<int:resource_id>/download")
@login_required
def download_resource(resource_id):
    resource = db.session.get(Resource, resource_id)
    if not resource or not _can_access(resource):
        return error("Không tìm thấy tài nguyên hoặc bạn không có quyền truy cập", 404)
    resource.download_count = (resource.download_count or 0) + 1
    db.session.commit()
    log_action("DOWNLOAD", "Resource", resource.id)
    if resource.file_path:
        return send_from_directory(current_app.config["UPLOAD_FOLDER"], resource.file_path,
                                   as_attachment=True, download_name=resource.file_name or resource.file_path)
    if resource.url:
        return success({"url": resource.url}, "Tài nguyên là liên kết ngoài")
    return error("Tài nguyên chưa có tệp hoặc liên kết", 404)


@bp.post("")
@staff_required
def create_resource():
    """Tạo tài nguyên. Gửi multipart/form-data (kèm field 'file') hoặc JSON (kèm 'url')."""
    data = get_request_data()
    missing = require_fields(data, ["title"])
    if missing:
        return error("Thiếu tiêu đề tài nguyên", 400, {"missing_fields": missing})
    file = request.files.get("file")
    if not file and not data.get("url"):
        return error("Cần tải lên tệp (field 'file') hoặc cung cấp 'url'")
    if file and (not file.filename or not _allowed(file.filename)):
        return error("Định dạng tệp không được hỗ trợ. Cho phép: "
                     + ", ".join(sorted(current_app.config["ALLOWED_EXTENSIONS"])))

    resource = Resource(uploaded_by=current_user.id)
    if not data.get("resource_type"):
        data["resource_type"] = "link" if not file else "document"
    err = _apply(resource, data)
    if err:
        return error(err)
    if file:
        resource.file_path, resource.file_name, resource.file_size, resource.mime_type = _save_file(file)
    db.session.add(resource)
    db.session.commit()
    log_action("CREATE", "Resource", resource.id, {"title": resource.title})
    return success(resource.to_dict(), "Thêm tài nguyên học tập thành công", 201)


@bp.put("/<int:resource_id>")
@staff_required
def update_resource(resource_id):
    resource = db.session.get(Resource, resource_id)
    if not resource:
        return error("Không tìm thấy tài nguyên", 404)
    data = get_request_data()
    file = request.files.get("file")
    if file and (not file.filename or not _allowed(file.filename)):
        return error("Định dạng tệp không được hỗ trợ")
    err = _apply(resource, data)
    if err:
        db.session.rollback()
        return error(err)
    if file:
        old = resource.file_path
        resource.file_path, resource.file_name, resource.file_size, resource.mime_type = _save_file(file)
        _remove_file(old)
    db.session.commit()
    log_action("UPDATE", "Resource", resource.id, {k: v for k, v in data.items()})
    return success(resource.to_dict(), "Cập nhật tài nguyên thành công")


@bp.delete("/<int:resource_id>")
@staff_required
def delete_resource(resource_id):
    resource = db.session.get(Resource, resource_id)
    if not resource:
        return error("Không tìm thấy tài nguyên", 404)
    stored, title = resource.file_path, resource.title
    db.session.delete(resource)
    db.session.commit()
    _remove_file(stored)
    log_action("DELETE", "Resource", resource_id, {"title": title})
    return success(message="Xóa tài nguyên thành công")
