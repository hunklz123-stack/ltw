"""Vai trò & ma trận phân quyền (M20)."""
from flask import Blueprint

from ..extensions import db
from ..models import ROLE_ADMIN, ROLE_LIBRARIAN, ROLE_STUDENT, Role
from ..utils.audit import log_action
from ..utils.decorators import admin_required
from ..utils.responses import error, success
from ..utils.validators import clean_str, get_json_body

bp = Blueprint("roles", __name__, url_prefix="/api/roles")

PERMISSIONS = {
    ROLE_ADMIN: [
        "Đăng nhập, quản lý hồ sơ cá nhân",
        "Quản lý tài khoản người dùng (thêm, sửa, xóa, khóa/mở khóa, đặt lại mật khẩu)",
        "Phân quyền người dùng",
        "Quản lý danh mục (thể loại, tác giả), sách và tài nguyên học tập",
        "Giám sát hoạt động hệ thống (nhật ký, thống kê), sao lưu/xuất dữ liệu",
    ],
    ROLE_LIBRARIAN: [
        "Đăng nhập, quản lý hồ sơ cá nhân",
        "Thêm, sửa, xóa thông tin sách; quản lý số lượng, tình trạng sách",
        "Quản lý tác giả, thể loại",
        "Cập nhật và quản lý tài nguyên học tập điện tử",
        "Lập phiếu mượn - trả sách, xem thống kê kho sách",
        "Tìm kiếm, tra cứu dữ liệu sách; dùng công cụ AI gợi ý phân loại",
    ],
    ROLE_STUDENT: [
        "Đăng ký, đăng nhập, quản lý hồ sơ cá nhân",
        "Tìm kiếm sách theo tên, tác giả, thể loại; tìm kiếm thông minh bằng ngôn ngữ tự nhiên",
        "Xem thông tin chi tiết, tình trạng sách",
        "Truy cập tài liệu điện tử được cấp quyền (public)",
        "Xem lịch sử mượn của bản thân, nhận gợi ý sách, hỏi đáp chatbot",
    ],
}


@bp.get("")
@admin_required
def list_roles():
    roles = Role.query.order_by(Role.id).all()
    return success([r.to_dict(with_count=True) for r in roles])


@bp.get("/permissions")
@admin_required
def permissions():
    return success(PERMISSIONS, "Ma trận phân quyền theo vai trò")


@bp.get("/<int:role_id>")
@admin_required
def get_role(role_id):
    role = db.session.get(Role, role_id)
    if not role:
        return error("Không tìm thấy vai trò", 404)
    data = role.to_dict(with_count=True)
    data["permissions"] = PERMISSIONS.get(role.name, [])
    return success(data)


@bp.put("/<int:role_id>")
@admin_required
def update_role(role_id):
    """Chỉ cho phép sửa tên hiển thị và mô tả; tên hệ thống của vai trò được cố định."""
    role = db.session.get(Role, role_id)
    if not role:
        return error("Không tìm thấy vai trò", 404)
    data = get_json_body()
    if "display_name" in data:
        role.display_name = clean_str(data["display_name"], 100)
    if "description" in data:
        role.description = clean_str(data["description"], 255)
    db.session.commit()
    log_action("UPDATE", "Role", role.id, data)
    return success(role.to_dict(with_count=True), "Cập nhật vai trò thành công")
