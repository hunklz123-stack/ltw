"""Mô hình dữ liệu (ORM) ánh xạ tới các bảng trong Microsoft SQL Server."""
from datetime import datetime

from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db

# ---------------- Hằng số vai trò ----------------
ROLE_ADMIN = "Admin"
ROLE_LIBRARIAN = "Librarian"
ROLE_STUDENT = "Student"
STAFF_ROLES = (ROLE_ADMIN, ROLE_LIBRARIAN)

BOOK_STATUSES = ("available", "out_of_stock", "discontinued")
BOOK_CONDITIONS = ("new", "good", "worn", "damaged")
RESOURCE_TYPES = ("ebook", "pdf", "slide", "video", "audio", "document", "link", "other")
ACCESS_LEVELS = ("public", "internal")  # public: mọi người dùng đăng nhập; internal: chỉ thủ thư/admin
BORROW_STATUSES = ("borrowing", "returned", "overdue", "lost")


def now():
    return datetime.now()


def fmt(dt):
    return dt.isoformat(timespec="seconds") if dt else None


# ---------------- Bảng liên kết Sách - Tác giả ----------------
book_authors = db.Table(
    "BookAuthors",
    db.Column("book_id", db.Integer, db.ForeignKey("Books.id", ondelete="CASCADE"), primary_key=True),
    db.Column("author_id", db.Integer, db.ForeignKey("Authors.id", ondelete="CASCADE"), primary_key=True),
)


class Role(db.Model):
    __tablename__ = "Roles"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    display_name = db.Column(db.Unicode(100))
    description = db.Column(db.Unicode(255))

    users = db.relationship("User", back_populates="role", lazy="dynamic")

    def to_dict(self, with_count=False):
        data = {
            "id": self.id,
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
        }
        if with_count:
            data["user_count"] = self.users.count()
        return data


class User(db.Model):
    __tablename__ = "Users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.Unicode(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.Unicode(100), nullable=False)
    email = db.Column(db.Unicode(100), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    student_code = db.Column(db.Unicode(20))
    role_id = db.Column(db.Integer, db.ForeignKey("Roles.id"), nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    failed_login_attempts = db.Column(db.Integer, nullable=False, default=0)
    locked_until = db.Column(db.DateTime)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, nullable=False, default=now)
    updated_at = db.Column(db.DateTime, nullable=False, default=now, onupdate=now)

    role = db.relationship("Role", back_populates="users")
    search_histories = db.relationship(
        "SearchHistory", back_populates="user", cascade="all, delete-orphan"
    )
    borrow_records = db.relationship("BorrowRecord", back_populates="user", lazy="dynamic")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def role_name(self):
        return self.role.name if self.role else None

    @property
    def is_staff(self):
        return self.role_name in STAFF_ROLES

    def is_locked(self):
        return self.locked_until is not None and self.locked_until > now()

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "full_name": self.full_name,
            "email": self.email,
            "phone": self.phone,
            "student_code": self.student_code,
            "role": self.role_name,
            "role_display": self.role.display_name if self.role else None,
            "is_active": self.is_active,
            "is_locked": self.is_locked(),
            "locked_until": fmt(self.locked_until),
            "last_login": fmt(self.last_login),
            "created_at": fmt(self.created_at),
            "updated_at": fmt(self.updated_at),
        }

    def to_brief(self):
        return {"id": self.id, "username": self.username, "full_name": self.full_name,
                "student_code": self.student_code}


class Category(db.Model):
    __tablename__ = "Categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(100), unique=True, nullable=False)
    description = db.Column(db.UnicodeText)
    created_at = db.Column(db.DateTime, nullable=False, default=now)

    books = db.relationship("Book", back_populates="category", lazy="dynamic")
    resources = db.relationship("Resource", back_populates="category", lazy="dynamic")

    def to_dict(self, with_count=False):
        data = {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_at": fmt(self.created_at),
        }
        if with_count:
            data["book_count"] = self.books.count()
        return data


class Author(db.Model):
    __tablename__ = "Authors"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(150), nullable=False)
    biography = db.Column(db.UnicodeText)
    nationality = db.Column(db.Unicode(100))
    birth_year = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, nullable=False, default=now)

    books = db.relationship("Book", secondary=book_authors, back_populates="authors", lazy="dynamic")

    def to_dict(self, with_count=False):
        data = {
            "id": self.id,
            "name": self.name,
            "biography": self.biography,
            "nationality": self.nationality,
            "birth_year": self.birth_year,
            "created_at": fmt(self.created_at),
        }
        if with_count:
            data["book_count"] = self.books.count()
        return data


class Book(db.Model):
    __tablename__ = "Books"

    id = db.Column(db.Integer, primary_key=True)
    isbn = db.Column(db.String(20), unique=True, nullable=False)
    title = db.Column(db.Unicode(255), nullable=False)
    description = db.Column(db.UnicodeText)
    publisher = db.Column(db.Unicode(150))
    publish_year = db.Column(db.Integer)
    language = db.Column(db.Unicode(50))
    pages = db.Column(db.Integer)
    category_id = db.Column(db.Integer, db.ForeignKey("Categories.id"))
    quantity = db.Column(db.Integer, nullable=False, default=0)            # tổng số bản
    available_quantity = db.Column(db.Integer, nullable=False, default=0)  # số bản còn trong kho
    status = db.Column(db.String(20), nullable=False, default="available")
    condition = db.Column(db.String(20), nullable=False, default="good")
    location = db.Column(db.Unicode(50))       # vị trí kệ sách
    keywords = db.Column(db.Unicode(500))      # từ khóa, phân tách bằng dấu phẩy
    cover_image = db.Column(db.Unicode(500))
    created_by = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, nullable=False, default=now)
    updated_at = db.Column(db.DateTime, nullable=False, default=now, onupdate=now)

    category = db.relationship("Category", back_populates="books")
    authors = db.relationship("Author", secondary=book_authors, back_populates="books")
    resources = db.relationship("Resource", back_populates="book", lazy="dynamic")
    borrow_records = db.relationship("BorrowRecord", back_populates="book", lazy="dynamic")

    @property
    def borrowed_quantity(self):
        return (self.quantity or 0) - (self.available_quantity or 0)

    def refresh_status(self):
        """Tự động cập nhật trạng thái theo số lượng (trừ khi sách đã ngừng lưu hành)."""
        if self.status != "discontinued":
            self.status = "available" if (self.available_quantity or 0) > 0 else "out_of_stock"

    def to_brief(self):
        return {"id": self.id, "isbn": self.isbn, "title": self.title,
                "authors": [a.name for a in self.authors]}

    def to_dict(self):
        return {
            "id": self.id,
            "isbn": self.isbn,
            "title": self.title,
            "description": self.description,
            "publisher": self.publisher,
            "publish_year": self.publish_year,
            "language": self.language,
            "pages": self.pages,
            "category": self.category.to_dict() if self.category else None,
            "authors": [{"id": a.id, "name": a.name} for a in self.authors],
            "quantity": self.quantity,
            "available_quantity": self.available_quantity,
            "borrowed_quantity": self.borrowed_quantity,
            "status": self.status,
            "condition": self.condition,
            "location": self.location,
            "keywords": [k.strip() for k in (self.keywords or "").split(",") if k.strip()],
            "cover_image": self.cover_image,
            "created_at": fmt(self.created_at),
            "updated_at": fmt(self.updated_at),
        }


class Resource(db.Model):
    """Tài nguyên học tập điện tử (ebook, slide, video, đường dẫn...)."""
    __tablename__ = "Resources"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.Unicode(255), nullable=False)
    description = db.Column(db.UnicodeText)
    resource_type = db.Column(db.String(20), nullable=False, default="document")
    url = db.Column(db.Unicode(1000))
    file_path = db.Column(db.Unicode(500))
    file_name = db.Column(db.Unicode(255))
    file_size = db.Column(db.Integer)
    mime_type = db.Column(db.String(100))
    book_id = db.Column(db.Integer, db.ForeignKey("Books.id"))
    category_id = db.Column(db.Integer, db.ForeignKey("Categories.id"))
    access_level = db.Column(db.String(20), nullable=False, default="public")
    uploaded_by = db.Column(db.Integer)
    download_count = db.Column(db.Integer, nullable=False, default=0)
    created_at = db.Column(db.DateTime, nullable=False, default=now)
    updated_at = db.Column(db.DateTime, nullable=False, default=now, onupdate=now)

    book = db.relationship("Book", back_populates="resources")
    category = db.relationship("Category", back_populates="resources")

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "resource_type": self.resource_type,
            "url": self.url,
            "has_file": bool(self.file_path),
            "file_name": self.file_name,
            "file_size": self.file_size,
            "mime_type": self.mime_type,
            "book": self.book.to_brief() if self.book else None,
            "category": {"id": self.category.id, "name": self.category.name} if self.category else None,
            "access_level": self.access_level,
            "uploaded_by": self.uploaded_by,
            "download_count": self.download_count,
            "download_endpoint": f"/api/resources/{self.id}/download",
            "created_at": fmt(self.created_at),
            "updated_at": fmt(self.updated_at),
        }


class BorrowRecord(db.Model):
    """Phiếu mượn - trả sách (bảng mở rộng)."""
    __tablename__ = "BorrowRecords"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("Users.id"), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey("Books.id"), nullable=False)
    borrow_date = db.Column(db.DateTime, nullable=False, default=now)
    due_date = db.Column(db.DateTime, nullable=False)
    return_date = db.Column(db.DateTime)
    status = db.Column(db.String(20), nullable=False, default="borrowing")
    extend_count = db.Column(db.Integer, nullable=False, default=0)
    note = db.Column(db.Unicode(500))
    processed_by = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, nullable=False, default=now)

    user = db.relationship("User", back_populates="borrow_records")
    book = db.relationship("Book", back_populates="borrow_records")

    @property
    def is_overdue(self):
        return self.status == "borrowing" and self.due_date is not None and self.due_date < now()

    @property
    def effective_status(self):
        return "overdue" if self.is_overdue else self.status

    def to_dict(self):
        days_overdue = (now() - self.due_date).days if self.is_overdue else 0
        return {
            "id": self.id,
            "user": self.user.to_brief() if self.user else None,
            "book": self.book.to_brief() if self.book else None,
            "borrow_date": fmt(self.borrow_date),
            "due_date": fmt(self.due_date),
            "return_date": fmt(self.return_date),
            "status": self.effective_status,
            "days_overdue": days_overdue,
            "extend_count": self.extend_count,
            "note": self.note,
            "processed_by": self.processed_by,
        }


class AuditLog(db.Model):
    """Nhật ký hoạt động hệ thống (giám sát - M21)."""
    __tablename__ = "AuditLogs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    username = db.Column(db.Unicode(50))
    action = db.Column(db.String(50), nullable=False)
    entity = db.Column(db.String(50))
    entity_id = db.Column(db.String(50))
    details = db.Column(db.UnicodeText)
    ip_address = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, nullable=False, default=now, index=True)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "username": self.username,
            "action": self.action,
            "entity": self.entity,
            "entity_id": self.entity_id,
            "details": self.details,
            "ip_address": self.ip_address,
            "created_at": fmt(self.created_at),
        }


class SearchHistory(db.Model):
    """Lịch sử tìm kiếm - phục vụ gợi ý sách cá nhân hóa."""
    __tablename__ = "SearchHistory"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("Users.id", ondelete="CASCADE"), nullable=False)
    search_text = db.Column(db.Unicode(500), nullable=False)  # không đặt tên "query" để tránh trùng Model.query
    created_at = db.Column(db.DateTime, nullable=False, default=now)

    user = db.relationship("User", back_populates="search_histories")


class TokenBlocklist(db.Model):
    """Danh sách token đã đăng xuất (thu hồi)."""
    __tablename__ = "TokenBlocklist"

    id = db.Column(db.Integer, primary_key=True)
    jti = db.Column(db.String(64), nullable=False, unique=True)
    created_at = db.Column(db.DateTime, nullable=False, default=now)
