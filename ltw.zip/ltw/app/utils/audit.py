"""Ghi nhật ký hoạt động hệ thống."""
import json

from flask import current_app, request
from flask_jwt_extended import get_current_user

from ..extensions import db
from ..models import AuditLog


def _client_ip():
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",")[0].strip()[:50]
    return (request.remote_addr or "")[:50]


def log_action(action, entity=None, entity_id=None, details=None, user=None):
    try:
        if user is None:
            try:
                user = get_current_user()
            except RuntimeError:
                user = None
        if isinstance(details, (dict, list)):
            details = json.dumps(details, ensure_ascii=False, default=str)
        db.session.add(AuditLog(
            user_id=user.id if user else None,
            username=user.username if user else None,
            action=action,
            entity=entity,
            entity_id=str(entity_id) if entity_id is not None else None,
            details=details,
            ip_address=_client_ip(),
        ))
        db.session.commit()
    except Exception:  # không để lỗi ghi log làm hỏng nghiệp vụ chính
        db.session.rollback()
        current_app.logger.exception("Không ghi được audit log")
