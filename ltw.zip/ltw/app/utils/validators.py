"""Hàm kiểm tra dữ liệu đầu vào."""
import re
from datetime import datetime

from flask import request

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.]{3,50}$")
PHONE_RE = re.compile(r"^[0-9+\-\s]{8,20}$")


def get_json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def get_request_data():
    """Lấy dữ liệu từ JSON hoặc form (multipart)."""
    if request.is_json:
        return get_json_body()
    return request.form.to_dict()


def require_fields(data, fields):
    missing = []
    for field in fields:
        value = data.get(field)
        if value is None or (isinstance(value, str) and not value.strip()):
            missing.append(field)
    return missing


def is_valid_email(email):
    return bool(email and EMAIL_RE.match(email))


def validate_password(password):
    """Trả về thông báo lỗi nếu mật khẩu không đạt chính sách, ngược lại None."""
    if not password or len(password) < 8:
        return "Mật khẩu phải có ít nhất 8 ký tự"
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Mật khẩu phải chứa cả chữ cái và chữ số"
    return None


def to_int(value, default=None):
    if value is None or value == "":
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def parse_bool(value, default=None):
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def parse_date(value):
    if not value:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def clean_str(value, max_len=None):
    if value is None:
        return None
    value = str(value).strip()
    if max_len:
        value = value[:max_len]
    return value or None
