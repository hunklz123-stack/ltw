"""Decorator xác thực & phân quyền theo vai trò (M20)."""
from functools import wraps

from flask_jwt_extended import current_user, verify_jwt_in_request

from ..models import ROLE_ADMIN, ROLE_LIBRARIAN
from .responses import error


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        return fn(*args, **kwargs)
    return wrapper


def roles_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            # Lấy vai trò từ CSDL (không tin claim trong token) để phản ánh ngay khi admin đổi quyền
            if current_user.role_name not in roles:
                return error("Bạn không có quyền thực hiện chức năng này", 403)
            return fn(*args, **kwargs)
        return wrapper
    return decorator


admin_required = roles_required(ROLE_ADMIN)
staff_required = roles_required(ROLE_ADMIN, ROLE_LIBRARIAN)
