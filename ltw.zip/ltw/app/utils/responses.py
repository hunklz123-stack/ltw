"""Định dạng phản hồi JSON thống nhất và phân trang."""
from flask import jsonify, request


def success(data=None, message="Thành công", status=200, meta=None):
    body = {"success": True, "message": message}
    if data is not None:
        body["data"] = data
    if meta is not None:
        body["meta"] = meta
    return jsonify(body), status


def error(message="Có lỗi xảy ra", status=400, errors=None):
    body = {"success": False, "message": message}
    if errors:
        body["errors"] = errors
    return jsonify(body), status


def get_pagination_args(default_per_page=10, max_per_page=100):
    try:
        page = max(int(request.args.get("page", 1)), 1)
    except (TypeError, ValueError):
        page = 1
    try:
        per_page = int(request.args.get("per_page", default_per_page))
    except (TypeError, ValueError):
        per_page = default_per_page
    per_page = min(max(per_page, 1), max_per_page)
    return page, per_page


def paginated(query, serializer, message="Thành công"):
    """Phân trang truy vấn. Lưu ý: SQL Server yêu cầu query phải có ORDER BY khi dùng OFFSET."""
    page, per_page = get_pagination_args()
    total = query.order_by(None).count()
    items = query.limit(per_page).offset((page - 1) * per_page).all()
    pages = (total + per_page - 1) // per_page if total else 0
    return success(
        [serializer(item) for item in items],
        message,
        meta={"page": page, "per_page": per_page, "total": total, "pages": pages},
    )
