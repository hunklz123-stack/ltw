"""Dịch vụ AI: tìm kiếm thông minh, gợi ý sách, chatbot, tự động phân loại.

Mặc định dùng bộ xử lý ngôn ngữ tự nhiên nội bộ (chuẩn hóa tiếng Việt, loại stopword,
mở rộng từ đồng nghĩa, chấm điểm theo trọng số trường). Nếu cấu hình GEMINI_API_KEY,
hệ thống sẽ dùng thêm Google Gemini để phân tích câu hỏi / sinh câu trả lời tự nhiên;
khi Gemini lỗi sẽ tự động quay về bộ xử lý nội bộ.
"""
import json
import re
import unicodedata
from collections import Counter

import requests
from flask import current_app
from sqlalchemy import func

from ..extensions import db
from ..models import Book, BorrowRecord, Category, Resource, SearchHistory, now

# ============================================================ Xử lý ngôn ngữ

STOPWORDS = {
    "tim", "kiem", "sach", "cuon", "quyen", "cho", "toi", "minh", "em", "anh", "chi", "ban", "ve",
    "cua", "la", "co", "nao", "nhung", "cac", "mot", "va", "hay", "hoac", "gi", "muon", "can",
    "danh", "giup", "voi", "the", "nhe", "a", "oi", "xin", "hoi", "de", "doc", "duoc", "khong",
    "o", "trong", "tai", "lieu", "nay", "kia", "do", "thi", "ma", "nhe", "vay", "sao", "lam",
    "nhu", "the", "nhieu", "it", "rat", "qua", "cung", "da", "dang", "se", "bi", "boi", "tu",
    "den", "len", "xuong", "ra", "vao", "hon", "nhat", "ai", "dau", "khi", "neu", "vi", "nen",
    "please", "find", "book", "books", "the", "a", "an", "of", "for", "about", "me", "i", "want",
    "some", "to", "and", "or", "in", "on", "with", "is", "are", "show", "list", "goi", "y",
    "de", "xuat", "thu", "vien", "liet", "ke", "hien",
}
# Từ ngắn/đặc biệt vẫn giữ lại dù trùng stopword hoặc chỉ có 1 ký tự
KEEP_TOKENS = {"c", "r", "c++", "c#", "ai", "go", "js", "ml", "it", "3d", "ui", "ux"}

SYNONYMS = {
    "lap trinh": ["programming", "coding", "code"],
    "programming": ["lap trinh"],
    "tri tue nhan tao": ["ai", "artificial intelligence", "machine learning", "hoc may"],
    "ai": ["tri tue nhan tao", "artificial intelligence"],
    "hoc may": ["machine learning", "tri tue nhan tao"],
    "machine learning": ["hoc may"],
    "hoc sau": ["deep learning"],
    "deep learning": ["hoc sau"],
    "co so du lieu": ["database", "sql"],
    "database": ["co so du lieu", "sql"],
    "sql": ["co so du lieu", "database"],
    "tieng anh": ["english", "ielts", "toeic"],
    "english": ["tieng anh"],
    "kinh te": ["economics", "kinh doanh"],
    "kinh doanh": ["business", "kinh te", "quan tri"],
    "web": ["html", "css", "javascript", "website"],
    "mang may tinh": ["network", "networking"],
    "toan": ["toan hoc", "math"],
    "giai tich": ["calculus"],
    "xac suat": ["thong ke", "probability"],
    "tieu thuyet": ["van hoc", "novel"],
    "truyen": ["van hoc", "tieu thuyet"],
    "khoa hoc du lieu": ["data science", "python", "phan tich du lieu"],
    "data science": ["khoa hoc du lieu"],
    "ky nang song": ["phat trien ban than", "self help"],
}

BEGINNER_QUERY = ["nguoi moi bat dau", "moi bat dau", "nguoi moi", "co ban", "nhap mon", "can ban",
                  "beginner", "beginners", "so cap", "tu con so 0", "tu dau", "de hieu"]
BEGINNER_DOC = ["co ban", "nhap mon", "can ban", "beginner", "nguoi moi", "tu dau", "so cap",
                "introduction", "basic", "crash course", "de hieu", "first", "head first"]
ADVANCED_QUERY = ["nang cao", "chuyen sau", "advanced", "chuyen nghiep", "expert"]
ADVANCED_DOC = ["nang cao", "chuyen sau", "advanced", "chuyen nghiep", "expert", "fluent", "effective"]
AVAILABLE_QUERY = ["con san", "co san", "con sach", "san co", "dang co", "con trong kho"]

FIELD_WEIGHTS = {"title": 3.0, "keywords": 2.5, "category": 2.0, "authors": 2.0,
                 "publisher": 0.5, "description": 1.0}

CATEGORY_HINTS = {
    "cong nghe": ["lap trinh", "python", "java", "javascript", "web", "database", "sql", "ai", "may tinh",
                  "phan mem", "code", "thuat toan", "mang", "du lieu", "machine learning", "linux", "app"],
    "toan": ["toan", "dai so", "giai tich", "xac suat", "thong ke", "hinh hoc", "ma tran", "calculus"],
    "van hoc": ["tieu thuyet", "truyen", "tho", "van", "novel", "tac pham", "ky su"],
    "kinh te": ["kinh te", "marketing", "tai chinh", "quan tri", "kinh doanh", "ke toan", "dau tu",
                "khoi nghiep"],
    "ngoai ngu": ["tieng anh", "english", "ielts", "toeic", "ngu phap", "tu vung", "tieng nhat",
                  "tieng trung", "tieng han"],
    "khoa hoc": ["vat ly", "hoa hoc", "sinh hoc", "vu tru", "khoa hoc", "tien hoa", "luong tu"],
    "ky nang": ["ky nang", "phat trien ban than", "giao tiep", "thoi quen", "tu duy", "lanh dao"],
}


def normalize(text):
    """Chữ thường, bỏ dấu tiếng Việt, bỏ ký tự đặc biệt (giữ + và # cho C++, C#)."""
    if not text:
        return ""
    text = str(text).lower().replace("đ", "d")
    text = unicodedata.normalize("NFD", text)
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    text = re.sub(r"[^a-z0-9+#\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text, remove_stopwords=True):
    tokens = normalize(text).split()
    if not remove_stopwords:
        return tokens
    result = []
    for t in tokens:
        if t in KEEP_TOKENS:
            result.append(t)
        elif t not in STOPWORDS and len(t) > 1:
            result.append(t)
    return result


def contains(text, phrase):
    """Kiểm tra cụm từ xuất hiện trọn vẹn (theo ranh giới từ)."""
    if not text or not phrase:
        return False
    return re.search(r"(?<![a-z0-9])" + re.escape(phrase) + r"(?![a-z0-9])", text) is not None


def _remove_phrase(text, phrase):
    return re.sub(r"(?<![a-z0-9])" + re.escape(phrase) + r"(?![a-z0-9])", " ", text)


# ============================================================ Gemini (tùy chọn)

def gemini_available():
    return bool(current_app.config.get("GEMINI_API_KEY"))


def call_gemini(prompt, json_mode=False, timeout=15):
    """Gọi Google Gemini qua REST API. Trả về chuỗi văn bản hoặc None nếu lỗi/không cấu hình."""
    key = current_app.config.get("GEMINI_API_KEY")
    if not key:
        return None
    model = current_app.config.get("GEMINI_MODEL", "gemini-2.0-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}]}
    if json_mode:
        body["generationConfig"] = {"responseMimeType": "application/json", "temperature": 0.2}
    try:
        resp = requests.post(url, headers={"x-goog-api-key": key}, json=body, timeout=timeout)
        resp.raise_for_status()
        return resp.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as exc:  # mạng lỗi, hết quota, sai key...
        current_app.logger.warning("Gemini lỗi, chuyển sang xử lý nội bộ: %s", exc)
        return None


def _gemini_json(prompt):
    text = call_gemini(prompt, json_mode=True)
    if not text:
        return None
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        match = re.search(r"\{.*\}", text, re.S)
        if match:
            try:
                return json.loads(match.group(0))
            except ValueError:
                return None
    return None


# ============================================================ 1. Tìm kiếm thông minh

def parse_query(query):
    """Phân tích câu truy vấn ngôn ngữ tự nhiên thành các tiêu chí tìm kiếm."""
    norm = normalize(query)
    info = {"normalized": norm, "level": None, "available_only": False,
            "year_from": None, "year_to": None}

    for phrase in sorted(BEGINNER_QUERY, key=len, reverse=True):
        if contains(norm, phrase):
            info["level"] = "beginner"
            norm = _remove_phrase(norm, phrase)
    for phrase in sorted(ADVANCED_QUERY, key=len, reverse=True):
        if contains(norm, phrase):
            info["level"] = "advanced"
            norm = _remove_phrase(norm, phrase)
    for phrase in AVAILABLE_QUERY:
        if contains(norm, phrase):
            info["available_only"] = True
            norm = _remove_phrase(norm, phrase)

    for m in re.finditer(r"\b(sau|tu|truoc|nam)\s+(?:nam\s+)?((?:19|20)\d{2})\b", norm):
        word, year = m.group(1), int(m.group(2))
        if word in ("sau", "tu"):
            info["year_from"] = year + (1 if word == "sau" else 0)
        elif word == "truoc":
            info["year_to"] = year - 1
        else:
            info["year_from"] = info["year_to"] = year
    norm = re.sub(r"\b(sau|tu|truoc|nam)\s+(?:nam\s+)?((?:19|20)\d{2})\b", " ", norm)

    # Giữ nguyên các cụm từ nhiều âm tiết đã biết (vd: "co so du lieu", "lap trinh")
    # để tránh bị tách nhỏ / mất do stopword ("lieu" trong "tai lieu").
    full_norm = norm
    phrases = []
    for key in sorted(SYNONYMS, key=len, reverse=True):
        if " " in key and contains(norm, key):
            phrases.append(key)
            norm = _remove_phrase(norm, key)

    tokens = tokenize(norm)
    bigrams = [f"{tokens[i]} {tokens[i + 1]}" for i in range(len(tokens) - 1)]
    keywords = phrases + [t for t in tokens if t not in phrases]
    expanded = []
    for key, values in SYNONYMS.items():
        if contains(full_norm, key):
            expanded.extend(v for v in values if v not in keywords and v not in expanded)
    info.update({"keywords": keywords, "bigrams": bigrams, "expanded": expanded})
    return info


def _book_fields(book):
    return {
        "title": normalize(book.title),
        "keywords": normalize(book.keywords),
        "category": normalize(book.category.name if book.category else ""),
        "authors": normalize(" ".join(a.name for a in book.authors)),
        "publisher": normalize(book.publisher),
        "description": normalize(book.description),
    }


def score_book(book, parsed, fields=None):
    fields = fields or _book_fields(book)
    score, matched = 0.0, set()
    terms = ([(t, 1.0) for t in parsed["keywords"]] + [(b, 1.5) for b in parsed["bigrams"]]
             + [(e, 0.8) for e in parsed["expanded"]])
    for term, factor in terms:
        for fname, text in fields.items():
            if contains(text, term):
                score += FIELD_WEIGHTS[fname] * factor
                matched.add(term)

    keyword_hits = [t for t in parsed["keywords"] if t in matched]
    if parsed["keywords"]:
        coverage = len(keyword_hits) / len(parsed["keywords"])
        score *= 0.5 + coverage  # ưu tiên sách khớp nhiều từ khóa
        has_topic = score > 0
    else:
        has_topic = True  # truy vấn chỉ có trình độ (vd: "sách cho người mới bắt đầu")

    level = parsed.get("level")
    if level and has_topic:
        level_text = " ".join([fields["title"], fields["keywords"], fields["description"]])
        hints = BEGINNER_DOC if level == "beginner" else ADVANCED_DOC
        if any(contains(level_text, h) for h in hints):
            score += 3.0
            matched.add("trình độ: " + ("cơ bản" if level == "beginner" else "nâng cao"))
    if score > 0 and book.available_quantity > 0:
        score += 0.3
    return score, matched


def smart_search(query, limit=10):
    parsed = parse_query(query)
    engine = "local-nlp"

    if gemini_available():
        ai = _gemini_json(
            "Bạn là trợ lý tìm kiếm của thư viện. Phân tích câu truy vấn tìm sách và CHỈ trả về JSON với "
            "các khóa: keywords (mảng từ khóa chủ đề quan trọng, có thể thêm từ đồng nghĩa tiếng Việt và "
            "tiếng Anh, không gồm từ chung chung như 'sách', 'tìm'), level ('beginner'|'advanced'|null), "
            "available_only (boolean), year_from (số|null), year_to (số|null).\n"
            f"Câu truy vấn: \"{query}\""
        )
        if isinstance(ai, dict):
            engine = "gemini+local-nlp"
            for kw in ai.get("keywords") or []:
                kw_norm = normalize(kw)
                if not kw_norm or kw_norm in STOPWORDS:
                    continue
                # Từ khóa do AI bổ sung được coi là "mở rộng" (trọng số thấp) để không làm giảm độ phủ
                if kw_norm not in parsed["keywords"] and kw_norm not in parsed["expanded"]:
                    parsed["expanded"].append(kw_norm)
            parsed["level"] = parsed["level"] or (ai.get("level") if ai.get("level") in ("beginner", "advanced") else None)
            parsed["available_only"] = parsed["available_only"] or bool(ai.get("available_only"))
            for key in ("year_from", "year_to"):
                if parsed[key] is None and isinstance(ai.get(key), int):
                    parsed[key] = ai[key]

    q = Book.query.filter(Book.status != "discontinued")
    if parsed["available_only"]:
        q = q.filter(Book.available_quantity > 0)
    if parsed["year_from"]:
        q = q.filter(Book.publish_year >= parsed["year_from"])
    if parsed["year_to"]:
        q = q.filter(Book.publish_year <= parsed["year_to"])

    if not parsed["keywords"] and not parsed["expanded"] and not parsed["level"] \
            and not parsed["available_only"] and not parsed["year_from"] and not parsed["year_to"]:
        return {"query": query, "engine": engine, "analysis": _analysis(parsed), "total": 0, "results": []}

    results = []
    filter_only = not parsed["keywords"] and not parsed["expanded"] and not parsed["level"]
    for book in q.all():
        if filter_only:
            score, matched = 1.0, set()
        else:
            score, matched = score_book(book, parsed)
        if score > 0:
            results.append((score, book, matched))
    results.sort(key=lambda x: (x[0], x[1].available_quantity), reverse=True)

    return {
        "query": query,
        "engine": engine,
        "analysis": _analysis(parsed),
        "total": len(results),
        "results": [{"score": round(s, 2), "matched_terms": sorted(m), "book": b.to_dict()}
                    for s, b, m in results[:limit]],
    }


def _analysis(parsed):
    return {
        "keywords": parsed["keywords"],
        "expanded_terms": parsed["expanded"],
        "level": parsed["level"],
        "available_only": parsed["available_only"],
        "year_from": parsed["year_from"],
        "year_to": parsed["year_to"],
    }


# ============================================================ 2. Gợi ý sách cá nhân hóa

def recommend_books(user, limit=10):
    records = BorrowRecord.query.filter_by(user_id=user.id).all()
    borrowed_ids = {r.book_id for r in records}
    cat_weights, author_weights = Counter(), Counter()
    for r in records:
        if r.book and r.book.category_id:
            cat_weights[r.book.category_id] += 3
        for a in (r.book.authors if r.book else []):
            author_weights[a.id] += 2

    searches = SearchHistory.query.filter_by(user_id=user.id) \
        .order_by(SearchHistory.created_at.desc()).limit(20).all()
    search_terms = Counter()
    for s in searches:
        for t in tokenize(s.search_text):
            search_terms[t] += 1

    popularity = dict(db.session.query(BorrowRecord.book_id, func.count(BorrowRecord.id))
                      .group_by(BorrowRecord.book_id).all())
    personalized = bool(cat_weights or author_weights or search_terms)

    scored = []
    for book in Book.query.filter(Book.status != "discontinued").all():
        if book.id in borrowed_ids:
            continue
        score, reasons = 0.0, []
        if book.category_id in cat_weights:
            score += cat_weights[book.category_id]
            reasons.append(f"Cùng thể loại '{book.category.name}' với sách bạn đã mượn")
        aw = sum(author_weights[a.id] for a in book.authors)
        if aw:
            score += aw
            reasons.append("Cùng tác giả với sách bạn đã mượn")
        if search_terms:
            text = " ".join([normalize(book.title), normalize(book.keywords),
                             normalize(book.category.name if book.category else "")])
            hits = [t for t in search_terms if contains(text, t)]
            if hits:
                score += 1.5 * sum(search_terms[t] for t in hits)
                reasons.append("Phù hợp lịch sử tìm kiếm: " + ", ".join(hits[:5]))
        pop = popularity.get(book.id, 0)
        score += min(pop, 10) * 0.2
        if not reasons:
            reasons.append("Sách được mượn nhiều" if pop else "Sách mới trong thư viện")
        if book.available_quantity > 0:
            score += 0.3
        scored.append((score, book.created_at or now(), book, reasons))

    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return {
        "strategy": "personalized" if personalized else "popular",
        "based_on": {
            "borrowed_books": len(borrowed_ids),
            "recent_searches": [s.search_text for s in searches[:5]],
        },
        "results": [{"score": round(s, 2), "reasons": r, "book": b.to_dict()}
                    for s, _, b, r in scored[:limit]],
    }


# ============================================================ 3. Chatbot thư viện

INTENTS = [
    ("my_borrows", ["sach toi dang muon", "toi dang muon nhung", "toi dang muon sach gi",
                    "toi da muon nhung", "lich su muon", "sach dang muon cua toi", "han tra cua toi"]),
    ("hours", ["gio mo cua", "mo cua", "dong cua", "may gio", "thoi gian lam viec", "gio lam viec",
               "lich lam viec"]),
    ("borrow_rules", ["cach muon", "thu tuc muon", "quy dinh muon", "quy dinh thu vien", "muon toi da",
                      "duoc muon bao nhieu", "muon bao lau", "muon duoc bao", "gia han", "han tra",
                      "qua han", "cach tra sach", "tien phat", "bi phat"]),
    ("categories", ["nhung the loai", "the loai nao", "cac the loai", "danh muc sach", "chu de nao",
                    "loai sach nao"]),
    ("stats", ["bao nhieu sach", "tong so sach", "thong ke thu vien", "bao nhieu dau sach",
               "bao nhieu cuon"]),
    ("resources", ["tai lieu dien tu nao", "co tai lieu dien tu", "nhung tai lieu dien tu", "tai nguyen hoc tap",
                   "ebook nao", "video bai giang", "giao trinh dien tu"]),
    ("recommend", ["goi y", "de xuat", "nen doc", "recommend", "sach hay"]),
    ("how_to_search", ["cach tim", "cach tra cuu", "huong dan tra cuu", "huong dan tim", "huong dan su dung",
                       "su dung he thong", "lam sao de tim", "lam the nao de tim"]),
]
GREETINGS = ["xin chao", "chao ban", "chao", "hello", "hi", "alo", "hey"]


def detect_intent(message):
    norm = normalize(message)
    for intent, phrases in INTENTS:
        if any(contains(norm, p) for p in phrases):
            return intent
    if any(contains(norm, g) for g in GREETINGS):
        rest = norm
        for g in GREETINGS:
            rest = _remove_phrase(rest, g)
        if not tokenize(rest):
            return "greeting"
    return "search"


def _format_books(items):
    lines = []
    for i, b in enumerate(items, 1):
        authors = ", ".join(a["name"] for a in b["authors"]) or "Không rõ tác giả"
        lines.append(f"{i}. {b['title']} - {authors} (còn {b['available_quantity']}/{b['quantity']} cuốn"
                     f"{', kệ ' + b['location'] if b.get('location') else ''})")
    return "\n".join(lines)


def chatbot(message, user):
    cfg = current_app.config
    intent = detect_intent(message)
    books, data = [], {}

    if intent == "greeting":
        reply = (f"Xin chào {user.full_name}! Tôi là trợ lý thư viện. Bạn có thể hỏi tôi về sách "
                 "(vd: 'Tìm sách Python cho người mới bắt đầu'), thể loại, giờ mở cửa, quy định mượn - trả, "
                 "hoặc sách bạn đang mượn.")
    elif intent == "hours":
        reply = f"Giờ mở cửa thư viện: {cfg['LIBRARY_OPEN_HOURS']}."
    elif intent == "borrow_rules":
        reply = (f"Quy định mượn - trả: mỗi bạn đọc được mượn tối đa {cfg['MAX_BORROW_BOOKS']} cuốn, "
                 f"thời hạn {cfg['BORROW_DAYS']} ngày/lần, được gia hạn tối đa {cfg['MAX_EXTEND_TIMES']} lần "
                 "(khi chưa quá hạn). Người có sách quá hạn sẽ không được mượn thêm. "
                 "Vui lòng mang thẻ sinh viên đến quầy thủ thư để mượn/trả sách.")
    elif intent == "my_borrows":
        records = BorrowRecord.query.filter_by(user_id=user.id, status="borrowing") \
            .order_by(BorrowRecord.due_date).all()
        data["borrows"] = [r.to_dict() for r in records]
        if not records:
            reply = "Hiện tại bạn không mượn cuốn sách nào."
        else:
            lines = [f"- {r.book.title}: hạn trả {r.due_date:%d/%m/%Y}"
                     + (" (ĐÃ QUÁ HẠN)" if r.is_overdue else "") for r in records]
            reply = f"Bạn đang mượn {len(records)} cuốn:\n" + "\n".join(lines)
    elif intent == "categories":
        cats = Category.query.order_by(Category.name).all()
        data["categories"] = [c.to_dict(with_count=True) for c in cats]
        reply = "Thư viện hiện có các thể loại:\n" + "\n".join(
            f"- {c['name']} ({c['book_count']} đầu sách)" for c in data["categories"])
    elif intent == "stats":
        titles = Book.query.count()
        copies = db.session.query(func.coalesce(func.sum(Book.quantity), 0)).scalar()
        available = db.session.query(func.coalesce(func.sum(Book.available_quantity), 0)).scalar()
        data.update({"titles": titles, "copies": int(copies), "available": int(available)})
        reply = (f"Thư viện hiện có {titles} đầu sách với tổng {int(copies)} cuốn, "
                 f"trong đó {int(available)} cuốn đang sẵn sàng cho mượn.")
    elif intent == "resources":
        q = Resource.query
        if not user.is_staff:
            q = q.filter(Resource.access_level == "public")
        res = q.order_by(Resource.created_at.desc()).limit(5).all()
        data["resources"] = [r.to_dict() for r in res]
        reply = ("Một số tài liệu điện tử mới nhất:\n" + "\n".join(f"- {r.title} ({r.resource_type})" for r in res)
                 + "\nXem đầy đủ tại GET /api/resources.") if res else "Hiện chưa có tài liệu điện tử nào."
    elif intent == "recommend":
        rec = recommend_books(user, limit=5)
        books = [r["book"] for r in rec["results"]]
        reply = "Tôi gợi ý cho bạn những cuốn sau:\n" + _format_books(books) if books \
            else "Hiện chưa có sách để gợi ý."
    elif intent == "how_to_search":
        reply = ("Bạn có thể tra cứu sách bằng: (1) GET /api/books?q=từ khóa (tìm theo tên, tác giả, thể loại, ISBN); "
                 "(2) lọc chi tiết: title, author, category_id, year_from, year_to, available=true; "
                 "(3) tìm kiếm thông minh POST /api/ai/smart-search với câu hỏi tự nhiên, "
                 "vd: 'sách lập trình Python cho người mới bắt đầu còn sẵn'.")
    else:
        result = smart_search(message, limit=5)
        books = [r["book"] for r in result["results"]]
        data["analysis"] = result["analysis"]
        if books:
            reply = f"Tôi tìm thấy {result['total']} cuốn phù hợp. Nổi bật nhất:\n" + _format_books(books)
        else:
            reply = ("Xin lỗi, tôi chưa tìm thấy sách phù hợp. Bạn thử dùng từ khóa khác, "
                     "hoặc hỏi 'thư viện có những thể loại nào?'.")

    source = "rule-based"
    if gemini_available() and intent not in ("greeting",):
        context = {"intent": intent, "draft_answer": reply, "books": [
            {"title": b["title"], "authors": [a["name"] for a in b["authors"]],
             "category": (b["category"] or {}).get("name"), "available": b["available_quantity"],
             "description": (b.get("description") or "")[:300]} for b in books]}
        ai_reply = call_gemini(
            "Bạn là chatbot của thư viện đại học, trả lời ngắn gọn, thân thiện bằng tiếng Việt. "
            "CHỈ dùng thông tin trong dữ liệu dưới đây, không bịa thêm sách hay quy định.\n"
            f"Dữ liệu (JSON): {json.dumps(context, ensure_ascii=False)}\n"
            f"Câu hỏi của bạn đọc {user.full_name}: \"{message}\""
        )
        if ai_reply:
            reply, source = ai_reply.strip(), "gemini"

    return {"intent": intent, "reply": reply, "source": source, "books": books, "data": data}


# ============================================================ 4. Tự động phân loại sách

def extract_keywords(title, description="", top_n=8):
    """Trích từ khóa (giữ nguyên dấu) gồm các cụm 2 âm tiết và từ đơn quan trọng."""
    counter = Counter()

    def process(text, weight):
        words = re.findall(r"[\wÀ-ỹ+#]+", (text or "").lower())
        normed = [normalize(w) for w in words]
        valid = [(w, n) for w, n in zip(words, normed) if n and (n in KEEP_TOKENS or (n not in STOPWORDS and len(n) > 1))
                 and not n.isdigit()]
        idx = {i for i, n in enumerate(normed) if n and (n in KEEP_TOKENS or (n not in STOPWORDS and len(n) > 1))
               and not n.isdigit()}
        for i in range(len(words) - 1):
            if i in idx and (i + 1) in idx:
                counter[f"{words[i]} {words[i + 1]}"] += 2 * weight
        for w, n in valid:
            if re.search(r"[a-z]", n) and (len(n) >= 4 or n in KEEP_TOKENS):
                counter[w] += weight

    process(title, 2)
    process(description, 1)
    result = []
    for kw, _ in counter.most_common():
        if not any(kw in r or r in kw for r in result):
            result.append(kw)
        if len(result) >= top_n:
            break
    return result


def suggest_category(title, description="", top_n=3):
    text = f"{title} {description or ''}"
    text_norm = normalize(text)
    tokens = set(tokenize(text))
    categories = Category.query.all()
    scores = []
    for cat in categories:
        cat_norm = normalize(cat.name)
        name_tokens = set(tokenize(cat.name))
        parts = [cat.name, cat.description or ""]
        for b in cat.books.limit(200).all():
            parts += [b.title, b.keywords or ""]
        profile = Counter(tokenize(" ".join(parts)))
        score = 0.0
        for t in tokens:
            if t in name_tokens:
                score += 5
            if t in profile:
                score += 1 + min(profile[t], 5) * 0.5
        for key, hints in CATEGORY_HINTS.items():
            if key in cat_norm:
                score += sum(2.5 for h in hints if contains(text_norm, h))
        scores.append((cat, score))

    total = sum(s for _, s in scores) or 1
    ranked = sorted((x for x in scores if x[1] > 0), key=lambda x: x[1], reverse=True)
    suggestions = [{"category": {"id": c.id, "name": c.name}, "score": round(s, 2),
                    "confidence": round(s / total, 2)} for c, s in ranked[:top_n]]
    keywords = extract_keywords(title, description)
    engine, reason = "local-nlp", None

    if gemini_available() and categories:
        ai = _gemini_json(
            "Bạn là thủ thư. Chọn thể loại phù hợp nhất cho cuốn sách trong danh sách thể loại cho sẵn và "
            "đề xuất 5-8 từ khóa tiếng Việt. CHỈ trả về JSON: {\"category\": \"<tên thể loại đúng như danh sách>\", "
            "\"keywords\": [..], \"reason\": \"<giải thích ngắn>\"}.\n"
            f"Danh sách thể loại: {json.dumps([c.name for c in categories], ensure_ascii=False)}\n"
            f"Tên sách: {title}\nMô tả: {description or ''}"
        )
        if isinstance(ai, dict):
            engine = "gemini+local-nlp"
            reason = ai.get("reason")
            match = next((c for c in categories if c.name == ai.get("category")), None)
            if match:
                suggestions = [s for s in suggestions if s["category"]["id"] != match.id]
                suggestions.insert(0, {"category": {"id": match.id, "name": match.name},
                                       "score": None, "confidence": None, "source": "gemini"})
                suggestions = suggestions[:top_n]
            if isinstance(ai.get("keywords"), list) and ai["keywords"]:
                keywords = [str(k) for k in ai["keywords"]][:top_n * 2]

    return {"engine": engine, "suggested_categories": suggestions, "suggested_keywords": keywords,
            "reason": reason}
