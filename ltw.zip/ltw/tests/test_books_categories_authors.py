"""Kiểm thử quản lý Sách, Thể loại, Tác giả và Kho tài sản (M09)."""
import pytest


def test_category_crud_and_force_delete(client, librarian_headers, student_headers):
    # 1. Thêm thể loại
    res_create = client.post("/api/categories", headers=librarian_headers, json={
        "name": "Toán rời rạc", "description": "Lý thuyết đồ thị và tổ hợp"
    })
    assert res_create.status_code == 201
    cat_id = res_create.get_json()["data"]["id"]

    # 2. Sinh viên đọc danh sách
    res_list = client.get("/api/categories?q=Toán", headers=student_headers)
    assert res_list.status_code == 200
    assert len(res_list.get_json()["data"]) >= 1

    # 3. Cập nhật thể loại
    res_up = client.put(f"/api/categories/{cat_id}", headers=librarian_headers, json={
        "description": "Cập nhật mô tả toán rời rạc"
    })
    assert res_up.status_code == 200

    # 4. Xóa thể loại chưa gắn sách
    res_del = client.delete(f"/api/categories/{cat_id}", headers=librarian_headers)
    assert res_del.status_code == 200


def test_author_crud(client, librarian_headers, student_headers):
    # Thêm tác giả
    res_create = client.post("/api/authors", headers=librarian_headers, json={
        "name": "Donald Knuth",
        "nationality": "Mỹ",
        "birth_year": 1938,
        "biography": "Tác giả The Art of Computer Programming",
    })
    assert res_create.status_code == 201
    author_id = res_create.get_json()["data"]["id"]

    # Xem chi tiết tác giả
    res_get = client.get(f"/api/authors/{author_id}", headers=student_headers)
    assert res_get.status_code == 200
    assert res_get.get_json()["data"]["name"] == "Donald Knuth"

    # Lọc theo quốc tịch
    res_nat = client.get("/api/authors?nationality=Mỹ", headers=student_headers)
    assert res_nat.status_code == 200
    assert any(a["name"] == "Donald Knuth" for a in res_nat.get_json()["data"])


def test_book_crud_and_search(client, librarian_headers, student_headers):
    # 1. Thêm sách mới
    res_create = client.post("/api/books", headers=librarian_headers, json={
        "isbn": "978-0131103627",
        "title": "The C Programming Language",
        "publisher": "Prentice Hall",
        "publish_year": 1988,
        "language": "Tiếng Anh",
        "pages": 272,
        "category_id": 1,
        "authors": ["Brian Kernighan", "Dennis Ritchie"],
        "quantity": 8,
        "location": "Kệ A2",
        "keywords": "c, lap trinh c, he thong, kinh dien",
        "condition": "good",
    })
    assert res_create.status_code == 201
    book_id = res_create.get_json()["data"]["id"]

    # 2. Tra cứu bằng ISBN
    res_isbn = client.get("/api/books/isbn/978-0131103627", headers=student_headers)
    assert res_isbn.status_code == 200
    assert res_isbn.get_json()["data"]["id"] == book_id

    # 3. Tìm kiếm theo từ khóa
    res_search = client.get("/api/books?q=Programming", headers=student_headers)
    assert res_search.status_code == 200
    assert any(b["id"] == book_id for b in res_search.get_json()["data"])

    # 4. Điều chỉnh số lượng kho
    res_qty = client.patch(f"/api/books/{book_id}/quantity", headers=librarian_headers, json={
        "change": 4, "reason": "Nhập thêm đợt 2"
    })
    assert res_qty.status_code == 200
    assert res_qty.get_json()["data"]["quantity"] == 12
    assert res_qty.get_json()["data"]["available_quantity"] == 12

    # 5. Cập nhật trạng thái sách
    res_status = client.patch(f"/api/books/{book_id}/status", headers=librarian_headers, json={
        "condition": "worn"
    })
    assert res_status.status_code == 200
    assert res_status.get_json()["data"]["condition"] == "worn"


def test_book_statistics(client, librarian_headers):
    res = client.get("/api/books/statistics", headers=librarian_headers)
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert "total_titles" in data
    assert "total_copies" in data
    assert "by_category" in data
    assert "by_condition" in data
