"""Kiểm thử quy trình Mượn - Trả - Gia hạn sách (M09 mở rộng)."""
import pytest
from app.models import Book


def test_borrow_and_return_cycle(client, librarian_headers, student_headers):
    # Kiểm tra số lượng sách ban đầu
    res_book = client.get("/api/books/1", headers=student_headers)
    avail_before = res_book.get_json()["data"]["available_quantity"]

    # 1. Thủ thư lập phiếu mượn cho sinh viên (id=3)
    res_borrow = client.post("/api/borrows", headers=librarian_headers, json={
        "user_id": 3,
        "book_id": 1,
        "days": 14,
        "note": "Mượn nghiên cứu",
    })
    assert res_borrow.status_code == 201
    borrow_id = res_borrow.get_json()["data"]["id"]

    # Số lượng sách có sẵn phải giảm đi 1
    res_book_after = client.get("/api/books/1", headers=student_headers)
    assert res_book_after.get_json()["data"]["available_quantity"] == avail_before - 1

    # 2. Sinh viên xem phiếu mượn của mình
    res_my = client.get("/api/borrows/my", headers=student_headers)
    assert res_my.status_code == 200
    assert any(b["id"] == borrow_id for b in res_my.get_json()["data"])

    # 3. Gia hạn mượn sách
    res_extend = client.put(f"/api/borrows/{borrow_id}/extend", headers=librarian_headers, json={"days": 7})
    assert res_extend.status_code == 200
    assert res_extend.get_json()["data"]["extend_count"] == 1

    # 4. Trả sách vào kho
    res_return = client.put(f"/api/borrows/{borrow_id}/return", headers=librarian_headers, json={
        "condition": "good", "note": "Đã trả xong"
    })
    assert res_return.status_code == 200
    assert res_return.get_json()["data"]["status"] == "returned"

    # Số lượng sách có sẵn phải hồi phục lại
    res_book_final = client.get("/api/books/1", headers=student_headers)
    assert res_book_final.get_json()["data"]["available_quantity"] == avail_before


def test_borrow_validation_duplicate_and_limits(client, librarian_headers):
    # Lập phiếu lần 1
    res1 = client.post("/api/borrows", headers=librarian_headers, json={
        "user_id": 4, "book_id": 2, "days": 10
    })
    assert res1.status_code == 201

    # Không được mượn cùng một cuốn sách khi chưa trả
    res2 = client.post("/api/borrows", headers=librarian_headers, json={
        "user_id": 4, "book_id": 2, "days": 10
    })
    assert res2.status_code == 409
    assert "đang mượn cuốn sách này" in res2.get_json()["message"]

