"""Kiểm thử phân hệ Xác thực, Tài khoản & Bảo mật (M20)."""
import pytest


def test_register_success(client):
    res = client.post("/api/auth/register", json={
        "username": "new_student",
        "password": "Password@123",
        "full_name": "Sinh viên Mới",
        "email": "new_student@test.com",
        "phone": "0912345678",
        "student_code": "SV999",
    })
    assert res.status_code == 201
    data = res.get_json()
    assert data["success"] is True
    assert data["data"]["username"] == "new_student"
    assert data["data"]["role"] == "Student"


def test_register_duplicate_username_and_email(client):
    # Trùng username
    res = client.post("/api/auth/register", json={
        "username": "sinhvien01",
        "password": "Password@123",
        "full_name": "Trùng Tên",
        "email": "unique@test.com",
    })
    assert res.status_code == 409

    # Trùng email
    res2 = client.post("/api/auth/register", json={
        "username": "unique_user",
        "password": "Password@123",
        "full_name": "Trùng Email",
        "email": "student1@test.com",
    })
    assert res2.status_code == 409


def test_login_success_and_fail(client):
    # Đăng nhập bằng username
    res = client.post("/api/auth/login", json={"username": "sinhvien01", "password": "Student@123"})
    assert res.status_code == 200
    data = res.get_json()
    assert "access_token" in data["data"]
    assert "refresh_token" in data["data"]

    # Đăng nhập bằng email
    res_email = client.post("/api/auth/login", json={"email": "student1@test.com", "password": "Student@123"})
    assert res_email.status_code == 200

    # Sai mật khẩu
    res_wrong = client.post("/api/auth/login", json={"username": "sinhvien01", "password": "WrongPassword"})
    assert res_wrong.status_code == 401


def test_account_lockout_after_multiple_failed_logins(client):
    username = "sinhvien02"
    # Thử sai 5 lần liên tiếp
    for _ in range(5):
        res = client.post("/api/auth/login", json={"username": username, "password": "WrongPassword"})
        assert res.status_code in (401, 403)

    # Lần thứ 6: Tài khoản phải bị khóa (403)
    res_locked = client.post("/api/auth/login", json={"username": username, "password": "Student@123"})
    assert res_locked.status_code == 403
    assert "tạm khóa" in res_locked.get_json()["message"]


def test_token_refresh(client):
    res = client.post("/api/auth/login", json={"username": "sinhvien01", "password": "Student@123"})
    refresh_token = res.get_json()["data"]["refresh_token"]

    res_refresh = client.post(
        "/api/auth/refresh",
        headers={"Authorization": f"Bearer {refresh_token}"}
    )
    assert res_refresh.status_code == 200
    assert "access_token" in res_refresh.get_json()["data"]


def test_profile_and_change_password(client, student_headers):
    # Xem hồ sơ
    res_me = client.get("/api/auth/me", headers=student_headers)
    assert res_me.status_code == 200
    assert res_me.get_json()["data"]["username"] == "sinhvien01"

    # Cập nhật hồ sơ
    res_up = client.put(
        "/api/auth/me",
        headers=student_headers,
        json={"full_name": "Student One Updated", "phone": "0999888777"}
    )
    assert res_up.status_code == 200
    assert res_up.get_json()["data"]["full_name"] == "Student One Updated"

    # Đổi mật khẩu
    res_pw = client.put(
        "/api/auth/change-password",
        headers=student_headers,
        json={"old_password": "Student@123", "new_password": "NewStudent@456"}
    )
    assert res_pw.status_code == 200

    # Đăng nhập lại với mật khẩu mới
    res_login_new = client.post("/api/auth/login", json={"username": "sinhvien01", "password": "NewStudent@456"})
    assert res_login_new.status_code == 200


def test_logout_and_revocation(client, student_headers):
    # Đăng xuất thu hồi token
    res_logout = client.post("/api/auth/logout", headers=student_headers)
    assert res_logout.status_code == 200

    # Dùng lại token cũ phải bị chặn (401)
    res_retry = client.get("/api/auth/me", headers=student_headers)
    assert res_retry.status_code == 401
    assert "thu hồi" in res_retry.get_json()["message"]
