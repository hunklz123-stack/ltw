"""Kiểm thử nhóm tính năng nâng cao tích hợp AI (Smart Search, Recommendations, Chatbot, Categorization)."""
import pytest


def test_ai_status(client, student_headers):
    res = client.get("/api/ai/status", headers=student_headers)
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert data["local_nlp"] is True
    assert "features" in data
    assert "smart-search" in data["features"]


def test_ai_smart_search(client, student_headers):
    # Tìm kiếm sách bằng câu hỏi tự nhiên
    res = client.post("/api/ai/smart-search", headers=student_headers, json={
        "query": "Tìm sách Python cơ bản cho người mới bắt đầu",
        "limit": 5,
    })
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert "results" in data
    assert len(data["results"]) >= 1
    # Cuốn "Lập trình Python từ Cơ bản đến Nâng cao" phải có điểm khớp cao
    top_book = data["results"][0]
    assert "Python" in top_book["book"]["title"]
    assert top_book["score"] > 0


def test_ai_recommendations(client, student_headers):
    res = client.get("/api/ai/recommendations", headers=student_headers)
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert "results" in data
    assert "strategy" in data


def test_ai_chatbot(client, student_headers):
    # Hỏi giờ mở cửa
    res_hours = client.post("/api/ai/chat", headers=student_headers, json={
        "message": "Thư viện mở cửa vào những khung giờ nào vậy ạ?"
    })
    assert res_hours.status_code == 200
    data_hours = res_hours.get_json()["data"]
    assert data_hours["intent"] == "hours"
    assert "Thứ 2" in data_hours["reply"]

    # Hỏi tìm sách
    res_search = client.post("/api/ai/chat", headers=student_headers, json={
        "message": "Thư viện có cuốn Clean Code không?"
    })
    assert res_search.status_code == 200
    data_search = res_search.get_json()["data"]
    assert data_search["intent"] == "search"
    assert "Clean Code" in data_search["reply"]


def test_ai_suggest_category(client, librarian_headers):
    res = client.post("/api/ai/suggest-category", headers=librarian_headers, json={
        "title": "Machine Learning and Deep Neural Networks with Python",
        "description": "Thực hành xây dựng mô hình AI và học sâu với TensorFlow"
    })
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert "suggested_categories" in data
    assert "suggested_keywords" in data
    assert any(k in ["machine learning", "ai", "python", "hoc may", "machine"] for k in data["suggested_keywords"])
