"""Kiểm thử ma trận phân quyền dựa trên vai trò (RBAC - Role-Based Access Control)."""
import pytest


def test_unauthenticated_access_blocked(client):
    endpoints = [
        ("GET", "/api/auth/me"),
        ("GET", "/api/users"),
        ("GET", "/api/books"),
        ("GET", "/api/categories"),
        ("GET", "/api/authors"),
        ("GET", "/api/resources"),
        ("GET", "/api/borrows"),
        ("GET", "/api/ai/status"),
        ("GET", "/api/system/dashboard"),
    ]
    for method, path in endpoints:
        res = client.open(path, method=method)
        assert res.status_code == 401, f"Endpoint {method} {path} should require authentication"


def test_student_forbidden_admin_endpoints(client, student_headers):
    admin_endpoints = [
        ("GET", "/api/users"),
        ("POST", "/api/users"),
        ("GET", "/api/roles"),
        ("GET", "/api/system/dashboard"),
        ("GET", "/api/system/audit-logs"),
        ("GET", "/api/system/export"),
    ]
    for method, path in admin_endpoints:
        res = client.open(path, method=method, headers=student_headers)
        assert res.status_code == 403, f"Student should not access {method} {path}"


def test_student_forbidden_staff_endpoints(client, student_headers):
    staff_endpoints = [
        ("POST", "/api/books"),
        ("POST", "/api/categories"),
        ("POST", "/api/authors"),
        ("POST", "/api/borrows"),
        ("GET", "/api/borrows/overdue"),
        ("POST", "/api/ai/suggest-category"),
    ]
    for method, path in staff_endpoints:
        res = client.open(path, method=method, headers=student_headers, json={})
        assert res.status_code == 403, f"Student should not access {method} {path}"


def test_librarian_permissions_and_restrictions(client, librarian_headers):
    # Thủ thư CÓ QUYỀN thêm sách/thể loại/tác giả/lập phiếu mượn
    res_cat = client.post("/api/categories", headers=librarian_headers, json={
        "name": "Kinh tế học", "description": "Sách kinh tế"
    })
    assert res_cat.status_code == 201

    # Nhưng thủ thư KHÔNG CÓ QUYỀN quản trị người dùng hoặc hệ thống
    res_users = client.get("/api/users", headers=librarian_headers)
    assert res_users.status_code == 403

    res_dash = client.get("/api/system/dashboard", headers=librarian_headers)
    assert res_dash.status_code == 403


def test_admin_full_access(client, admin_headers):
    # Admin có quyền xem dashboard
    res_dash = client.get("/api/system/dashboard", headers=admin_headers)
    assert res_dash.status_code == 200

    # Admin có quyền xem danh sách người dùng
    res_users = client.get("/api/users", headers=admin_headers)
    assert res_users.status_code == 200

    # Admin có quyền xem ma trận phân quyền
    res_roles = client.get("/api/roles/permissions", headers=admin_headers)
    assert res_roles.status_code == 200

