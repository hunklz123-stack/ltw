"""Kiểm thử phân hệ LMS/LCMS & Quản lý Tài nguyên học tập điện tử (M10)."""
import io
import pytest


def test_create_url_resource(client, librarian_headers, student_headers):
    # Tạo tài nguyên liên kết URL
    res = client.post("/api/resources", headers=librarian_headers, json={
        "title": "Tài liệu trực tuyến Python Official Docs",
        "resource_type": "link",
        "url": "https://docs.python.org/3/",
        "access_level": "public",
        "category_id": 1,
    })
    assert res.status_code == 201
    res_id = res.get_json()["data"]["id"]

    # Sinh viên có thể xem tài nguyên public
    res_stu = client.get(f"/api/resources/{res_id}", headers=student_headers)
    assert res_stu.status_code == 200
    assert res_stu.get_json()["data"]["title"] == "Tài liệu trực tuyến Python Official Docs"


def test_upload_and_download_resource_file(client, librarian_headers, student_headers):
    # Tải lên tệp tài liệu PDF giả lập
    fake_pdf = (io.BytesIO(b"%PDF-1.4 sample content for test"), "test_document.pdf")
    data = {
        "title": "Tài liệu kiểm thử PDF",
        "resource_type": "pdf",
        "access_level": "public",
        "file": fake_pdf,
    }
    res_up = client.post(
        "/api/resources",
        headers=librarian_headers,
        data=data,
        content_type="multipart/form-data"
    )
    assert res_up.status_code == 201
    res_data = res_up.get_json()["data"]
    res_id = res_data["id"]
    assert res_data["has_file"] is True

    # Sinh viên tải tệp
    res_down = client.get(f"/api/resources/{res_id}/download", headers=student_headers)
    assert res_down.status_code == 200
    assert b"%PDF-1.4" in res_down.data


def test_internal_resource_access_control(client, student_headers, librarian_headers):
    # Tạo tài nguyên nội bộ
    res_create = client.post("/api/resources", headers=librarian_headers, json={
        "title": "Đề thi nội bộ tuyệt mật",
        "resource_type": "document",
        "url": "https://internal.test.edu.vn/exam.pdf",
        "access_level": "internal",
    })
    assert res_create.status_code == 201
    res_id = res_create.get_json()["data"]["id"]

    # Sinh viên xem chi tiết tài nguyên nội bộ -> 404 (che giấu sự tồn tại tài nguyên bảo mật)
    res_stu = client.get(f"/api/resources/{res_id}", headers=student_headers)
    assert res_stu.status_code == 404

    # Sinh viên lấy danh sách tài nguyên -> Không thấy tài nguyên nội bộ
    res_list = client.get("/api/resources", headers=student_headers)
    assert res_list.status_code == 200
    assert all(r["access_level"] == "public" for r in res_list.get_json()["data"])

    # Thủ thư xem chi tiết tài nguyên nội bộ -> 200 OK
    res_lib = client.get(f"/api/resources/{res_id}", headers=librarian_headers)
    assert res_lib.status_code == 200
