"""Kiểm thử phân hệ Bảo mật, Vận hành & Giám sát hệ thống (M21)."""
import json
import pytest


def test_health_check_public(client):
    res = client.get("/api/system/health")
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert data["status"] == "ok"
    assert data["database"] == "ok"


def test_dashboard_metrics(client, admin_headers):
    res = client.get("/api/system/dashboard", headers=admin_headers)
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert "users" in data
    assert "books" in data
    assert "resources" in data
    assert "borrows" in data
    assert data["users"]["total"] >= 4
    assert data["books"]["titles"] >= 2


def test_audit_logs(client, admin_headers):
    res = client.get("/api/system/audit-logs", headers=admin_headers)
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert isinstance(data, list)


def test_export_data_json(client, admin_headers):
    res = client.get("/api/system/export", headers=admin_headers)
    assert res.status_code == 200
    assert res.mimetype == "application/json"
    data = json.loads(res.data.decode("utf-8"))
    assert "users" in data
    assert "books" in data
    assert "categories" in data
    assert "authors" in data


def test_cleanup_tokens(client, admin_headers):
    res = client.post("/api/system/cleanup-tokens", headers=admin_headers)
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert "deleted" in data

