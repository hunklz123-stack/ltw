"""Pytest fixtures cấu hình môi trường kiểm thử độc lập trên SQLite in-memory."""
import os
import sys
import shutil
import tempfile
import pytest

# Đảm bảo đường dẫn gốc của project luôn nằm trong sys.path
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Thiết lập biến môi trường trước khi import app
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["JWT_SECRET_KEY"] = "test-jwt-secret-key-at-least-32-chars-long"
os.environ["SECRET_KEY"] = "test-secret-key"
os.environ["MAX_LOGIN_ATTEMPTS"] = "5"
os.environ["LOCK_MINUTES"] = "15"

from app import create_app
from app.extensions import db
from app.models import (
    ROLE_ADMIN, ROLE_LIBRARIAN, ROLE_STUDENT,
    Role, User, Category, Author, Book, Resource, BorrowRecord
)


@pytest.fixture(scope="session")
def temp_upload_dir():
    dir_path = tempfile.mkdtemp(prefix="library_test_uploads_")
    yield dir_path
    shutil.rmtree(dir_path, ignore_errors=True)


@pytest.fixture
def app(temp_upload_dir):
    test_app = create_app()
    test_app.config.update({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
        "UPLOAD_FOLDER": temp_upload_dir,
        "MAX_LOGIN_ATTEMPTS": 5,
        "LOCK_MINUTES": 15,
    })

    with test_app.app_context():
        db.create_all()
        _seed_test_data()
        yield test_app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return test_app_client(app)


def test_app_client(app):
    return app.test_client()


def _seed_test_data():
    """Nạp dữ liệu cơ sở cho từng bài kiểm thử."""
    # 1. Roles
    r_admin = Role(name=ROLE_ADMIN, display_name="Quản trị viên", description="Toàn quyền")
    r_lib = Role(name=ROLE_LIBRARIAN, display_name="Thủ thư", description="Quản lý sách")
    r_stu = Role(name=ROLE_STUDENT, display_name="Sinh viên", description="Bạn đọc")
    db.session.add_all([r_admin, r_lib, r_stu])
    db.session.commit()

    # 2. Users
    admin = User(username="admin", full_name="Admin User", email="admin@test.com", role=r_admin, is_active=True)
    admin.set_password("Admin@123")

    librarian = User(username="thuthu", full_name="Librarian User", email="librarian@test.com", role=r_lib, is_active=True)
    librarian.set_password("Librarian@123")

    student1 = User(username="sinhvien01", full_name="Student One", email="student1@test.com", student_code="SV001", role=r_stu, is_active=True)
    student1.set_password("Student@123")

    student2 = User(username="sinhvien02", full_name="Student Two", email="student2@test.com", student_code="SV002", role=r_stu, is_active=True)
    student2.set_password("Student@123")

    db.session.add_all([admin, librarian, student1, student2])
    db.session.commit()

    # 3. Categories
    cat_it = Category(name="Công nghệ thông tin", description="Sách CNTT & Lập trình")
    cat_ai = Category(name="Trí tuệ nhân tạo", description="Sách AI & Machine Learning")
    db.session.add_all([cat_it, cat_ai])
    db.session.commit()

    # 4. Authors
    auth_bob = Author(name="Robert C. Martin", nationality="Mỹ", birth_year=1952)
    auth_long = Author(name="Phạm Thế Long", nationality="Việt Nam", birth_year=1954)
    db.session.add_all([auth_bob, auth_long])
    db.session.commit()

    # 5. Books
    book1 = Book(
        isbn="978-0132350884",
        title="Clean Code",
        description="Handbook of Agile Software Craftsmanship",
        publisher="Prentice Hall",
        publish_year=2008,
        language="Tiếng Anh",
        pages=464,
        category=cat_it,
        authors=[auth_bob],
        quantity=5,
        available_quantity=4,
        status="available",
        condition="good",
        location="Kệ A1",
        keywords="clean code, lap trinh, agile, nang cao",
    )
    book2 = Book(
        isbn="978-604-58-12345",
        title="Lập trình Python từ Cơ bản đến Nâng cao",
        description="Sách hướng dẫn học Python cho người mới bắt đầu",
        publisher="NXB KHKT",
        publish_year=2023,
        language="Tiếng Việt",
        pages=400,
        category=cat_it,
        authors=[auth_long],
        quantity=10,
        available_quantity=10,
        status="available",
        condition="new",
        location="Kệ B1",
        keywords="python, lap trinh python, co ban, nguoi moi bat dau",
    )
    db.session.add_all([book1, book2])
    db.session.commit()

    # 6. Resources
    res_pub = Resource(
        title="Slide Lập trình Python",
        resource_type="slide",
        url="https://test.edu.vn/python-slide.pdf",
        access_level="public",
        category=cat_it,
        book=book2,
        uploaded_by=admin.id,
    )
    res_int = Resource(
        title="Tài liệu nội bộ Thủ thư",
        resource_type="document",
        url="https://test.edu.vn/internal-guide.pdf",
        access_level="internal",
        category=cat_it,
        uploaded_by=admin.id,
    )
    db.session.add_all([res_pub, res_int])
    db.session.commit()


def get_token(client, username, password):
    res = client.post("/api/auth/login", json={"username": username, "password": password})
    assert res.status_code == 200, f"Login failed for {username}: {res.get_json()}"
    return res.get_json()["data"]["access_token"]


@pytest.fixture
def admin_headers(client):
    token = get_token(client, "admin", "Admin@123")
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def librarian_headers(client):
    token = get_token(client, "thuthu", "Librarian@123")
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def student_headers(client):
    token = get_token(client, "sinhvien01", "Student@123")
    return {"Authorization": f"Bearer {token}"}
