"""Cấu hình ứng dụng Web API quản lý hệ thống sách thư viện."""
import os
from datetime import timedelta
from urllib.parse import quote_plus

from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))


def _bool(value, default=False):
    if value is None:
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def build_odbc_string(database=None):
    """Tạo chuỗi kết nối ODBC tới Microsoft SQL Server từ biến môi trường."""
    server = os.getenv("DB_SERVER", "localhost")
    database = database or os.getenv("DB_NAME", "LibraryDB")
    driver = os.getenv("DB_DRIVER", "ODBC Driver 17 for SQL Server")
    user = os.getenv("DB_USER")
    password = os.getenv("DB_PASSWORD", "")
    trusted = _bool(os.getenv("DB_TRUSTED_CONNECTION"), default=not user)

    parts = [f"DRIVER={{{driver}}}", f"SERVER={server}", f"DATABASE={database}"]
    if trusted:
        parts.append("Trusted_Connection=yes")
    else:
        parts += [f"UID={user}", f"PWD={password}"]
    parts.append("TrustServerCertificate=yes")
    return ";".join(parts)


def build_database_uri():
    # Cho phép ghi đè toàn bộ bằng DATABASE_URL (ví dụ: sqlite:///test.db để chạy thử)
    url = os.getenv("DATABASE_URL")
    if url:
        return url
    return "mssql+pyodbc:///?odbc_connect=" + quote_plus(build_odbc_string())


class Config:
    # ---- Bảo mật ----
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-secret-key")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "change-me-jwt-secret-key-at-least-32-chars")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=int(os.getenv("JWT_ACCESS_MINUTES", "60")))
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=int(os.getenv("JWT_REFRESH_DAYS", "7")))
    MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
    LOCK_MINUTES = int(os.getenv("LOCK_MINUTES", "15"))
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*")

    # ---- Cơ sở dữ liệu ----
    DB_NAME = os.getenv("DB_NAME", "LibraryDB")
    SQLALCHEMY_DATABASE_URI = build_database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}

    # ---- Tài nguyên học tập (upload) ----
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", os.path.join(BASE_DIR, "uploads"))
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_UPLOAD_MB", "50")) * 1024 * 1024
    ALLOWED_EXTENSIONS = {
        "pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "txt", "epub",
        "mp4", "mp3", "zip", "rar", "png", "jpg", "jpeg",
    }

    # ---- Nghiệp vụ mượn - trả ----
    BORROW_DAYS = int(os.getenv("BORROW_DAYS", "14"))
    MAX_BORROW_BOOKS = int(os.getenv("MAX_BORROW_BOOKS", "5"))
    MAX_EXTEND_TIMES = int(os.getenv("MAX_EXTEND_TIMES", "2"))
    LIBRARY_OPEN_HOURS = os.getenv(
        "LIBRARY_OPEN_HOURS",
        "Thứ 2 - Thứ 6: 7h30 - 17h00; Thứ 7: 8h00 - 11h30; Chủ nhật nghỉ",
    )

    # ---- Sao lưu (thư mục trên máy chạy SQL Server) ----
    BACKUP_DIR = os.getenv("BACKUP_DIR", r"C:\LibraryBackups")

    # ---- AI (tùy chọn) ----
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

    # ---- Log ----
    LOG_DIR = os.getenv("LOG_DIR", os.path.join(BASE_DIR, "logs"))
