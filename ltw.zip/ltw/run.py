"""Entry point khởi chạy ứng dụng Flask Web API quản lý hệ thống sách thư viện."""
import os
import sys

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from app import create_app

app = create_app()

if __name__ == "__main__":
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "5000"))
    debug = os.getenv("FLASK_DEBUG", "True").strip().lower() in ("1", "true", "yes", "y", "on")

    print("=" * 70)
    print("  HỆ THỐNG WEB API QUẢN LÝ SÁCH THƯ VIỆN (LIBRARY MANAGEMENT API)")
    print("=" * 70)
    print(f"  * Máy chủ đang chạy tại : http://localhost:{port}")
    print(f"  * Địa chỉ mạng nội bộ   : http://{host}:{port}")
    print(f"  * Kiểm tra tình trạng   : http://localhost:{port}/api/system/health")
    print(f"  * Tài liệu API          : docs/API_DOCUMENTATION.md & Postman Collection")
    print("-" * 70)
    print("  Tài khoản kiểm thử mặc định:")
    print("    - Admin (Quản trị viên)   : admin      / Admin@123")
    print("    - Librarian (Thủ thư)     : thuthu     / Librarian@123")
    print("    - Student (Sinh viên)     : sinhvien01 / Student@123")
    print("=" * 70)

    app.run(host=host, port=port, debug=debug)
