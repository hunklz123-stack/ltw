"""Script khởi tạo CSDL và nạp dữ liệu mẫu (Seed Data) cho hệ thống thư viện.

Hỗ trợ:
  - Tự động tạo CSDL LibraryDB trên SQL Server nếu chưa có.
  - Tạo toàn bộ 11 bảng CSDL theo ORM Models.
  - Nạp 3 vai trò (Admin, Librarian, Student), tài khoản mẫu, thể loại, tác giả,
    kho sách phong phú (có từ khóa phục vụ AI), tài nguyên học tập và phiếu mượn mẫu.
  - Hỗ trợ cờ:
      --sqlite : Khởi tạo trên SQLite cục bộ (library.db) để test nhanh không cần SQL Server.
      --drop   : Xóa các bảng cũ trước khi tạo mới (chạy lại từ đầu).
"""
import argparse
import os
import sys
from datetime import datetime, timedelta

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from config import Config, build_odbc_string
from app import create_app
from app.extensions import db
from app.models import (
    ROLE_ADMIN, ROLE_LIBRARIAN, ROLE_STUDENT,
    Role, User, Category, Author, Book, Resource, BorrowRecord, AuditLog, SearchHistory, TokenBlocklist
)


def ensure_sql_server_database():
    """Tạo CSDL SQL Server nếu chưa tồn tại (chạy trên database 'master')."""
    db_name = os.getenv("DB_NAME", "LibraryDB")
    if os.getenv("DATABASE_URL") and not os.getenv("DATABASE_URL", "").startswith("mssql"):
        return

    try:
        import pyodbc
        master_conn_str = build_odbc_string(database="master")
        print(f"[*] Đang kết nối tới SQL Server để kiểm tra CSDL '{db_name}'...")
        conn = pyodbc.connect(master_conn_str, autocommit=True)
        cursor = conn.cursor()
        cursor.execute(f"IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'{db_name}') CREATE DATABASE [{db_name}];")
        cursor.close()
        conn.close()
        print(f"[+] CSDL '{db_name}' đã sẵn sàng trên Microsoft SQL Server.")
    except Exception as exc:
        print(f"[!] Chú ý: Không thể tự động tạo CSDL trên SQL Server ({exc}).")
        print("    Nếu bạn đang dùng SQL Server cục bộ, vui lòng đảm bảo SQL Server Browser & Service đang chạy,")
        print("    hoặc tạo CSDL 'LibraryDB' thủ công qua file database/schema.sql trong SSMS.")
        print("    Để chạy thử nghiệm trên SQLite độc lập, hãy truyền thêm cờ --sqlite.")


def seed_roles():
    """Khởi tạo 3 vai trò cơ sở."""
    roles_data = [
        {
            "name": ROLE_ADMIN,
            "display_name": "Quản trị viên",
            "description": "Toàn quyền quản trị hệ thống, tài khoản, phân quyền, cấu hình và giám sát",
        },
        {
            "name": ROLE_LIBRARIAN,
            "display_name": "Thủ thư",
            "description": "Quản lý sách, tác giả, thể loại, tài nguyên số và thực hiện nghiệp vụ mượn - trả",
        },
        {
            "name": ROLE_STUDENT,
            "display_name": "Sinh viên / Bạn đọc",
            "description": "Tra cứu sách, tài nguyên học tập công khai, mượn sách và tương tác với AI",
        },
    ]
    created = 0
    for r_info in roles_data:
        role = Role.query.filter_by(name=r_info["name"]).first()
        if not role:
            role = Role(**r_info)
            db.session.add(role)
            created += 1
    db.session.commit()
    print(f"[+] Vai trò: Đã kiểm tra/khởi tạo {created} vai trò mới.")


def seed_users():
    """Khởi tạo các tài khoản người dùng mẫu cho từng vai trò."""
    admin_role = Role.query.filter_by(name=ROLE_ADMIN).first()
    librarian_role = Role.query.filter_by(name=ROLE_LIBRARIAN).first()
    student_role = Role.query.filter_by(name=ROLE_STUDENT).first()

    users_data = [
        {
            "username": "admin",
            "password": "Admin@123",
            "full_name": "Quản trị viên Hệ thống",
            "email": "admin@library.edu.vn",
            "phone": "0901234567",
            "student_code": None,
            "role": admin_role,
        },
        {
            "username": "thuthu",
            "password": "Librarian@123",
            "full_name": "Nguyễn Thị Mai (Thủ thư)",
            "email": "thuthu@library.edu.vn",
            "phone": "0912345678",
            "student_code": None,
            "role": librarian_role,
        },
        {
            "username": "sinhvien01",
            "password": "Student@123",
            "full_name": "Trần Văn An",
            "email": "an.tv@student.edu.vn",
            "phone": "0987654321",
            "student_code": "SV20230001",
            "role": student_role,
        },
        {
            "username": "sinhvien02",
            "password": "Student@123",
            "full_name": "Lê Hoàng Bách",
            "email": "bach.lh@student.edu.vn",
            "phone": "0981112233",
            "student_code": "SV20230002",
            "role": student_role,
        },
    ]

    created = 0
    for u_info in users_data:
        user = User.query.filter_by(username=u_info["username"]).first()
        if not user:
            pw = u_info.pop("password")
            user = User(**u_info, is_active=True)
            user.set_password(pw)
            db.session.add(user)
            created += 1
    db.session.commit()
    print(f"[+] Tài khoản: Đã kiểm tra/khởi tạo {created} tài khoản người dùng mẫu.")


def seed_categories():
    """Khởi tạo danh mục thể loại sách."""
    categories_data = [
        ("Công nghệ thông tin & Lập trình", "Sách về thuật toán, cấu trúc dữ liệu, các ngôn ngữ lập trình Python, Java, C++, C#, JavaScript"),
        ("Trí tuệ nhân tạo & Khoa học dữ liệu", "Học máy (Machine Learning), Học sâu (Deep Learning), Xử lý ngôn ngữ tự nhiên, Big Data"),
        ("Mạng máy tính & An toàn thông tin", "Kiến trúc mạng máy tính, giao thức TCP/IP, bảo mật hệ thống, mật mã học"),
        ("Toán học & Khoa học cơ bản", "Giải tích, Đại số tuyến tính, Xác suất thống kê, Toán rời rạc ứng dụng"),
        ("Kinh tế & Quản trị kinh doanh", "Kinh tế vi mô, vĩ mô, quản trị dự án, tài chính doanh nghiệp và khởi nghiệp"),
        ("Ngoại ngữ & Kỹ năng mềm", "Tiếng Anh chuyên ngành, IELTS, kỹ năng giao tiếp, thuyết trình và đàm phán"),
        ("Kỹ nghệ phần mềm & Kiến trúc hệ thống", "Mô hình Agile/Scrum, thiết kế hướng đối tượng, vi dịch vụ (Microservices), Design Patterns"),
    ]
    created = 0
    for name, desc in categories_data:
        cat = Category.query.filter_by(name=name).first()
        if not cat:
            cat = Category(name=name, description=desc)
            db.session.add(cat)
            created += 1
    db.session.commit()
    print(f"[+] Thể loại: Đã kiểm tra/khởi tạo {created} thể loại.")


def seed_authors():
    """Khởi tạo danh sách tác giả nổi tiếng."""
    authors_data = [
        {"name": "Robert C. Martin", "nationality": "Mỹ", "birth_year": 1952, "biography": "Uncle Bob - Chuyên gia hàng đầu thế giới về kỹ nghệ phần mềm và Clean Code"},
        {"name": "Andrew S. Tanenbaum", "nationality": "Hà Lan", "birth_year": 1944, "biography": "Giáo sư khoa học máy tính, tác giả các giáo trình kinh điển về Hệ điều hành và Mạng máy tính"},
        {"name": "Stuart Russell", "nationality": "Anh", "birth_year": 1962, "biography": "Giáo sư Đại học UC Berkeley, đồng tác giả cuốn sách gối đầu giường Trí tuệ nhân tạo (AIMA)"},
        {"name": "Peter Norvig", "nationality": "Mỹ", "birth_year": 1956, "biography": "Nhà khoa học máy tính, Giám đốc nghiên cứu tại Google, đồng tác giả Artificial Intelligence: A Modern Approach"},
        {"name": "Martin Fowler", "nationality": "Anh", "birth_year": 1963, "biography": "Nhà tư tưởng kiến trúc phần mềm tại ThoughtWorks, tiên phong về Refactoring và Microservices"},
        {"name": "Donald E. Knuth", "nationality": "Mỹ", "birth_year": 1938, "biography": "Huyền thoại khoa học máy tính Stanford, tác giả bộ sách bất hủ The Art of Computer Programming"},
        {"name": "Đặng Văn Đức", "nationality": "Việt Nam", "birth_year": 1965, "biography": "Chuyên gia kỹ thuật phần mềm, tác giả giáo trình Phân tích thiết kế hệ thống hướng đối tượng UML"},
        {"name": "Phạm Thế Long", "nationality": "Việt Nam", "birth_year": 1954, "biography": "Giáo sư, Tiến sĩ khoa học, tác giả các giáo trình Giải thuật và Cấu trúc dữ liệu tại Việt Nam"},
        {"name": "Dale Carnegie", "nationality": "Mỹ", "birth_year": 1888, "biography": "Tác giả cuốn sách bất hủ Đắc nhân tâm và Nghệ thuật diễn thuyết"},
        {"name": "Nguyễn Nhật Ánh", "nationality": "Việt Nam", "birth_year": 1955, "biography": "Nhà văn thiếu nhi và thanh thiếu niên nổi tiếng hàng đầu Việt Nam"},
    ]
    created = 0
    for a_info in authors_data:
        auth = Author.query.filter_by(name=a_info["name"]).first()
        if not auth:
            auth = Author(**a_info)
            db.session.add(auth)
            created += 1
    db.session.commit()
    print(f"[+] Tác giả: Đã kiểm tra/khởi tạo {created} tác giả.")


def seed_books():
    """Khởi tạo kho sách phong phú kèm từ khóa phục vụ AI Smart Search."""
    cat_it = Category.query.filter(Category.name.like("%Công nghệ thông tin%")).first()
    cat_ai = Category.query.filter(Category.name.like("%Trí tuệ nhân tạo%")).first()
    cat_net = Category.query.filter(Category.name.like("%Mạng máy tính%")).first()
    cat_math = Category.query.filter(Category.name.like("%Toán học%")).first()
    cat_se = Category.query.filter(Category.name.like("%Kỹ nghệ phần mềm%")).first()
    cat_skill = Category.query.filter(Category.name.like("%Ngoại ngữ%")).first()

    auth_bob = Author.query.filter_by(name="Robert C. Martin").first()
    auth_tanen = Author.query.filter_by(name="Andrew S. Tanenbaum").first()
    auth_russell = Author.query.filter_by(name="Stuart Russell").first()
    auth_norvig = Author.query.filter_by(name="Peter Norvig").first()
    auth_fowler = Author.query.filter_by(name="Martin Fowler").first()
    auth_knuth = Author.query.filter_by(name="Donald E. Knuth").first()
    auth_duc = Author.query.filter_by(name="Đặng Văn Đức").first()
    auth_long = Author.query.filter_by(name="Phạm Thế Long").first()
    auth_carnegie = Author.query.filter_by(name="Dale Carnegie").first()

    books_data = [
        {
            "isbn": "978-0132350884",
            "title": "Clean Code: A Handbook of Agile Software Craftsmanship",
            "description": "Cuốn sách kinh điển hướng dẫn lập trình viên viết code sạch, dễ bảo trì, dễ hiểu và tái cấu trúc mã nguồn hiệu quả. Phù hợp cho lập trình viên từ cơ bản đến nâng cao.",
            "publisher": "Prentice Hall",
            "publish_year": 2008,
            "language": "Tiếng Anh",
            "pages": 464,
            "category": cat_se,
            "authors": [auth_bob] if auth_bob else [],
            "quantity": 10,
            "available_quantity": 8,
            "status": "available",
            "condition": "good",
            "location": "Kệ A1-01",
            "keywords": "clean code, agile, lap trinh, lap trinh sach, phan mem, nang cao, refactoring, code quality",
        },
        {
            "isbn": "978-0134494166",
            "title": "Clean Architecture: A Craftsman's Guide to Software Structure",
            "description": "Các quy tắc phổ quát về cấu trúc và kiến trúc phần mềm, quy tắc phụ thuộc, ranh giới kiến trúc và kiến trúc phân lớp hướng đối tượng.",
            "publisher": "Prentice Hall",
            "publish_year": 2017,
            "language": "Tiếng Anh",
            "pages": 432,
            "category": cat_se,
            "authors": [auth_bob] if auth_bob else [],
            "quantity": 8,
            "available_quantity": 7,
            "status": "available",
            "condition": "new",
            "location": "Kệ A1-02",
            "keywords": "kien truc phan mem, software architecture, clean architecture, thiet ke he thong, microservices",
        },
        {
            "isbn": "978-0136042594",
            "title": "Artificial Intelligence: A Modern Approach (4th Edition)",
            "description": "Giáo trình toàn diện và phổ biến nhất thế giới về trí tuệ nhân tạo, bao gồm tìm kiếm thông minh, logic suy luận, học máy, học sâu và robot học.",
            "publisher": "Pearson",
            "publish_year": 2020,
            "language": "Tiếng Anh",
            "pages": 1136,
            "category": cat_ai,
            "authors": [a for a in [auth_russell, auth_norvig] if a],
            "quantity": 12,
            "available_quantity": 9,
            "status": "available",
            "condition": "good",
            "location": "Kệ B2-05",
            "keywords": "tri tue nhan tao, ai, artificial intelligence, hoc may, machine learning, neural networks, robot",
        },
        {
            "isbn": "978-0132126953",
            "title": "Computer Networks (5th Edition)",
            "description": "Giáo trình mạng máy tính kinh điển phân tích sâu các tầng giao thức TCP/IP, định tuyến, bảo mật mạng, mạng không dây và truyền thông đa phương tiện.",
            "publisher": "Prentice Hall",
            "publish_year": 2011,
            "language": "Tiếng Anh",
            "pages": 960,
            "category": cat_net,
            "authors": [auth_tanen] if auth_tanen else [],
            "quantity": 15,
            "available_quantity": 12,
            "status": "available",
            "condition": "good",
            "location": "Kệ C1-03",
            "keywords": "mang may tinh, computer networks, tcp/ip, routing, internet, bao mat mang, protocol",
        },
        {
            "isbn": "978-0133591620",
            "title": "Modern Operating Systems (4th Edition)",
            "description": "Tổng quan toàn diện về nguyên lý hệ điều hành: quản lý tiến trình, luồng, bộ nhớ ảo, hệ thống tệp tin, đa xử lý và bảo mật hệ điều hành hiện đại.",
            "publisher": "Pearson",
            "publish_year": 2014,
            "language": "Tiếng Anh",
            "pages": 1136,
            "category": cat_it,
            "authors": [auth_tanen] if auth_tanen else [],
            "quantity": 7,
            "available_quantity": 5,
            "status": "available",
            "condition": "good",
            "location": "Kệ C1-04",
            "keywords": "he dieu hanh, operating system, linux, windows, process, memory management, file system",
        },
        {
            "isbn": "978-0201485677",
            "title": "Refactoring: Improving the Design of Existing Code",
            "description": "Kỹ thuật tái cấu trúc mã nguồn để cải thiện thiết kế mà không làm thay đổi hành vi bên ngoài. Cẩm nang không thể thiếu của kỹ sư phần mềm.",
            "publisher": "Addison-Wesley",
            "publish_year": 1999,
            "language": "Tiếng Anh",
            "pages": 464,
            "category": cat_se,
            "authors": [auth_fowler] if auth_fowler else [],
            "quantity": 6,
            "available_quantity": 6,
            "status": "available",
            "condition": "worn",
            "location": "Kệ A1-03",
            "keywords": "refactoring, design patterns, ma nguon, toi uu code, clean code, lap trinh huong doi tuong",
        },
        {
            "isbn": "978-0201896831",
            "title": "The Art of Computer Programming: Fundamental Algorithms (Vol 1)",
            "description": "Tác phẩm vĩ đại của Donald Knuth về các thuật toán cơ bản, cấu trúc dữ liệu tuyến tính, cây và phân tích độ phức tạp thuật toán.",
            "publisher": "Addison-Wesley",
            "publish_year": 1997,
            "language": "Tiếng Anh",
            "pages": 672,
            "category": cat_it,
            "authors": [auth_knuth] if auth_knuth else [],
            "quantity": 5,
            "available_quantity": 4,
            "status": "available",
            "condition": "good",
            "location": "Kệ A2-01",
            "keywords": "giai thuat, cau truc du lieu, algorithms, knuth, toan roi rac, co ban, nang cao",
        },
        {
            "isbn": "978-604-0-123456",
            "title": "Giáo trình Cấu trúc dữ liệu và Giải thuật",
            "description": "Giáo trình chuẩn cho sinh viên công nghệ thông tin: mảng, danh sách liên kết, ngăn xếp, hàng đợi, cây nhị phân, đồ thị và các thuật toán sắp xếp, tìm kiếm.",
            "publisher": "NXB Thông tin và Truyền thông",
            "publish_year": 2019,
            "language": "Tiếng Việt",
            "pages": 380,
            "category": cat_it,
            "authors": [auth_long] if auth_long else [],
            "quantity": 25,
            "available_quantity": 20,
            "status": "available",
            "condition": "good",
            "location": "Kệ D1-01",
            "keywords": "cau truc du lieu, giai thuat, algorithms, data structures, sap xep, tim kiem, co ban, c++",
        },
        {
            "isbn": "978-604-0-654321",
            "title": "Phân tích và Thiết kế Hệ thống Hướng đối tượng với UML",
            "description": "Phương pháp luận phân tích yêu cầu nghiệp vụ, mô hình hóa Use Case, biểu đồ lớp, biểu đồ tuần tự theo chuẩn UML phục vụ phát triển phần mềm doanh nghiệp.",
            "publisher": "NXB Giáo dục Việt Nam",
            "publish_year": 2018,
            "language": "Tiếng Việt",
            "pages": 320,
            "category": cat_se,
            "authors": [auth_duc] if auth_duc else [],
            "quantity": 18,
            "available_quantity": 15,
            "status": "available",
            "condition": "new",
            "location": "Kệ D1-02",
            "keywords": "uml, phan tich thiet ke, huong doi tuong, use case, oop, software engineering",
        },
        {
            "isbn": "978-604-58-12345",
            "title": "Lập trình Python từ Cơ bản đến Nâng cao",
            "description": "Sách hướng dẫn học lập trình Python toàn diện cho người mới bắt đầu: cú pháp, hướng đối tượng, xử lý dữ liệu với Pandas, NumPy, lập trình web với Flask và tự động hóa.",
            "publisher": "NXB Khoa học và Kỹ thuật",
            "publish_year": 2023,
            "language": "Tiếng Việt",
            "pages": 450,
            "category": cat_it,
            "authors": [auth_long] if auth_long else [],
            "quantity": 20,
            "available_quantity": 17,
            "status": "available",
            "condition": "new",
            "location": "Kệ D2-01",
            "keywords": "python, lap trinh python, co ban, nguoi moi bat dau, flask, data analysis, pandas",
        },
        {
            "isbn": "978-604-58-56789",
            "title": "Nhập môn Học máy và Khoa học Dữ liệu với Python",
            "description": "Thực hành xây dựng mô hình dự báo, hồi quy tuyến tính, phân cụm, cây quyết định và mạng nơ-ron nhân tạo sử dụng thư viện Scikit-learn và PyTorch.",
            "publisher": "NXB Đại học Quốc gia",
            "publish_year": 2024,
            "language": "Tiếng Việt",
            "pages": 410,
            "category": cat_ai,
            "authors": [auth_long] if auth_long else [],
            "quantity": 15,
            "available_quantity": 13,
            "status": "available",
            "condition": "new",
            "location": "Kệ B2-06",
            "keywords": "hoc may, machine learning, data science, python, scikit-learn, pytorch, nhap mon, ai",
        },
        {
            "isbn": "978-604-58-99999",
            "title": "Cơ sở Dữ liệu Quan hệ và Ngôn ngữ SQL",
            "description": "Lý thuyết chuẩn hóa cơ sở dữ liệu (1NF, 2NF, 3NF, BCNF), thiết kế lược đồ quan hệ ERD, truy vấn SQL từ cơ bản đến nâng cao trên Microsoft SQL Server.",
            "publisher": "NXB Thống Kê",
            "publish_year": 2022,
            "language": "Tiếng Việt",
            "pages": 360,
            "category": cat_it,
            "authors": [auth_duc] if auth_duc else [],
            "quantity": 20,
            "available_quantity": 18,
            "status": "available",
            "condition": "good",
            "location": "Kệ D2-02",
            "keywords": "co so du lieu, database, sql, sql server, quan he, truy van, chuan hoa, erd",
        },
        {
            "isbn": "978-0671027032",
            "title": "Đắc Nhân Tâm (How to Win Friends and Influence People)",
            "description": "Nghệ thuật đối nhân xử thế, giao tiếp và thuyết phục người khác. Cuốn sách gối đầu giường về kỹ năng mềm cho mọi sinh viên và người đi làm.",
            "publisher": "Simon & Schuster / NXB Tổng hợp TP.HCM",
            "publish_year": 2016,
            "language": "Tiếng Việt",
            "pages": 320,
            "category": cat_skill,
            "authors": [auth_carnegie] if auth_carnegie else [],
            "quantity": 30,
            "available_quantity": 25,
            "status": "available",
            "condition": "good",
            "location": "Kệ E1-01",
            "keywords": "dac nhan tam, ky nang mem, giao tiep, lanh dao, thuyet phuc, self-help",
        },
        {
            "isbn": "978-604-0-987654",
            "title": "Xác suất Thống kê và Ứng dụng trong Khoa học Máy tính",
            "description": "Cơ sở xác suất, biến ngẫu nhiên, các phân phối phổ biến, ước lượng tham số và kiểm định giả thuyết phục vụ học máy và trí tuệ nhân tạo.",
            "publisher": "NXB Giáo dục Việt Nam",
            "publish_year": 2021,
            "language": "Tiếng Việt",
            "pages": 290,
            "category": cat_math,
            "authors": [auth_long] if auth_long else [],
            "quantity": 14,
            "available_quantity": 12,
            "status": "available",
            "condition": "good",
            "location": "Kệ F1-01",
            "keywords": "toan, xac suat, thong ke, probability, statistics, ai, data science",
        },
    ]

    created = 0
    for b_info in books_data:
        book = Book.query.filter_by(isbn=b_info["isbn"]).first()
        if not book:
            authors = b_info.pop("authors")
            book = Book(**b_info)
            book.authors = authors
            db.session.add(book)
            created += 1
    db.session.commit()
    print(f"[+] Sách: Đã kiểm tra/khởi tạo {created} đầu sách mẫu.")


def seed_resources():
    """Khởi tạo tài nguyên học tập điện tử (M10 - LMS/LCMS)."""
    book_clean_code = Book.query.filter_by(isbn="978-0132350884").first()
    book_python = Book.query.filter_by(isbn="978-604-58-12345").first()
    book_sql = Book.query.filter_by(isbn="978-604-58-99999").first()
    cat_it = Category.query.filter(Category.name.like("%Công nghệ thông tin%")).first()

    resources_data = [
        {
            "title": "Slide bài giảng: Nguyên lý Lập trình Python & Clean Code",
            "description": "Bộ bài giảng điện tử 12 chương phục vụ học phần Lập trình nâng cao.",
            "resource_type": "slide",
            "url": "https://library.edu.vn/materials/python-clean-code-slides.pdf",
            "file_name": "python_clean_code_slides.pdf",
            "file_size": 4520000,
            "mime_type": "application/pdf",
            "book": book_python,
            "category": cat_it,
            "access_level": "public",
            "uploaded_by": 1,
            "download_count": 42,
        },
        {
            "title": "Tài liệu thực hành: Truy vấn SQL trên Microsoft SQL Server",
            "description": "Hướng dẫn thực hành viết câu lệnh SELECT, JOIN, GROUP BY, Subquery và Transaction.",
            "resource_type": "pdf",
            "url": "https://library.edu.vn/materials/sql-server-lab-manual.pdf",
            "file_name": "sql_server_lab_manual.pdf",
            "file_size": 2850000,
            "mime_type": "application/pdf",
            "book": book_sql,
            "category": cat_it,
            "access_level": "public",
            "uploaded_by": 1,
            "download_count": 68,
        },
        {
            "title": "Video bài giảng: Phân tích kiến trúc Clean Architecture",
            "description": "Video ghi hình bài giảng chuyên sâu về thiết kế phần mềm hướng dịch vụ.",
            "resource_type": "video",
            "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "file_name": None,
            "file_size": 0,
            "mime_type": "video/mp4",
            "book": book_clean_code,
            "category": cat_it,
            "access_level": "public",
            "uploaded_by": 2,
            "download_count": 19,
        },
        {
            "title": "Đề cương & Ngân hàng câu hỏi thi môn Cơ sở dữ liệu (Nội bộ)",
            "description": "Tài liệu ngân hàng đề thi lưu hành nội bộ dành cho giảng viên và thủ thư thẩm định.",
            "resource_type": "document",
            "url": "https://library.edu.vn/internal/exam-bank-databases-2026.docx",
            "file_name": "exam_bank_databases_2026.docx",
            "file_size": 1200000,
            "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "book": book_sql,
            "category": cat_it,
            "access_level": "internal",
            "uploaded_by": 1,
            "download_count": 5,
        },
    ]

    created = 0
    for res_info in resources_data:
        res = Resource.query.filter_by(title=res_info["title"]).first()
        if not res:
            res = Resource(**res_info)
            db.session.add(res)
            created += 1
    db.session.commit()
    print(f"[+] Tài nguyên học tập: Đã kiểm tra/khởi tạo {created} tài nguyên mẫu.")


def seed_borrow_records():
    """Khởi tạo một số phiếu mượn mẫu (đang mượn, đã trả, quá hạn)."""
    if BorrowRecord.query.count() > 0:
        print("[+] Phiếu mượn: Đã có sẵn dữ liệu, bỏ qua seed phiếu mượn.")
        return

    user_an = User.query.filter_by(username="sinhvien01").first()
    user_bach = User.query.filter_by(username="sinhvien02").first()
    book_clean_code = Book.query.filter_by(isbn="978-0132350884").first()
    book_python = Book.query.filter_by(isbn="978-604-58-12345").first()
    book_ai = Book.query.filter_by(isbn="978-0136042594").first()

    if not user_an or not book_clean_code or not book_python:
        return

    now_dt = datetime.now()
    records_data = [
        # Phiếu 1: Đang mượn hợp lệ (hạn còn 10 ngày)
        {
            "user_id": user_an.id,
            "book_id": book_clean_code.id,
            "borrow_date": now_dt - timedelta(days=4),
            "due_date": now_dt + timedelta(days=10),
            "return_date": None,
            "status": "borrowing",
            "extend_count": 0,
            "note": "Mượn phục vụ làm đồ án chuyên ngành",
            "processed_by": 2,
        },
        # Phiếu 2: Đã trả đúng hạn
        {
            "user_id": user_an.id,
            "book_id": book_python.id,
            "borrow_date": now_dt - timedelta(days=20),
            "due_date": now_dt - timedelta(days=6),
            "return_date": now_dt - timedelta(days=7),
            "status": "returned",
            "extend_count": 0,
            "note": "Sách trả nguyên vẹn, tình trạng tốt",
            "processed_by": 2,
        },
        # Phiếu 3: Quá hạn mượn (due_date đã qua 5 ngày trước)
        {
            "user_id": user_bach.id,
            "book_id": book_ai.id,
            "borrow_date": now_dt - timedelta(days=20),
            "due_date": now_dt - timedelta(days=5),
            "return_date": None,
            "status": "borrowing",
            "extend_count": 1,
            "note": "Đã gửi thông báo nhắc trả sách lần 1",
            "processed_by": 2,
        },
    ]

    created = 0
    for r_info in records_data:
        exists = BorrowRecord.query.filter_by(
            user_id=r_info["user_id"], book_id=r_info["book_id"], borrow_date=r_info["borrow_date"]
        ).first()
        if not exists:
            rec = BorrowRecord(**r_info)
            db.session.add(rec)
            created += 1
    db.session.commit()
    print(f"[+] Phiếu mượn: Đã kiểm tra/khởi tạo {created} phiếu mượn mẫu.")


def seed_audit_logs():
    """Ghi nhận nhật ký kiểm toán khởi tạo ban đầu."""
    if AuditLog.query.count() == 0:
        db.session.add(AuditLog(
            user_id=1,
            username="admin",
            action="SYSTEM_INIT",
            entity="Database",
            entity_id="All",
            details='{"message": "Khởi tạo hệ thống CSDL thư viện và nạp dữ liệu mẫu ban đầu"}',
            ip_address="127.0.0.1",
        ))
        db.session.commit()
        print("[+] Nhật ký kiểm toán: Đã tạo bản ghi SYSTEM_INIT.")


def main():
    parser = argparse.ArgumentParser(description="Khởi tạo CSDL và nạp dữ liệu mẫu cho hệ thống thư viện")
    parser.add_argument("--sqlite", action="store_true", help="Sử dụng SQLite cục bộ (library.db) thay vì SQL Server")
    parser.add_argument("--drop", action="store_true", help="Xóa các bảng cũ trước khi tạo lại")
    args = parser.parse_args()

    if args.sqlite:
        sqlite_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "library.db"))
        sqlite_uri = f"sqlite:///{sqlite_path}"
        os.environ["DATABASE_URL"] = sqlite_uri
        Config.SQLALCHEMY_DATABASE_URI = sqlite_uri
        print(f"[*] Cấu hình chế độ SQLite: {sqlite_uri}")
    else:
        # Thử đảm bảo database trên SQL Server
        ensure_sql_server_database()

    app = create_app()

    with app.app_context():
        if args.drop:
            print("[*] Đang xóa các bảng CSDL cũ (--drop)...")
            db.drop_all()
            print("[+] Đã xóa toàn bộ bảng cũ.")

        print("[*] Đang tạo các bảng CSDL theo ORM Models...")
        db.create_all()
        print("[+] Đã tạo cấu trúc các bảng CSDL thành công.")

        print("[*] Bắt đầu nạp dữ liệu mẫu (Seeding)...")
        seed_roles()
        seed_users()
        seed_categories()
        seed_authors()
        seed_books()
        seed_resources()
        seed_borrow_records()
        seed_audit_logs()

        print("=" * 70)
        print("  HOÀN THÀNH KHỞI TẠO CƠ SỞ DỮ LIỆU & DỮ LIỆU MẪU!")
        print("=" * 70)
        print("  Tổng hợp dữ liệu khởi tạo:")
        print(f"    - Vai trò (Roles)       : {Role.query.count()} vai trò (Admin, Librarian, Student)")
        print(f"    - Người dùng (Users)    : {User.query.count()} tài khoản")
        print(f"    - Thể loại (Categories) : {Category.query.count()} thể loại")
        print(f"    - Tác giả (Authors)     : {Author.query.count()} tác giả")
        print(f"    - Đầu sách (Books)      : {Book.query.count()} đầu sách")
        print(f"    - Tài nguyên số         : {Resource.query.count()} tài nguyên")
        print(f"    - Phiếu mượn            : {BorrowRecord.query.count()} phiếu mượn")
        print("=" * 70)


if __name__ == "__main__":
    main()
