# ĐẶC TẢ CHI TIẾT CÁC WEB API QUẢN LÝ HỆ THỐNG SÁCH THƯ VIỆN

**Tên đề tài:** Xây dựng Web API quản lý hệ thống sách thư viện  
**Công nghệ:** Python, Flask, SQLAlchemy, Microsoft SQL Server (`pyodbc`), Flask-JWT-Extended, JSON, Postman  
**Phiên bản API:** `v1.0.0`  
**Base URL:** `http://localhost:5000` (hoặc `http://<server-ip>:5000`)  
**Định dạng dữ liệu:** `application/json` (Encoding: UTF-8)

---

## MỤC LỤC
1. [Quy ước Chuẩn hóa Dữ liệu & Mã lỗi HTTP](#1-quy-ước-chuẩn-hóa-dữ-liệu--mã-lỗi-http)
2. [Ma trận Phân quyền theo Vai trò (RBAC)](#2-ma-trận-phân-quyền-theo-vai-trò-rbac)
3. [Phân hệ 01: Xác thực & Hồ sơ cá nhân (`/api/auth`)](#3-phân-hệ-01-xác-thực--hồ-sơ-cá-nhân-apiauth)
4. [Phân hệ 02: Quản lý Người dùng & Tài khoản (`/api/users`)](#4-phân-hệ-02-quản-lý-người-dùng--tài-khoản-apiusers)
5. [Phân hệ 03: Vai trò & Phân quyền (`/api/roles`)](#5-phân-hệ-03-vai-trò--phân-quyền-apiroles)
6. [Phân hệ 04: Quản lý Thể loại sách (`/api/categories`)](#6-phân-hệ-04-quản-lý-thể-loại-sách-apicategories)
7. [Phân hệ 05: Quản lý Tác giả (`/api/authors`)](#7-phân-hệ-05-quản-lý-tác-giả-apiauthors)
8. [Phân hệ 06: Quản lý Sách & Kho tài sản (`/api/books` - M09)](#8-phân-hệ-06-quản-lý-sách--kho-tài-sản-apibooks---m09)
9. [Phân hệ 07: Tài nguyên học tập điện tử (`/api/resources` - M10)](#9-phân-hệ-07-tài-nguyên-học-tập-điện-tử-apiresources---m10)
10. [Phân hệ 08: Phiếu Mượn - Trả sách (`/api/borrows` - M09)](#10-phân-hệ-08-phiếu-mượn---trả-sách-apiborrows---m09)
11. [Phân hệ 09: Tính năng AI nâng cao (`/api/ai`)](#11-phân-hệ-09-tính-năng-ai-nâng-cao-apiai)
12. [Phân hệ 10: Vận hành, An ninh & Giám sát (`/api/system` - M21)](#12-phân-hệ-10-vận-hành-an-ninh--giám-sát-apisystem---m21)

---

## 1. Quy ước Chuẩn hóa Dữ liệu & Mã lỗi HTTP

Mọi phản hồi từ hệ thống đều tuân thủ cấu trúc JSON tiêu chuẩn sau:

### Phản hồi thành công (200 OK / 201 Created):
```json
{
  "success": true,
  "message": "Thông điệp mô tả kết quả xử lý (nếu có)",
  "data": { ... } // hoặc mảng dữ liệu [...]
}
```

### Phản hồi phân trang (Paginated Response):
```json
{
  "success": true,
  "data": [ ... ],
  "pagination": {
    "page": 1,
    "per_page": 10,
    "total": 52,
    "pages": 6,
    "has_next": true,
    "has_prev": false
  }
}
```

### Phản hồi lỗi (Error Response):
```json
{
  "success": false,
  "message": "Nội dung thông báo lỗi bằng tiếng Việt",
  "data": null,
  "errors": { ... } // Thông tin lỗi chi tiết (nếu có, ví dụ missing_fields)
}
```

### Bảng mã trạng thái HTTP sử dụng:
| Mã HTTP | Tên chuẩn | Ý nghĩa trong hệ thống |
| :---: | :--- | :--- |
| **`200`** | OK | Truy vấn thành công, cập nhật hoặc xóa hoàn tất. |
| **`201`** | Created | Thêm mới tài nguyên thành công (sách, người dùng, phiếu mượn...). |
| **`400`** | Bad Request | Dữ liệu gửi lên sai định dạng, thiếu trường bắt buộc, vi phạm validation. |
| **`401`** | Unauthorized | Thiếu Bearer Token, token sai hoặc đã hết hạn / bị thu hồi khi đăng xuất. |
| **`403`** | Forbidden | Tài khoản không đủ quyền hạn vai trò (RBAC) hoặc đang bị khóa. |
| **`404`** | Not Found | Không tìm thấy ID tài nguyên được yêu cầu. |
| **`409`** | Conflict | Trùng khóa duy nhất (username, email, ISBN) hoặc vi phạm ràng buộc toàn vẹn. |
| **`413`** | Payload Too Large | Tệp tải lên vượt quá giới hạn tối đa cấu hình (`MAX_UPLOAD_MB`). |
| **`500`** | Internal Server Error | Lỗi nội bộ máy chủ; rollback giao dịch và ghi log chi tiết vào `logs/app.log`. |

---

## 2. Ma trận Phân quyền theo Vai trò (RBAC)

Hệ thống định nghĩa 3 vai trò người dùng chuẩn hóa:

| Nhóm chức năng | Student (Sinh viên / Bạn đọc) | Librarian (Thủ thư) | Admin (Quản trị viên) |
| :--- | :---: | :---: | :---: |
| **Đăng ký, Đăng nhập, Hồ sơ cá nhân** | Toàn quyền | Toàn quyền | Toàn quyền |
| **Xem sách, tác giả, thể loại** | Có | Có | Có |
| **Thêm, sửa, xóa sách, tác giả, thể loại** | Không | Toàn quyền | Toàn quyền |
| **Xem tài nguyên học tập công khai (`public`)** | Có | Có | Có |
| **Xem tài nguyên học tập nội bộ (`internal`)** | Không | Có | Có |
| **Upload / Quản lý tài nguyên học tập** | Không | Toàn quyền | Toàn quyền |
| **Xem phiếu mượn của chính mình** | Có | Có | Có |
| **Lập phiếu mượn, Trả sách, Gia hạn** | Không | Toàn quyền | Toàn quyền |
| **Tính năng AI (Tìm kiếm, Chatbot, Gợi ý)** | Có | Có | Có |
| **AI Gợi ý thể loại & từ khóa** | Không | Có | Có |
| **Quản trị người dùng & Phân quyền** | Không | Không | Toàn quyền |
| **Bảng điều khiển (Dashboard) & Audit Log** | Không | Không | Toàn quyền |
| **Sao lưu CSDL (.bak) & Xuất dữ liệu** | Không | Không | Toàn quyền |

---

## 3. Phân hệ 01: Xác thực & Hồ sơ cá nhân (`/api/auth`)

### 3.1. Đăng ký tài khoản sinh viên
- **Endpoint:** `POST /api/auth/register`
- **Quyền:** `Public`
- **Request Body:**
```json
{
  "username": "sinhvien_test",
  "password": "Student@123",
  "full_name": "Nguyễn Hoàng Nam",
  "email": "nam.nh@student.edu.vn",
  "phone": "0988776655",
  "student_code": "SV20269999"
}
```
- **Response (201 Created):**
```json
{
  "success": true,
  "message": "Đăng ký tài khoản thành công",
  "data": {
    "id": 5,
    "username": "sinhvien_test",
    "full_name": "Nguyễn Hoàng Nam",
    "email": "nam.nh@student.edu.vn",
    "phone": "0988776655",
    "student_code": "SV20269999",
    "role": "Student",
    "is_active": true
  }
}
```

### 3.2. Đăng nhập hệ thống
- **Endpoint:** `POST /api/auth/login`
- **Quyền:** `Public`
- **Request Body:**
```json
{
  "username": "sinhvien01",
  "password": "Student@123"
}
```
*(Có thể truyền `"email": "an.tv@student.edu.vn"` thay cho `"username"`).*
- **Response (200 OK):**
```json
{
  "success": true,
  "message": null,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "expires_in": 3600,
    "user": {
      "id": 3,
      "username": "sinhvien01",
      "full_name": "Trần Văn An",
      "role": "Student"
    }
  }
}
```

### 3.3. Làm mới Access Token
- **Endpoint:** `POST /api/auth/refresh`
- **Quyền:** Yêu cầu Header `Authorization: Bearer <refresh_token>`
- **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "expires_in": 3600
  }
}
```

### 3.4. Xem hồ sơ cá nhân
- **Endpoint:** `GET /api/auth/me`
- **Quyền:** Đã đăng nhập (`Student`, `Librarian`, `Admin`)
- **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": 3,
    "username": "sinhvien01",
    "full_name": "Trần Văn An",
    "email": "an.tv@student.edu.vn",
    "phone": "0987654321",
    "student_code": "SV20230001",
    "role": "Student",
    "is_active": true
  }
}
```

### 3.5. Cập nhật hồ sơ cá nhân
- **Endpoint:** `PUT /api/auth/me`
- **Quyền:** Đã đăng nhập
- **Request Body:**
```json
{
  "full_name": "Trần Văn An (Cập nhật)",
  "phone": "0987000111"
}
```

### 3.6. Đổi mật khẩu
- **Endpoint:** `PUT /api/auth/change-password`
- **Quyền:** Đã đăng nhập
- **Request Body:**
```json
{
  "old_password": "Student@123",
  "new_password": "NewStudent@456"
}
```

### 3.7. Đăng xuất (Thu hồi Token)
- **Endpoint:** `POST /api/auth/logout`
- **Quyền:** Đã đăng nhập
- **Ghi chú:** JTI của JWT hiện tại được lưu vào bảng `TokenBlocklist`, ngăn chặn sử dụng lại token cũ.

---

## 4. Phân hệ 02: Quản lý Người dùng & Tài khoản (`/api/users`)
*Tất cả endpoints yêu cầu quyền **Admin**.*

### 4.1. Danh sách người dùng (Phân trang & Lọc)
- **Endpoint:** `GET /api/users`
- **Query Parameters:**
  - `page`: Số trang (mặc định: `1`)
  - `per_page`: Số bản ghi/trang (mặc định: `10`, tối đa `100`)
  - `q`: Tìm kiếm theo username, họ tên, email, mã sinh viên
  - `role`: Lọc vai trò (`Admin`, `Librarian`, `Student`)
  - `is_active`: `true` hoặc `false`

### 4.2. Chi tiết người dùng theo ID
- **Endpoint:** `GET /api/users/<id>`

### 4.3. Tạo tài khoản người dùng mới
- **Endpoint:** `POST /api/users`
- **Request Body:**
```json
{
  "username": "thuthu_moi",
  "password": "Librarian@123",
  "full_name": "Trần Thị Thu Hà",
  "email": "ha.tt@library.edu.vn",
  "phone": "0934567890",
  "role": "Librarian",
  "is_active": true
}
```

### 4.4. Cập nhật thông tin người dùng
- **Endpoint:** `PUT /api/users/<id>`
- **Request Body:** Các trường `full_name`, `email`, `phone`, `student_code`, `is_active`.

### 4.5. Đổi vai trò người dùng
- **Endpoint:** `PATCH /api/users/<id>/role`
- **Request Body:** `{"role": "Librarian"}` hoặc `{"role_id": 2}`.

### 4.6. Khóa / Mở khóa tài khoản
- **Endpoint:** `PATCH /api/users/<id>/status`
- **Request Body:**
```json
{
  "is_active": true,
  "unlock": true
}
```

### 4.7. Đặt lại mật khẩu (Reset Password)
- **Endpoint:** `POST /api/users/<id>/reset-password`
- **Request Body:** `{"new_password": "NewSecret@123"}` (nếu bỏ trống hệ thống tự sinh ngẫu nhiên).

### 4.8. Xóa tài khoản
- **Endpoint:** `DELETE /api/users/<id>`
- **Ghi chú:** Không cho phép xóa Admin hiện tại hoặc người dùng đã phát sinh phiếu mượn (trả mã 409).

---

## 5. Phân hệ 03: Vai trò & Phân quyền (`/api/roles`)
*Tất cả endpoints yêu cầu quyền **Admin**.*

- `GET /api/roles`: Danh sách vai trò kèm số lượng user trực thuộc.
- `GET /api/roles/permissions`: Ma trận phân quyền chi tiết của 3 vai trò.
- `GET /api/roles/<id>`: Chi tiết vai trò kèm danh sách quyền hạn.
- `PUT /api/roles/<id>`: Cập nhật tên hiển thị (`display_name`) và mô tả (`description`).

---

## 6. Phân hệ 04: Quản lý Thể loại sách (`/api/categories`)

- `GET /api/categories`: Danh sách thể loại (kèm số đầu sách `book_count`). Lọc theo `?q=...`. *(Đã đăng nhập).*
- `GET /api/categories/<id>`: Chi tiết thể loại. *(Đã đăng nhập).*
- `GET /api/categories/<id>/books`: Danh sách sách thuộc thể loại đó (có phân trang). *(Đã đăng nhập).*
- `POST /api/categories`: Thêm thể loại mới. *(Librarian, Admin).*
```json
{
  "name": "Kỹ thuật phần mềm & Kiến trúc hệ thống",
  "description": "Sách về Design Patterns, Microservices, Clean Architecture"
}
```
- `PUT /api/categories/<id>`: Cập nhật thể loại. *(Librarian, Admin).*
- `DELETE /api/categories/<id>?force=true`: Xóa thể loại. Nếu đang có sách gắn với thể loại, cần truyền `?force=true` để gỡ liên kết (không xóa sách). *(Librarian, Admin).*

---

## 7. Phân hệ 05: Quản lý Tác giả (`/api/authors`)

- `GET /api/authors`: Danh sách tác giả. Hỗ trợ lọc theo `?q=...`, `?nationality=...`. *(Đã đăng nhập).*
- `GET /api/authors/<id>`: Chi tiết tác giả và danh sách các đầu sách của tác giả. *(Đã đăng nhập).*
- `POST /api/authors`: Thêm tác giả mới. *(Librarian, Admin).*
```json
{
  "name": "Robert C. Martin",
  "nationality": "Mỹ",
  "birth_year": 1952,
  "biography": "Uncle Bob - Tác giả Clean Code"
}
```
- `PUT /api/authors/<id>`: Cập nhật thông tin tác giả. *(Librarian, Admin).*
- `DELETE /api/authors/<id>?force=true`: Xóa tác giả. *(Librarian, Admin).*

---

## 8. Phân hệ 06: Quản lý Sách & Kho tài sản (`/api/books` - M09)

### 8.1. Danh sách & Lọc sách đa tiêu chí
- **Endpoint:** `GET /api/books`
- **Quyền:** Đã đăng nhập
- **Query Parameters:**
  - `page`, `per_page`: Phân trang
  - `q`: Tìm kiếm theo tên sách, ISBN, mô tả, từ khóa
  - `category_id`: Lọc theo thể loại
  - `author_id`: Lọc theo tác giả
  - `status`: `available`, `out_of_stock`, `discontinued`
  - `condition`: `new`, `good`, `worn`, `damaged`
  - `language`: `Tiếng Việt`, `Tiếng Anh`
  - `year_from`, `year_to`: Lọc năm xuất bản
  - `sort`: Sắp xếp theo `title`, `publish_year`, `quantity`, `available_quantity`, `created_at`
  - `order`: `asc` hoặc `desc`

### 8.2. Chi tiết sách theo ID / ISBN
- `GET /api/books/<id>`: Chi tiết sách, danh sách tác giả, thể loại, tài nguyên điện tử đính kèm.
- `GET /api/books/isbn/<isbn>`: Tra cứu sách bằng mã ISBN chuẩn.

### 8.3. Thống kê kho sách
- **Endpoint:** `GET /api/books/statistics`
- **Quyền:** `Librarian`, `Admin`
- **Dữ liệu trả về:** Tổng số đầu sách, tổng số bản sách, số bản còn trong kho, số bản đang mượn, cơ cấu theo thể loại, tình trạng vật lý, danh sách sách sắp hết hàng (`low_stock`) và top sách được mượn nhiều nhất (`top_borrowed`).

### 8.4. Thêm sách mới
- **Endpoint:** `POST /api/books`
- **Quyền:** `Librarian`, `Admin`
- **Request Body:**
```json
{
  "isbn": "978-0132350884",
  "title": "Clean Code: A Handbook of Agile Software Craftsmanship",
  "description": "Sách kinh điển về lập trình sạch",
  "publisher": "Prentice Hall",
  "publish_year": 2008,
  "language": "Tiếng Anh",
  "pages": 464,
  "category_id": 7,
  "authors": ["Robert C. Martin"],
  "quantity": 10,
  "location": "Kệ A1-01",
  "keywords": "clean code, agile, lap trinh, nang cao",
  "condition": "good"
}
```

### 8.5. Cập nhật thông tin sách
- **Endpoint:** `PUT /api/books/<id>`
- **Quyền:** `Librarian`, `Admin`
- **Ghi chú:** Chặn sửa tay `available_quantity` nhằm đảm bảo tính nhất quán kho.

### 8.6. Điều chỉnh số lượng kho (Nhập thêm / Thanh lý)
- **Endpoint:** `PATCH /api/books/<id>/quantity`
- **Quyền:** `Librarian`, `Admin`
- **Request Body:**
```json
{
  "change": 5,
  "reason": "Nhập thêm 5 bản từ nguồn tài trợ"
}
```
*(Hoặc truyền `{"quantity": 15}` để ấn định tổng số lượng mới).*

### 8.7. Cập nhật trạng thái & Tình trạng sách
- **Endpoint:** `PATCH /api/books/<id>/status`
- **Request Body:** `{"condition": "worn", "status": "available"}`.

### 8.8. Xóa sách
- **Endpoint:** `DELETE /api/books/<id>`
- **Ghi chú:** Nếu sách đã có lịch sử mượn trả, hệ thống chặn xóa (mã 409) và yêu cầu chuyển sang trạng thái `discontinued`.

---

## 9. Phân hệ 07: Tài nguyên học tập điện tử (`/api/resources` - M10)

- `GET /api/resources`: Danh sách tài nguyên học tập điện tử (ebook, slide, pdf, video, link). *Sinh viên chỉ thấy tài nguyên `public`; Thủ thư và Admin thấy cả `public` và `internal`.*
- `GET /api/resources/<id>`: Xem chi tiết tài nguyên. Nếu sinh viên truy cập tài nguyên `internal`, hệ thống trả mã `404 Not Found` để che giấu tài nguyên nhạy cảm.
- `GET /api/resources/<id>/download`: Tải tệp tài liệu điện tử và tự động tăng lượt tải (`download_count`).
- `POST /api/resources`: Thêm tài nguyên mới. *(Librarian, Admin).*
  - Hỗ trợ gửi `application/json` (cho tài nguyên URL / link ngoài).
  - Hỗ trợ gửi `multipart/form-data` kèm trường `file` (cho tải tệp trực tiếp lên hệ thống).
- `PUT /api/resources/<id>`: Cập nhật tài nguyên hoặc thay thế tệp cũ. *(Librarian, Admin).*
- `DELETE /api/resources/<id>`: Xóa tài nguyên và tự động dọn tệp vật lý trên đĩa. *(Librarian, Admin).*

---

## 10. Phân hệ 08: Phiếu Mượn - Trả sách (`/api/borrows` - M09)

### 10.1. Danh sách phiếu mượn
- `GET /api/borrows`: Danh sách phiếu mượn toàn hệ thống (Thủ thư/Admin); Sinh viên chỉ xem danh sách của mình.
- `GET /api/borrows/my`: Phiếu mượn của chính người dùng đang đăng nhập.
- `GET /api/borrows/overdue`: Danh sách phiếu mượn đã quá hạn trả (`status=overdue`). *(Librarian, Admin).*
- `GET /api/borrows/<id>`: Chi tiết phiếu mượn.

### 10.2. Lập phiếu mượn sách mới
- **Endpoint:** `POST /api/borrows`
- **Quyền:** `Librarian`, `Admin`
- **Request Body:**
```json
{
  "user_id": 3,
  "book_id": 1,
  "days": 14,
  "note": "Mượn nghiên cứu làm đồ án"
}
```
- **Ràng buộc nghiệp vụ tự động:**
  - Kiểm tra tài khoản người dùng có đang hoạt động hay không.
  - Chặn mượn nếu người dùng đang có sách quá hạn chưa trả.
  - Chặn mượn nếu vượt quá số lượng tối đa (`MAX_BORROW_BOOKS`, mặc định 5 cuốn).
  - Chặn mượn trùng cuốn sách đang mượn.
  - Tự động trừ số lượng sách khả dụng trong kho (`available_quantity -= 1`).

### 10.3. Gia hạn mượn sách
- **Endpoint:** `PUT /api/borrows/<id>/extend`
- **Quyền:** `Librarian`, `Admin`
- **Request Body:** `{"days": 7}`
- **Ràng buộc:** Chặn gia hạn nếu sách đã quá hạn hoặc đã đạt số lần gia hạn tối đa (`MAX_EXTEND_TIMES`, mặc định 2 lần).

### 10.4. Trả sách vào kho
- **Endpoint:** `PUT /api/borrows/<id>/return`
- **Quyền:** `Librarian`, `Admin`
- **Request Body:**
```json
{
  "condition": "good",
  "is_lost": false,
  "note": "Sách nguyên vẹn, trả đúng hạn"
}
```
- **Xử lý kho:**
  - Nếu trả bình thường: `available_quantity += 1`.
  - Nếu báo mất (`is_lost = true`): Chuyển trạng thái phiếu sang `lost`, giảm tổng số bản `quantity -= 1`, và ghi nhận vi phạm vào AuditLog.

---

## 11. Phân hệ 09: Tính năng AI nâng cao (`/api/ai`)

### 11.1. Kiểm tra trạng thái AI Engine
- **Endpoint:** `GET /api/ai/status`
- **Quyền:** Đã đăng nhập
- **Dữ liệu trả về:** Báo cáo engine đang chạy (`local-nlp` hoặc `gemini+local-nlp`).

### 11.2. Tìm kiếm thông minh bằng ngôn ngữ tự nhiên
- **Endpoint:** `POST /api/ai/smart-search`
- **Quyền:** Đã đăng nhập
- **Request Body:**
```json
{
  "query": "Tìm sách lập trình Python cho người mới bắt đầu xuất bản sau năm 2020",
  "limit": 5
}
```
- **Cơ chế hoạt động:**
  - Chuẩn hóa tiếng Việt, tách cụm từ đồng nghĩa (Việt - Anh).
  - Bóc tách ràng buộc: trình độ (`beginner`), tình trạng (`available_only`), khoảng năm (`year_from`, `year_to`).
  - Chấm điểm trọng số thông minh theo trường và lưu lịch sử tìm kiếm người dùng.

### 11.3. Gợi ý sách cá nhân hóa
- **Endpoint:** `GET /api/ai/recommendations?limit=5`
- **Quyền:** Đã đăng nhập
- **Cơ chế:** Phân tích trọng số thể loại và tác giả từ lịch sử mượn sách (`BorrowRecord`) và các lượt tìm kiếm gần nhất (`SearchHistory`) của người dùng để đưa ra gợi ý chính xác.

### 11.4. Chatbot thư viện
- **Endpoint:** `POST /api/ai/chat`
- **Quyền:** Đã đăng nhập
- **Request Body:**
```json
{
  "message": "Thư viện mở cửa vào những khung giờ nào vậy ạ?"
}
```
- **Hỗ trợ các nhóm ý định (Intents):** `hours` (giờ mở cửa), `rules` (quy định mượn trả), `search` (tìm sách), `categories` (danh mục thể loại), `help` (hướng dẫn tra cứu).

### 11.5. Tự động đề xuất thể loại & từ khóa
- **Endpoint:** `POST /api/ai/suggest-category`
- **Quyền:** `Librarian`, `Admin`
- **Request Body:**
```json
{
  "title": "Machine Learning and Deep Neural Networks with Python",
  "description": "Hướng dẫn thực hành xây dựng mô hình AI và học sâu với TensorFlow"
}
```
- **Dữ liệu trả về:** Danh sách thể loại gợi ý xếp theo độ tự tin (`confidence`) và danh sách 5-8 từ khóa quan trọng giúp thủ thư nhập liệu nhanh chóng.

---

## 12. Phân hệ 10: Vận hành, An ninh & Giám sát (`/api/system` - M21)

### 12.1. Kiểm tra sức khỏe hệ thống (Health Check)
- **Endpoint:** `GET /api/system/health`
- **Quyền:** `Public` (Không cần đăng nhập)
- **Response:**
```json
{
  "success": true,
  "message": "Hệ thống đang hoạt động",
  "data": {
    "status": "ok",
    "database": "ok",
    "dialect": "mssql",
    "time": "2026-11-02T20:30:00"
  }
}
```

### 12.2. Bảng điều khiển giám sát (Dashboard)
- **Endpoint:** `GET /api/system/dashboard`
- **Quyền:** `Admin`
- **Dữ liệu trả về:** Thống kê tổng hợp số lượng user (theo role, active, locked), sách, tài nguyên, mượn trả, nhật ký hoạt động 7 ngày gần nhất và số lần đăng nhập thất bại.

### 12.3. Nhật ký kiểm toán (Audit Logs)
- **Endpoint:** `GET /api/system/audit-logs`
- **Quyền:** `Admin`
- **Query Parameters:** `page`, `per_page`, `user_id`, `username`, `action`, `entity`, `from`, `to` (YYYY-MM-DD).

### 12.4. Xuất toàn bộ dữ liệu CSDL ra JSON
- **Endpoint:** `GET /api/system/export`
- **Quyền:** `Admin`
- **Response:** Tệp JSON chứa toàn bộ dữ liệu logic của 11 bảng.

### 12.5. Sao lưu Microsoft SQL Server ra tệp `.bak`
- **Endpoint:** `POST /api/system/backup`
- **Quyền:** `Admin`
- **Ghi chú:** Thực thi lệnh T-SQL `BACKUP DATABASE` trực tiếp trên SQL Server với chế độ `autocommit=True` và lưu vào thư mục `BACKUP_DIR`.

### 12.6. Dọn dẹp Token hết hạn trong Blocklist
- **Endpoint:** `POST /api/system/cleanup-tokens`
- **Quyền:** `Admin`
- **Ghi chú:** Xóa các token thu hồi đã tồn tại lâu hơn thời gian hết hạn refresh token để giải phóng dung lượng bảng `TokenBlocklist`.

