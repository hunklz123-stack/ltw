-- ============================================================================
-- ĐỀ TÀI: XÂY DỰNG WEB API QUẢN LÝ HỆ THỐNG SÁCH THƯ VIỆN
-- TỆP: database/seed_data.sql
-- HỆ QUẢN TRỊ CƠ SỞ DỮ LIỆU: MICROSOFT SQL SERVER 2017+ / 2019 / 2022
-- MÔ TẢ: Tập lệnh nạp dữ liệu mẫu ban đầu (Unicode tiếng Việt N'...')
-- ============================================================================

USE [LibraryDB];
GO

-- ============================================================================
-- 1. NẠP VAI TRÒ (Roles)
-- ============================================================================
SET IDENTITY_INSERT dbo.Roles ON;

INSERT INTO dbo.Roles (id, name, display_name, description) VALUES
(1, 'Admin', N'Quản trị viên', N'Toàn quyền quản trị hệ thống, tài khoản, phân quyền, cấu hình và giám sát'),
(2, 'Librarian', N'Thủ thư', N'Quản lý sách, tác giả, thể loại, tài nguyên số và thực hiện nghiệp vụ mượn - trả'),
(3, 'Student', N'Sinh viên / Bạn đọc', N'Tra cứu sách, tài nguyên học tập công khai, mượn sách và tương tác với AI');

SET IDENTITY_INSERT dbo.Roles OFF;
GO

-- ============================================================================
-- 2. NẠP TÀI KHOẢN NGƯỜI DÙNG (Users)
-- Mật khẩu mặc định:
--   admin      -> Admin@123
--   thuthu     -> Librarian@123
--   sinhvien01 -> Student@123
--   sinhvien02 -> Student@123
-- ============================================================================
SET IDENTITY_INSERT dbo.Users ON;

INSERT INTO dbo.Users (id, username, password_hash, full_name, email, phone, student_code, role_id, is_active, failed_login_attempts, locked_until, last_login, created_at, updated_at) VALUES
(1, N'admin', 'scrypt:32768:8:1$acRNMjIA1iri2Clw$2bed0c9b4ccea8339c59682e094787cb4fa21af22423c43674bb947622c643fdac5cd8ab814013eeb5f00400146d12a59555439d45012493cae37af452ffbbe6', N'Quản trị viên Hệ thống', N'admin@library.edu.vn', '0901234567', NULL, 1, 1, 0, NULL, GETDATE(), GETDATE(), GETDATE()),
(2, N'thuthu', 'scrypt:32768:8:1$R4isEzTR1T0UNqC5$bd39ca527eb8a187f99ebff63b419740d014b14de101bcc3a1b62a2f41cca1c48ca054caf007da2399e875ece6f641c31f9d00bdffafd6392e7f2529d1e3fcb4', N'Nguyễn Thị Mai (Thủ thư)', N'thuthu@library.edu.vn', '0912345678', NULL, 2, 1, 0, NULL, GETDATE(), GETDATE(), GETDATE()),
(3, N'sinhvien01', 'scrypt:32768:8:1$9h83eRnydEZhzgPC$0bb9913e2a2b6751b0948492241eaaa593482a0ae54e3e5462a9d8d08d7af606a55ffeba27ef1bda1819308f9c2ace7f623987d883ee4cf277c0e70932cb1dd7', N'Trần Văn An', N'an.tv@student.edu.vn', '0987654321', N'SV20230001', 3, 1, 0, NULL, GETDATE(), GETDATE(), GETDATE()),
(4, N'sinhvien02', 'scrypt:32768:8:1$9h83eRnydEZhzgPC$0bb9913e2a2b6751b0948492241eaaa593482a0ae54e3e5462a9d8d08d7af606a55ffeba27ef1bda1819308f9c2ace7f623987d883ee4cf277c0e70932cb1dd7', N'Lê Hoàng Bách', N'bach.lh@student.edu.vn', '0981112233', N'SV20230002', 3, 1, 0, NULL, GETDATE(), GETDATE(), GETDATE());

SET IDENTITY_INSERT dbo.Users OFF;
GO

-- ============================================================================
-- 3. NẠP THỂ LOẠI (Categories)
-- ============================================================================
SET IDENTITY_INSERT dbo.Categories ON;

INSERT INTO dbo.Categories (id, name, description, created_at) VALUES
(1, N'Công nghệ thông tin & Lập trình', N'Sách về thuật toán, cấu trúc dữ liệu, các ngôn ngữ lập trình Python, Java, C++, C#, JavaScript', GETDATE()),
(2, N'Trí tuệ nhân tạo & Khoa học dữ liệu', N'Học máy (Machine Learning), Học sâu (Deep Learning), Xử lý ngôn ngữ tự nhiên, Big Data', GETDATE()),
(3, N'Mạng máy tính & An toàn thông tin', N'Kiến trúc mạng máy tính, giao thức TCP/IP, bảo mật hệ thống, mật mã học', GETDATE()),
(4, N'Toán học & Khoa học cơ bản', N'Giải tích, Đại số tuyến tính, Xác suất thống kê, Toán rời rạc ứng dụng', GETDATE()),
(5, N'Kinh tế & Quản trị kinh doanh', N'Kinh tế vi mô, vĩ mô, quản trị dự án, tài chính doanh nghiệp và khởi nghiệp', GETDATE()),
(6, N'Ngoại ngữ & Kỹ năng mềm', N'Tiếng Anh chuyên ngành, IELTS, kỹ năng giao tiếp, thuyết trình và đàm phán', GETDATE()),
(7, N'Kỹ nghệ phần mềm & Kiến trúc hệ thống', N'Mô hình Agile/Scrum, thiết kế hướng đối tượng, vi dịch vụ (Microservices), Design Patterns', GETDATE());

SET IDENTITY_INSERT dbo.Categories OFF;
GO

-- ============================================================================
-- 4. NẠP TÁC GIẢ (Authors)
-- ============================================================================
SET IDENTITY_INSERT dbo.Authors ON;

INSERT INTO dbo.Authors (id, name, biography, nationality, birth_year, created_at) VALUES
(1, N'Robert C. Martin', N'Uncle Bob - Chuyên gia hàng đầu thế giới về kỹ nghệ phần mềm và Clean Code', N'Mỹ', 1952, GETDATE()),
(2, N'Andrew S. Tanenbaum', N'Giáo sư khoa học máy tính, tác giả các giáo trình kinh điển về Hệ điều hành và Mạng máy tính', N'Hà Lan', 1944, GETDATE()),
(3, N'Stuart Russell', N'Giáo sư Đại học UC Berkeley, đồng tác giả cuốn sách gối đầu giường Trí tuệ nhân tạo (AIMA)', N'Anh', 1962, GETDATE()),
(4, N'Peter Norvig', N'Nhà khoa học máy tính, Giám đốc nghiên cứu tại Google, đồng tác giả Artificial Intelligence: A Modern Approach', N'Mỹ', 1956, GETDATE()),
(5, N'Martin Fowler', N'Nhà tư tưởng kiến trúc phần mềm tại ThoughtWorks, tiên phong về Refactoring và Microservices', N'Anh', 1963, GETDATE()),
(6, N'Donald E. Knuth', N'Huyền thoại khoa học máy tính Stanford, tác giả bộ sách bất hủ The Art of Computer Programming', N'Mỹ', 1938, GETDATE()),
(7, N'Đặng Văn Đức', N'Chuyên gia kỹ thuật phần mềm, tác giả giáo trình Phân tích thiết kế hệ thống hướng đối tượng UML', N'Việt Nam', 1965, GETDATE()),
(8, N'Phạm Thế Long', N'Giáo sư, Tiến sĩ khoa học, tác giả các giáo trình Giải thuật và Cấu trúc dữ liệu tại Việt Nam', N'Việt Nam', 1954, GETDATE()),
(9, N'Dale Carnegie', N'Tác giả cuốn sách bất hủ Đắc nhân tâm và Nghệ thuật diễn thuyết', N'Mỹ', 1888, GETDATE()),
(10, N'Nguyễn Nhật Ánh', N'Nhà văn thiếu nhi và thanh thiếu niên nổi tiếng hàng đầu Việt Nam', N'Việt Nam', 1955, GETDATE());

SET IDENTITY_INSERT dbo.Authors OFF;
GO

-- ============================================================================
-- 5. NẠP ĐẦU SÁCH (Books)
-- ============================================================================
SET IDENTITY_INSERT dbo.Books ON;

INSERT INTO dbo.Books (id, isbn, title, description, publisher, publish_year, language, pages, category_id, quantity, available_quantity, status, condition, location, keywords, cover_image, created_by, created_at, updated_at) VALUES
(1, '978-0132350884', N'Clean Code: A Handbook of Agile Software Craftsmanship', N'Cuốn sách kinh điển hướng dẫn lập trình viên viết code sạch, dễ bảo trì, dễ hiểu và tái cấu trúc mã nguồn hiệu quả. Phù hợp cho lập trình viên từ cơ bản đến nâng cao.', N'Prentice Hall', 2008, N'Tiếng Anh', 464, 7, 10, 8, 'available', 'good', N'Kệ A1-01', N'clean code, agile, lap trinh, lap trinh sach, phan mem, nang cao, refactoring, code quality', NULL, 1, GETDATE(), GETDATE()),
(2, '978-0134494166', N'Clean Architecture: A Craftsman''s Guide to Software Structure', N'Các quy tắc phổ quát về cấu trúc và kiến trúc phần mềm, quy tắc phụ thuộc, ranh giới kiến trúc và kiến trúc phân lớp hướng đối tượng.', N'Prentice Hall', 2017, N'Tiếng Anh', 432, 7, 8, 7, 'available', 'new', N'Kệ A1-02', N'kien truc phan mem, software architecture, clean architecture, thiet ke he thong, microservices', NULL, 1, GETDATE(), GETDATE()),
(3, '978-0136042594', N'Artificial Intelligence: A Modern Approach (4th Edition)', N'Giáo trình toàn diện và phổ biến nhất thế giới về trí tuệ nhân tạo, bao gồm tìm kiếm thông minh, logic suy luận, học máy, học sâu và robot học.', N'Pearson', 2020, N'Tiếng Anh', 1136, 2, 12, 9, 'available', 'good', N'Kệ B2-05', N'tri tue nhan tao, ai, artificial intelligence, hoc may, machine learning, neural networks, robot', NULL, 1, GETDATE(), GETDATE()),
(4, '978-0132126953', N'Computer Networks (5th Edition)', N'Giáo trình mạng máy tính kinh điển phân tích sâu các tầng giao thức TCP/IP, định tuyến, bảo mật mạng, mạng không dây và truyền thông đa phương tiện.', N'Prentice Hall', 2011, N'Tiếng Anh', 960, 3, 15, 12, 'available', 'good', N'Kệ C1-03', N'mang may tinh, computer networks, tcp/ip, routing, internet, bao mat mang, protocol', NULL, 1, GETDATE(), GETDATE()),
(5, '978-0133591620', N'Modern Operating Systems (4th Edition)', N'Tổng quan toàn diện về nguyên lý hệ điều hành: quản lý tiến trình, luồng, bộ nhớ ảo, hệ thống tệp tin, đa xử lý và bảo mật hệ điều hành hiện đại.', N'Pearson', 2014, N'Tiếng Anh', 1136, 1, 7, 5, 'available', 'good', N'Kệ C1-04', N'he dieu hanh, operating system, linux, windows, process, memory management, file system', NULL, 1, GETDATE(), GETDATE()),
(6, '978-0201485677', N'Refactoring: Improving the Design of Existing Code', N'Kỹ thuật tái cấu trúc mã nguồn để cải thiện thiết kế mà không làm thay đổi hành vi bên ngoài. Cẩm nang không thể thiếu của kỹ sư phần mềm.', N'Addison-Wesley', 1999, N'Tiếng Anh', 464, 7, 6, 6, 'available', 'worn', N'Kệ A1-03', N'refactoring, design patterns, ma nguon, toi uu code, clean code, lap trinh huong doi tuong', NULL, 1, GETDATE(), GETDATE()),
(7, '978-0201896831', N'The Art of Computer Programming: Fundamental Algorithms (Vol 1)', N'Tác phẩm vĩ đại của Donald Knuth về các thuật toán cơ bản, cấu trúc dữ liệu tuyến tính, cây và phân tích độ phức tạp thuật toán.', N'Addison-Wesley', 1997, N'Tiếng Anh', 672, 1, 5, 4, 'available', 'good', N'Kệ A2-01', N'giai thuat, cau truc du lieu, algorithms, knuth, toan roi rac, co ban, nang cao', NULL, 1, GETDATE(), GETDATE()),
(8, '978-604-0-123456', N'Giáo trình Cấu trúc dữ liệu và Giải thuật', N'Giáo trình chuẩn cho sinh viên công nghệ thông tin: mảng, danh sách liên kết, ngăn xếp, hàng đợi, cây nhị phân, đồ thị và các thuật toán sắp xếp, tìm kiếm.', N'NXB Thông tin và Truyền thông', 2019, N'Tiếng Việt', 380, 1, 25, 20, 'available', 'good', N'Kệ D1-01', N'cau truc du lieu, giai thuat, algorithms, data structures, sap xep, tim kiem, co ban, c++', NULL, 1, GETDATE(), GETDATE()),
(9, '978-604-0-654321', N'Phân tích và Thiết kế Hệ thống Hướng đối tượng với UML', N'Phương pháp luận phân tích yêu cầu nghiệp vụ, mô hình hóa Use Case, biểu đồ lớp, biểu đồ tuần tự theo chuẩn UML phục vụ phát triển phần mềm doanh nghiệp.', N'NXB Giáo dục Việt Nam', 2018, N'Tiếng Việt', 320, 7, 18, 15, 'available', 'new', N'Kệ D1-02', N'uml, phan tich thiet ke, huong doi tuong, use case, oop, software engineering', NULL, 1, GETDATE(), GETDATE()),
(10, '978-604-58-12345', N'Lập trình Python từ Cơ bản đến Nâng cao', N'Sách hướng dẫn học lập trình Python toàn diện cho người mới bắt đầu: cú pháp, hướng đối tượng, xử lý dữ liệu với Pandas, NumPy, lập trình web với Flask và tự động hóa.', N'NXB Khoa học và Kỹ thuật', 2023, N'Tiếng Việt', 450, 1, 20, 17, 'available', 'new', N'Kệ D2-01', N'python, lap trinh python, co ban, nguoi moi bat dau, flask, data analysis, pandas', NULL, 1, GETDATE(), GETDATE()),
(11, '978-604-58-56789', N'Nhập môn Học máy và Khoa học Dữ liệu với Python', N'Thực hành xây dựng mô hình dự báo, hồi quy tuyến tính, phân cụm, cây quyết định và mạng nơ-ron nhân tạo sử dụng thư viện Scikit-learn và PyTorch.', N'NXB Đại học Quốc gia', 2024, N'Tiếng Việt', 410, 2, 15, 13, 'available', 'new', N'Kệ B2-06', N'hoc may, machine learning, data science, python, scikit-learn, pytorch, nhap mon, ai', NULL, 1, GETDATE(), GETDATE()),
(12, '978-604-58-99999', N'Cơ sở Dữ liệu Quan hệ và Ngôn ngữ SQL', N'Lý thuyết chuẩn hóa cơ sở dữ liệu (1NF, 2NF, 3NF, BCNF), thiết kế lược đồ quan hệ ERD, truy vấn SQL từ cơ bản đến nâng cao trên Microsoft SQL Server.', N'NXB Thống Kê', 2022, N'Tiếng Việt', 360, 1, 20, 18, 'available', 'good', N'Kệ D2-02', N'co so du lieu, database, sql, sql server, quan he, truy van, chuan hoa, erd', NULL, 1, GETDATE(), GETDATE()),
(13, '978-0671027032', N'Đắc Nhân Tâm (How to Win Friends and Influence People)', N'Nghệ thuật đối nhân xử thế, giao tiếp và thuyết phục người khác. Cuốn sách gối đầu giường về kỹ năng mềm cho mọi sinh viên và người đi làm.', N'Simon & Schuster / NXB Tổng hợp TP.HCM', 2016, N'Tiếng Việt', 320, 6, 30, 25, 'available', 'good', N'Kệ E1-01', N'dac nhan tam, ky nang mem, giao tiep, lanh dao, thuyet phuc, self-help', NULL, 1, GETDATE(), GETDATE()),
(14, '978-604-0-987654', N'Xác suất Thống kê và Ứng dụng trong Khoa học Máy tính', N'Cơ sở xác suất, biến ngẫu nhiên, các phân phối phổ biến, ước lượng tham số và kiểm định giả thuyết phục vụ học máy và trí tuệ nhân tạo.', N'NXB Giáo dục Việt Nam', 2021, N'Tiếng Việt', 290, 4, 14, 12, 'available', 'good', N'Kệ F1-01', N'toan, xac suat, thong ke, probability, statistics, ai, data science', NULL, 1, GETDATE(), GETDATE());

SET IDENTITY_INSERT dbo.Books OFF;
GO

-- ============================================================================
-- 6. NẠP LIÊN KẾT SÁCH - TÁC GIẢ (BookAuthors)
-- ============================================================================
INSERT INTO dbo.BookAuthors (book_id, author_id) VALUES
(1, 1),  -- Clean Code -> Robert C. Martin
(2, 1),  -- Clean Architecture -> Robert C. Martin
(3, 3),  -- AI Modern Approach -> Stuart Russell
(3, 4),  -- AI Modern Approach -> Peter Norvig
(4, 2),  -- Computer Networks -> Andrew S. Tanenbaum
(5, 2),  -- Modern Operating Systems -> Andrew S. Tanenbaum
(6, 5),  -- Refactoring -> Martin Fowler
(7, 6),  -- TAOCP -> Donald E. Knuth
(8, 8),  -- Cấu trúc dữ liệu & giải thuật -> Phạm Thế Long
(9, 7),  -- Thiết kế hệ thống UML -> Đặng Văn Đức
(10, 8), -- Lập trình Python -> Phạm Thế Long
(11, 8), -- Học máy với Python -> Phạm Thế Long
(12, 7), -- CSDL Quan hệ & SQL -> Đặng Văn Đức
(13, 9), -- Đắc nhân tâm -> Dale Carnegie
(14, 8); -- Xác suất thống kê -> Phạm Thế Long
GO

-- ============================================================================
-- 7. NẠP TÀI NGUYÊN HỌC TẬP ĐIỆN TỬ (Resources)
-- ============================================================================
SET IDENTITY_INSERT dbo.Resources ON;

INSERT INTO dbo.Resources (id, title, description, resource_type, url, file_path, file_name, file_size, mime_type, book_id, category_id, access_level, uploaded_by, download_count, created_at, updated_at) VALUES
(1, N'Slide bài giảng: Nguyên lý Lập trình Python & Clean Code', N'Bộ bài giảng điện tử 12 chương phục vụ học phần Lập trình nâng cao.', 'slide', N'https://library.edu.vn/materials/python-clean-code-slides.pdf', NULL, N'python_clean_code_slides.pdf', 4520000, 'application/pdf', 10, 1, 'public', 1, 42, GETDATE(), GETDATE()),
(2, N'Tài liệu thực hành: Truy vấn SQL trên Microsoft SQL Server', N'Hướng dẫn thực hành viết câu lệnh SELECT, JOIN, GROUP BY, Subquery và Transaction.', 'pdf', N'https://library.edu.vn/materials/sql-server-lab-manual.pdf', NULL, N'sql_server_lab_manual.pdf', 2850000, 'application/pdf', 12, 1, 'public', 1, 68, GETDATE(), GETDATE()),
(3, N'Video bài giảng: Phân tích kiến trúc Clean Architecture', N'Video ghi hình bài giảng chuyên sâu về thiết kế phần mềm hướng dịch vụ.', 'video', N'https://www.youtube.com/watch?v=dQw4w9WgXcQ', NULL, NULL, 0, 'video/mp4', 1, 7, 'public', 2, 19, GETDATE(), GETDATE()),
(4, N'Đề cương & Ngân hàng câu hỏi thi môn Cơ sở dữ liệu (Nội bộ)', N'Tài liệu ngân hàng đề thi lưu hành nội bộ dành cho giảng viên và thủ thư thẩm định.', 'document', N'https://library.edu.vn/internal/exam-bank-databases-2026.docx', NULL, N'exam_bank_databases_2026.docx', 1200000, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 12, 1, 'internal', 1, 5, GETDATE(), GETDATE());

SET IDENTITY_INSERT dbo.Resources OFF;
GO

-- ============================================================================
-- 8. NẠP PHIẾU MƯỢN MẪU (BorrowRecords)
-- ============================================================================
SET IDENTITY_INSERT dbo.BorrowRecords ON;

INSERT INTO dbo.BorrowRecords (id, user_id, book_id, borrow_date, due_date, return_date, status, extend_count, note, processed_by, created_at) VALUES
(1, 3, 1, DATEADD(day, -4, GETDATE()), DATEADD(day, 10, GETDATE()), NULL, 'borrowing', 0, N'Mượn phục vụ làm đồ án chuyên ngành', 2, DATEADD(day, -4, GETDATE())),
(2, 3, 10, DATEADD(day, -20, GETDATE()), DATEADD(day, -6, GETDATE()), DATEADD(day, -7, GETDATE()), 'returned', 0, N'Sách trả nguyên vẹn, tình trạng tốt', 2, DATEADD(day, -20, GETDATE())),
(3, 4, 3, DATEADD(day, -20, GETDATE()), DATEADD(day, -5, GETDATE()), NULL, 'borrowing', 1, N'Đã gửi thông báo nhắc trả sách lần 1', 2, DATEADD(day, -20, GETDATE()));

SET IDENTITY_INSERT dbo.BorrowRecords OFF;
GO

-- ============================================================================
-- 9. NẠP NHẬT KÝ KIỂM TOÁN BAN ĐẦU (AuditLogs)
-- ============================================================================
INSERT INTO dbo.AuditLogs (user_id, username, action, entity, entity_id, details, ip_address, created_at) VALUES
(1, N'admin', 'SYSTEM_INIT', 'Database', 'All', N'{"message": "Khởi tạo hệ thống CSDL thư viện và nạp dữ liệu mẫu ban đầu theo đề án"}', '127.0.0.1', GETDATE());
GO

PRINT N'[+] ĐÃ NẠP TOÀN BỘ DỮ LIỆU MẪU CHO CSDL LibraryDB THÀNH CÔNG!';
GO

