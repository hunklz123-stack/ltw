-- ============================================================================
-- ĐỀ TÀI: XÂY DỰNG WEB API QUẢN LÝ HỆ THỐNG SÁCH THƯ VIỆN
-- TỆP: database/schema.sql
-- HỆ QUẢN TRỊ CƠ SỞ DỮ LIỆU: MICROSOFT SQL SERVER 2017+ / 2019 / 2022 / AZURE SQL
-- MÔ TẢ: Tập lệnh tạo CSDL LibraryDB và toàn bộ 11 bảng theo mô hình ORM
-- ============================================================================

-- 1. TẠO CƠ SỞ DỮ LIỆU NẾU CHƯA CÓ
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'LibraryDB')
BEGIN
    CREATE DATABASE [LibraryDB]
    COLLATE Vietnamese_CI_AS;
    PRINT N'[+] Đã tạo mới cơ sở dữ liệu LibraryDB.';
END
GO

USE [LibraryDB];
GO

-- 2. XÓA CÁC BẢNG THEO THỨ TỰ PHỤ THUỘC (NẾU ĐÃ TỒN TẠI ĐỂ TẠO LẠI SẠCH SẼ)
IF OBJECT_ID(N'dbo.SearchHistory', N'U') IS NOT NULL DROP TABLE dbo.SearchHistory;
IF OBJECT_ID(N'dbo.AuditLogs', N'U') IS NOT NULL DROP TABLE dbo.AuditLogs;
IF OBJECT_ID(N'dbo.TokenBlocklist', N'U') IS NOT NULL DROP TABLE dbo.TokenBlocklist;
IF OBJECT_ID(N'dbo.BorrowRecords', N'U') IS NOT NULL DROP TABLE dbo.BorrowRecords;
IF OBJECT_ID(N'dbo.Resources', N'U') IS NOT NULL DROP TABLE dbo.Resources;
IF OBJECT_ID(N'dbo.BookAuthors', N'U') IS NOT NULL DROP TABLE dbo.BookAuthors;
IF OBJECT_ID(N'dbo.Books', N'U') IS NOT NULL DROP TABLE dbo.Books;
IF OBJECT_ID(N'dbo.Authors', N'U') IS NOT NULL DROP TABLE dbo.Authors;
IF OBJECT_ID(N'dbo.Categories', N'U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID(N'dbo.Roles', N'U') IS NOT NULL DROP TABLE dbo.Roles;
GO

-- ============================================================================
-- 3. BẢNG 1: Roles (Vai trò người dùng - M20)
-- ============================================================================
CREATE TABLE dbo.Roles (
    id INT IDENTITY(1,1) NOT NULL,
    name VARCHAR(50) NOT NULL,
    display_name NVARCHAR(100) NULL,
    description NVARCHAR(255) NULL,
    CONSTRAINT PK_Roles PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT UQ_Roles_name UNIQUE NONCLUSTERED (name ASC)
);
GO

-- ============================================================================
-- 4. BẢNG 2: Users (Người dùng, tài khoản & phân quyền - M20)
-- ============================================================================
CREATE TABLE dbo.Users (
    id INT IDENTITY(1,1) NOT NULL,
    username NVARCHAR(50) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) NOT NULL,
    phone VARCHAR(20) NULL,
    student_code NVARCHAR(20) NULL,
    role_id INT NOT NULL,
    is_active BIT NOT NULL CONSTRAINT DF_Users_is_active DEFAULT (1),
    failed_login_attempts INT NOT NULL CONSTRAINT DF_Users_failed_attempts DEFAULT (0),
    locked_until DATETIME NULL,
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_Users_created_at DEFAULT (GETDATE()),
    updated_at DATETIME NOT NULL CONSTRAINT DF_Users_updated_at DEFAULT (GETDATE()),
    CONSTRAINT PK_Users PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT UQ_Users_username UNIQUE NONCLUSTERED (username ASC),
    CONSTRAINT UQ_Users_email UNIQUE NONCLUSTERED (email ASC),
    CONSTRAINT FK_Users_Roles FOREIGN KEY (role_id) REFERENCES dbo.Roles (id)
);
GO
CREATE NONCLUSTERED INDEX IX_Users_role_id ON dbo.Users (role_id ASC);
CREATE NONCLUSTERED INDEX IX_Users_student_code ON dbo.Users (student_code ASC);
GO

-- ============================================================================
-- 5. BẢNG 3: Categories (Thể loại sách - M09)
-- ============================================================================
CREATE TABLE dbo.Categories (
    id INT IDENTITY(1,1) NOT NULL,
    name NVARCHAR(100) NOT NULL,
    description NVARCHAR(MAX) NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_Categories_created_at DEFAULT (GETDATE()),
    CONSTRAINT PK_Categories PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT UQ_Categories_name UNIQUE NONCLUSTERED (name ASC)
);
GO

-- ============================================================================
-- 6. BẢNG 4: Authors (Tác giả - M09)
-- ============================================================================
CREATE TABLE dbo.Authors (
    id INT IDENTITY(1,1) NOT NULL,
    name NVARCHAR(150) NOT NULL,
    biography NVARCHAR(MAX) NULL,
    nationality NVARCHAR(100) NULL,
    birth_year INT NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_Authors_created_at DEFAULT (GETDATE()),
    CONSTRAINT PK_Authors PRIMARY KEY CLUSTERED (id ASC)
);
GO
CREATE NONCLUSTERED INDEX IX_Authors_name ON dbo.Authors (name ASC);
GO

-- ============================================================================
-- 7. BẢNG 5: Books (Thông tin sách & kho tài sản - M09)
-- ============================================================================
CREATE TABLE dbo.Books (
    id INT IDENTITY(1,1) NOT NULL,
    isbn VARCHAR(20) NOT NULL,
    title NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    publisher NVARCHAR(150) NULL,
    publish_year INT NULL,
    language NVARCHAR(50) NULL,
    pages INT NULL,
    category_id INT NULL,
    quantity INT NOT NULL CONSTRAINT DF_Books_quantity DEFAULT (0),
    available_quantity INT NOT NULL CONSTRAINT DF_Books_available DEFAULT (0),
    status VARCHAR(20) NOT NULL CONSTRAINT DF_Books_status DEFAULT ('available'),
    condition VARCHAR(20) NOT NULL CONSTRAINT DF_Books_condition DEFAULT ('good'),
    location NVARCHAR(50) NULL,
    keywords NVARCHAR(500) NULL,
    cover_image NVARCHAR(500) NULL,
    created_by INT NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_Books_created_at DEFAULT (GETDATE()),
    updated_at DATETIME NOT NULL CONSTRAINT DF_Books_updated_at DEFAULT (GETDATE()),
    CONSTRAINT PK_Books PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT UQ_Books_isbn UNIQUE NONCLUSTERED (isbn ASC),
    CONSTRAINT FK_Books_Categories FOREIGN KEY (category_id) REFERENCES dbo.Categories (id) ON DELETE SET NULL,
    CONSTRAINT CK_Books_status CHECK (status IN ('available', 'out_of_stock', 'discontinued')),
    CONSTRAINT CK_Books_condition CHECK (condition IN ('new', 'good', 'worn', 'damaged')),
    CONSTRAINT CK_Books_quantity_positive CHECK (quantity >= 0 AND available_quantity >= 0 AND available_quantity <= quantity)
);
GO
CREATE NONCLUSTERED INDEX IX_Books_category_id ON dbo.Books (category_id ASC);
CREATE NONCLUSTERED INDEX IX_Books_status ON dbo.Books (status ASC);
CREATE NONCLUSTERED INDEX IX_Books_title ON dbo.Books (title ASC);
GO

-- ============================================================================
-- 8. BẢNG 6: BookAuthors (Liên kết Nhiều - Nhiều Sách và Tác giả)
-- ============================================================================
CREATE TABLE dbo.BookAuthors (
    book_id INT NOT NULL,
    author_id INT NOT NULL,
    CONSTRAINT PK_BookAuthors PRIMARY KEY CLUSTERED (book_id ASC, author_id ASC),
    CONSTRAINT FK_BookAuthors_Books FOREIGN KEY (book_id) REFERENCES dbo.Books (id) ON DELETE CASCADE,
    CONSTRAINT FK_BookAuthors_Authors FOREIGN KEY (author_id) REFERENCES dbo.Authors (id) ON DELETE CASCADE
);
GO
CREATE NONCLUSTERED INDEX IX_BookAuthors_author_id ON dbo.BookAuthors (author_id ASC);
GO

-- ============================================================================
-- 9. BẢNG 7: Resources (Tài nguyên học tập điện tử - M10 LMS/LCMS)
-- ============================================================================
CREATE TABLE dbo.Resources (
    id INT IDENTITY(1,1) NOT NULL,
    title NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    resource_type VARCHAR(20) NOT NULL CONSTRAINT DF_Resources_type DEFAULT ('document'),
    url NVARCHAR(1000) NULL,
    file_path NVARCHAR(500) NULL,
    file_name NVARCHAR(255) NULL,
    file_size INT NULL,
    mime_type VARCHAR(100) NULL,
    book_id INT NULL,
    category_id INT NULL,
    access_level VARCHAR(20) NOT NULL CONSTRAINT DF_Resources_access DEFAULT ('public'),
    uploaded_by INT NULL,
    download_count INT NOT NULL CONSTRAINT DF_Resources_downloads DEFAULT (0),
    created_at DATETIME NOT NULL CONSTRAINT DF_Resources_created_at DEFAULT (GETDATE()),
    updated_at DATETIME NOT NULL CONSTRAINT DF_Resources_updated_at DEFAULT (GETDATE()),
    CONSTRAINT PK_Resources PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT FK_Resources_Books FOREIGN KEY (book_id) REFERENCES dbo.Books (id) ON DELETE SET NULL,
    CONSTRAINT FK_Resources_Categories FOREIGN KEY (category_id) REFERENCES dbo.Categories (id) ON DELETE SET NULL,
    CONSTRAINT CK_Resources_type CHECK (resource_type IN ('ebook', 'pdf', 'slide', 'video', 'audio', 'document', 'link', 'other')),
    CONSTRAINT CK_Resources_access CHECK (access_level IN ('public', 'internal'))
);
GO
CREATE NONCLUSTERED INDEX IX_Resources_book_id ON dbo.Resources (book_id ASC);
CREATE NONCLUSTERED INDEX IX_Resources_category_id ON dbo.Resources (category_id ASC);
CREATE NONCLUSTERED INDEX IX_Resources_access_level ON dbo.Resources (access_level ASC);
GO

-- ============================================================================
-- 10. BẢNG 8: BorrowRecords (Phiếu mượn - trả sách - M09 mở rộng)
-- ============================================================================
CREATE TABLE dbo.BorrowRecords (
    id INT IDENTITY(1,1) NOT NULL,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    borrow_date DATETIME NOT NULL CONSTRAINT DF_BorrowRecords_borrow_date DEFAULT (GETDATE()),
    due_date DATETIME NOT NULL,
    return_date DATETIME NULL,
    status VARCHAR(20) NOT NULL CONSTRAINT DF_BorrowRecords_status DEFAULT ('borrowing'),
    extend_count INT NOT NULL CONSTRAINT DF_BorrowRecords_extend DEFAULT (0),
    note NVARCHAR(500) NULL,
    processed_by INT NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_BorrowRecords_created_at DEFAULT (GETDATE()),
    CONSTRAINT PK_BorrowRecords PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT FK_BorrowRecords_Users FOREIGN KEY (user_id) REFERENCES dbo.Users (id),
    CONSTRAINT FK_BorrowRecords_Books FOREIGN KEY (book_id) REFERENCES dbo.Books (id),
    CONSTRAINT CK_BorrowRecords_status CHECK (status IN ('borrowing', 'returned', 'overdue', 'lost'))
);
GO
CREATE NONCLUSTERED INDEX IX_BorrowRecords_user_id ON dbo.BorrowRecords (user_id ASC);
CREATE NONCLUSTERED INDEX IX_BorrowRecords_book_id ON dbo.BorrowRecords (book_id ASC);
CREATE NONCLUSTERED INDEX IX_BorrowRecords_status ON dbo.BorrowRecords (status ASC);
CREATE NONCLUSTERED INDEX IX_BorrowRecords_due_date ON dbo.BorrowRecords (due_date ASC);
GO

-- ============================================================================
-- 11. BẢNG 9: AuditLogs (Nhật ký kiểm toán & an ninh hệ thống - M21)
-- ============================================================================
CREATE TABLE dbo.AuditLogs (
    id INT IDENTITY(1,1) NOT NULL,
    user_id INT NULL,
    username NVARCHAR(50) NULL,
    action VARCHAR(50) NOT NULL,
    entity VARCHAR(50) NULL,
    entity_id VARCHAR(50) NULL,
    details NVARCHAR(MAX) NULL,
    ip_address VARCHAR(50) NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_AuditLogs_created_at DEFAULT (GETDATE()),
    CONSTRAINT PK_AuditLogs PRIMARY KEY CLUSTERED (id ASC)
);
GO
CREATE NONCLUSTERED INDEX IX_AuditLogs_created_at ON dbo.AuditLogs (created_at DESC);
CREATE NONCLUSTERED INDEX IX_AuditLogs_action ON dbo.AuditLogs (action ASC);
CREATE NONCLUSTERED INDEX IX_AuditLogs_user_id ON dbo.AuditLogs (user_id ASC);
GO

-- ============================================================================
-- 12. BẢNG 10: SearchHistory (Lịch sử tìm kiếm phục vụ gợi ý AI)
-- ============================================================================
CREATE TABLE dbo.SearchHistory (
    id INT IDENTITY(1,1) NOT NULL,
    user_id INT NOT NULL,
    search_text NVARCHAR(500) NOT NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_SearchHistory_created_at DEFAULT (GETDATE()),
    CONSTRAINT PK_SearchHistory PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT FK_SearchHistory_Users FOREIGN KEY (user_id) REFERENCES dbo.Users (id) ON DELETE CASCADE
);
GO
CREATE NONCLUSTERED INDEX IX_SearchHistory_user_id ON dbo.SearchHistory (user_id ASC);
GO

-- ============================================================================
-- 13. BẢNG 11: TokenBlocklist (Danh sách JWT token bị thu hồi khi đăng xuất - M20)
-- ============================================================================
CREATE TABLE dbo.TokenBlocklist (
    id INT IDENTITY(1,1) NOT NULL,
    jti VARCHAR(64) NOT NULL,
    created_at DATETIME NOT NULL CONSTRAINT DF_TokenBlocklist_created_at DEFAULT (GETDATE()),
    CONSTRAINT PK_TokenBlocklist PRIMARY KEY CLUSTERED (id ASC),
    CONSTRAINT UQ_TokenBlocklist_jti UNIQUE NONCLUSTERED (jti ASC)
);
GO
CREATE NONCLUSTERED INDEX IX_TokenBlocklist_created_at ON dbo.TokenBlocklist (created_at ASC);
GO

PRINT N'[+] ĐÃ TẠO TOÀN BỘ 11 BẢNG VÀ CHỈ MỤC CHO CSDL LibraryDB THÀNH CÔNG!';
GO

