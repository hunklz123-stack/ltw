# Tài liệu Bàn giao Dự án (HANDOFF)
**Đề tài:** Xây dựng Web API quản lý hệ thống sách thư viện  
**Công nghệ:** Python, Flask, SQLAlchemy, Microsoft SQL Server (`pyodbc`), JWT (`Flask-JWT-Extended`), RESTful API, JSON, Postman  
**Cập nhật lần cuối:** 2026-11-02

---

## 1. Tổng quan Đề tài & Phạm vi Hệ thống

Hệ thống cung cấp RESTful Web API phục vụ số hóa và tập trung hóa nghiệp vụ thư viện cho **3 nhóm vai trò** (`Admin`, `Librarian`, `Student`), bao phủ **4 phân hệ chức năng** và **nhóm tính năng AI mở rộng** theo đề cương:

| Phân hệ | Mô tả nghiệp vụ chính | Module triển khai |
| :--- | :--- | :--- |
| **M09 - Quản lý tài sản** | Quản lý sách, tác giả, thể loại, vị trí kệ, số lượng tồn/đang mượn, tình trạng vật lý (`new`, `good`, `worn`, `damaged`), trạng thái lưu hành (`available`, `out_of_stock`, `discontinued`), phiếu mượn - trả - gia hạn, thống kê kho | `books.py`, `authors.py`, `categories.py`, `borrows.py` |
| **M10 - LMS/LCMS & Tài nguyên học tập** | Quản lý tài liệu điện tử (`ebook`, `pdf`, `slide`, `video`, `audio`, `document`, `link`), upload tệp hoặc gắn URL ngoài, liên kết sách/thể loại, phân quyền truy cập (`public` / `internal`), tải tệp & đếm lượt tải | `resources.py` |
| **M20 - Tài khoản, Xác thực & Phân quyền** | Đăng ký, đăng nhập (username/email), JWT Access & Refresh Token, thu hồi token khi đăng xuất, đổi mật khẩu, quản lý người dùng, gán vai trò (RBAC), khóa tạm thời khi đăng nhập sai nhiều lần | `auth.py`, `users.py`, `roles.py`, `decorators.py` |
| **M21 - Bảo mật, Sao lưu & Vận hành** | Nhật ký kiểm toán (`AuditLogs`), HTTP Security Headers, Rotating File Logs, Health Check, Dashboard giám sát, sao lưu SQL Server gốc (`.bak`), xuất dữ liệu logic (`.json`), dọn token hết hạn | `system.py`, `audit.py`, `app/__init__.py` |
| **AI - Tính năng nâng cao** | Tìm kiếm thông minh bằng ngôn ngữ tự nhiên, gợi ý sách cá nhân hóa (từ lịch sử mượn & tìm kiếm), Chatbot thư viện, tự động gợi ý thể loại & từ khóa cho thủ thư | `ai.py`, `ai_service.py` |

---

## 2. Tóm tắt Tiến độ Công việc

### 2.1. Hạng mục ĐÃ HOÀN THÀNH (~80% khối lượng mã nguồn)
- [x] **Cấu hình & Khung dự án:** Thiết lập cấu hình qua biến môi trường (`config.py`, `.env.example`), danh sách thư viện (`requirements.txt`), `.gitignore`.
- [x] **Application Factory & Middleware:** Khởi tạo Flask app (`app/__init__.py`, `app/extensions.py`), cấu hình CORS, JSON tiếng Việt UTF-8, Security Headers, Global Error Handlers và Rotating File Logging.
- [x] **Thiết kế ORM Models (`app/models.py`):** Hoàn thiện toàn bộ **11 bảng** tương thích chuẩn Unicode (`NVARCHAR`) của Microsoft SQL Server.
- [x] **Tầng tiện ích dùng chung (`app/utils/`):** Chuẩn hóa JSON response, phân trang tương thích SQL Server, kiểm tra dữ liệu đầu vào, RBAC decorators, ghi Audit Log.
- [x] **Toàn bộ 10 nhóm RESTful API Blueprints (`app/routes/`):** Đã cài đặt đầy đủ 48 endpoints cho tất cả các nghiệp vụ trong đề cương.
- [x] **Dịch vụ AI Hybrid (`app/services/ai_service.py`):** Hoạt động độc lập bằng bộ xử lý ngôn ngữ tự nhiên tiếng Việt nội bộ (`local-nlp`) và tự động nâng cấp qua Google Gemini REST API nếu cấu hình `GEMINI_API_KEY`.

### 2.2. Hạng mục CHƯA HOÀN THÀNH (Cần làm tiếp)
- [ ] **Entry point khởi chạy server (`run.py`):** Tập tin chạy ứng dụng Flask ở thư mục gốc.
- [ ] **Script khởi tạo CSDL & dữ liệu mẫu (`init_db.py`):** Tự động tạo bảng, khởi tạo 3 vai trò mặc định, tài khoản mẫu (`admin`, `librarian`, `student`) và dữ liệu sách/tác giả/thể loại/tài nguyên/phiếu mượn mẫu.
- [ ] **Tập lệnh SQL cho Microsoft SQL Server (`database/schema.sql`, `database/seed_data.sql`):** Phục vụ chạy trực tiếp trên SSMS và nộp kèm sản phẩm cơ sở dữ liệu của đề tài.
- [ ] **Postman Collection & Environment (`postman/`):** Bộ request kiểm thử đầy đủ kèm script tự động gắn Bearer Token để bàn giao kết quả kiểm thử API.
- [ ] **Automated Tests (`tests/`):** Bộ kiểm thử tự động kiểm tra toàn bộ luồng nghiệp vụ và phân quyền.
- [ ] **Tài liệu hướng dẫn & Đặc tả API (`README.md`, `docs/API_DOCUMENTATION.md`):** Hiện `GET /` trong `app/__init__.py` đã dẫn chiếu tới 2 tài liệu này nhưng file chưa được tạo.
- [ ] **Chạy kiểm thử thực tế trên môi trường máy:** Xem lưu ý môi trường bên dưới.

> **Lưu ý quan trọng về môi trường máy hiện tại:**  
> Qua kiểm tra terminal, máy Windows hiện tại **chưa cài đặt Python** (`py -0p` báo `No installed Pythons found!`, `python.exe` chỉ là stub của `WindowsApps`). Vì vậy toàn bộ mã nguồn hiện chưa được chạy thực thi trực tiếp; bước kiểm tra cú pháp runtime và kết nối SQL Server cần thực hiện ngay sau khi cài Python 3.10+ và ODBC Driver 17/18 for SQL Server.

---

## 3. Kiến trúc Hệ thống Đã Thiết kế

### 3.1. Cấu trúc thư mục hiện tại
```text
d:\code\ltw\
├── .env.example                 # Mẫu cấu hình biến môi trường
├── .gitignore                   # Loại trừ venv, .env, uploads/, logs/, __pycache__
├── config.py                    # Lớp Config & hàm tạo chuỗi kết nối ODBC SQL Server
├── requirements.txt             # Các gói thư viện Python cần thiết
├── HANDOFF.md                   # Tài liệu bàn giao tiến độ & kiến trúc (file này)
└── app\
    ├── __init__.py              # Application Factory (create_app), JWT callbacks, Error handlers
    ├── extensions.py            # Khởi tạo db (SQLAlchemy), jwt (JWTManager), cors (CORS)
    ├── models.py                # Định nghĩa 11 bảng CSDL & phương thức serialize
    ├── routes\                  # Tầng Controller / RESTful Blueprints
    │   ├── __init__.py
    │   ├── auth.py              # /api/auth/*       - Xác thực & hồ sơ cá nhân
    │   ├── users.py             # /api/users/*      - Quản trị người dùng & phân quyền
    │   ├── roles.py             # /api/roles/*      - Vai trò & ma trận quyền hạn
    │   ├── categories.py        # /api/categories/* - Quản lý thể loại sách
    │   ├── authors.py           # /api/authors/*    - Quản lý tác giả
    │   ├── books.py             # /api/books/*      - Quản lý sách, tồn kho & thống kê
    │   ├── resources.py         # /api/resources/*  - Tài nguyên học tập điện tử (upload/url)
    │   ├── borrows.py           # /api/borrows/*    - Phiếu mượn - trả - gia hạn sách
    │   ├── ai.py                # /api/ai/*         - Tìm kiếm thông minh, gợi ý, chatbot, phân loại
    │   └── system.py            # /api/system/*     - Health, dashboard, audit logs, backup, export
    ├── services\                # Tầng Business / Domain Service phức tạp
    │   ├── __init__.py
    │   └── ai_service.py        # Xử lý tiếng Việt, chấm điểm tìm kiếm, gợi ý, chatbot & Gemini API
    └── utils\                   # Tầng tiện ích dùng chung
        ├── __init__.py
        ├── audit.py             # Ghi nhật ký AuditLog an toàn
        ├── decorators.py        # @login_required, @roles_required, @admin_required, @staff_required
        ├── responses.py         # success(), error(), paginated()
        └── validators.py        # Validate email, password, phone, ép kiểu ngày/số/chuỗi
```

### 3.2. Thiết kế Cơ sở dữ liệu (11 bảng trong `app/models.py`)
1. **`Roles`**: `id`, `name` (`Admin` | `Librarian` | `Student`), `display_name`, `description`.
2. **`Users`**: `id`, `username`, `password_hash`, `full_name`, `email`, `phone`, `student_code`, `role_id` (FK -> `Roles`), `is_active`, `failed_login_attempts`, `locked_until`, `last_login`, `created_at`, `updated_at`.
3. **`Categories`**: `id`, `name`, `description`, `created_at`.
4. **`Authors`**: `id`, `name`, `biography`, `nationality`, `birth_year`, `created_at`.
5. **`Books`**: `id`, `isbn` (unique), `title`, `description`, `publisher`, `publish_year`, `language`, `pages`, `category_id` (FK -> `Categories`), `quantity`, `available_quantity`, `status`, `condition`, `location`, `keywords`, `cover_image`, `created_by`, `created_at`, `updated_at`.
6. **`BookAuthors`**: Bảng liên kết nhiều-nhiều (`book_id` FK -> `Books`, `author_id` FK -> `Authors`, `ON DELETE CASCADE`).
7. **`Resources`**: `id`, `title`, `description`, `resource_type`, `url`, `file_path`, `file_name`, `file_size`, `mime_type`, `book_id` (FK -> `Books`), `category_id` (FK -> `Categories`), `access_level` (`public` | `internal`), `uploaded_by`, `download_count`, `created_at`, `updated_at`.
8. **`BorrowRecords`**: `id`, `user_id` (FK -> `Users`), `book_id` (FK -> `Books`), `borrow_date`, `due_date`, `return_date`, `status` (`borrowing` | `returned` | `overdue` | `lost`), `extend_count`, `note`, `processed_by`, `created_at`.
9. **`AuditLogs`**: `id`, `user_id`, `username`, `action`, `entity`, `entity_id`, `details` (JSON text), `ip_address`, `created_at` (indexed).
10. **`SearchHistory`**: `id`, `user_id` (FK -> `Users`, `ON DELETE CASCADE`), `search_text`, `created_at` — lưu lịch sử tra cứu phục vụ gợi ý sách cá nhân hóa.
11. **`TokenBlocklist`**: `id`, `jti` (unique), `created_at` — lưu danh sách JWT đã thu hồi khi đăng xuất.

### 3.3. Tổng hợp các Nhóm API & Phân quyền

| Tiền tố URL | Các Endpoint chính | Phân quyền |
| :--- | :--- | :--- |
| `/api/auth` | `POST /register`, `POST /login`, `POST /refresh`, `POST /logout`, `GET/PUT /me`, `PUT /change-password` | Public (`register`, `login`), User đã đăng nhập (còn lại) |
| `/api/users` | `GET /`, `GET /<id>`, `POST /`, `PUT /<id>`, `PATCH /<id>/role`, `PATCH /<id>/status`, `POST /<id>/reset-password`, `DELETE /<id>` | Chỉ `Admin` |
| `/api/roles` | `GET /`, `GET /permissions`, `GET /<id>`, `PUT /<id>` | Chỉ `Admin` |
| `/api/categories` | `GET /`, `GET /<id>`, `GET /<id>/books`, `POST /`, `PUT /<id>`, `DELETE /<id>` | Xem: Đã đăng nhập; Thêm/Sửa/Xóa: `Admin`, `Librarian` |
| `/api/authors` | `GET /`, `GET /<id>`, `POST /`, `PUT /<id>`, `DELETE /<id>` | Xem: Đã đăng nhập; Thêm/Sửa/Xóa: `Admin`, `Librarian` |
| `/api/books` | `GET /`, `GET /<id>`, `GET /isbn/<isbn>`, `GET /statistics`, `POST /`, `PUT /<id>`, `PATCH /<id>/quantity`, `PATCH /<id>/status`, `DELETE /<id>` | Xem/Tìm kiếm: Đã đăng nhập; Quản lý & Thống kê: `Admin`, `Librarian` |
| `/api/resources` | `GET /`, `GET /<id>`, `GET /<id>/download`, `POST /`, `PUT /<id>`, `DELETE /<id>` | `Student` chỉ thấy/tải `public`; `Admin`/`Librarian` toàn quyền + xem `internal` |
| `/api/borrows` | `GET /`, `GET /my`, `GET /overdue`, `GET /<id>`, `POST /`, `PUT /<id>/return`, `PUT /<id>/extend` | `Student` chỉ xem phiếu của mình; Lập phiếu/Trả/Gia hạn/Quá hạn: `Admin`, `Librarian` |
| `/api/ai` | `GET /status`, `POST /smart-search`, `GET /recommendations`, `POST /chat`, `POST /suggest-category` | Đã đăng nhập; riêng `/suggest-category`: `Admin`, `Librarian` |
| `/api/system` | `GET /health`, `GET /dashboard`, `GET /audit-logs`, `POST /backup`, `GET /backups`, `GET /export`, `POST /cleanup-tokens` | `/health`: Public; Còn lại: Chỉ `Admin` |

---

## 4. Các Quyết định Kỹ thuật Quan trọng

1. **Tương thích đặc thù với Microsoft SQL Server:**
   - **Unicode tiếng Việt:** Tất cả các cột chứa chuỗi tiếng Việt đều dùng `db.Unicode` / `db.UnicodeText` để ánh xạ sang `NVARCHAR` trong SQL Server (tránh lỗi mất dấu với `VARCHAR`).
   - **Phân trang (`OFFSET ... FETCH`):** SQL Server bắt buộc câu truy vấn có `ORDER BY` khi dùng `LIMIT/OFFSET` và cấm `ORDER BY` trong subquery đếm. Hàm `paginated()` trong `app/utils/responses.py` dùng `query.order_by(None).count()` để đếm tổng và yêu cầu mọi truy vấn truyền vào phải có `.order_by(...)`.
   - **Tránh `GROUP BY` trên cột `NVARCHAR(MAX)`:** SQL Server không cho phép `GROUP BY` trực tiếp trên cột `UnicodeText` (như `Book.description`). Trong `/api/books/statistics`, thống kê sách mượn nhiều nhất được tách thành truy vấn nhóm theo `BorrowRecord.book_id` trước rồi mới truy vấn chi tiết `Book`.
   - **Sao lưu `.bak` ngoài Transaction:** Lệnh T-SQL `BACKUP DATABASE` không được phép chạy bên trong transaction. Endpoint `POST /api/system/backup` lấy `raw_connection()`, bật `driver_conn.autocommit = True` và duyệt hết `cursor.nextset()` để đảm bảo tiến trình ghi đĩa hoàn tất trước khi đóng kết nối.
   - **Linh hoạt khi kiểm thử:** `config.py` xây dựng chuỗi `mssql+pyodbc:///?odbc_connect=...` từ các biến `DB_SERVER`, `DB_NAME`, `DB_DRIVER`, `DB_TRUSTED_CONNECTION`, nhưng cho phép ghi đè qua `DATABASE_URL` (ví dụ `sqlite:///test.db`) để dễ dàng chạy unit test khi chưa bật SQL Server.

2. **Bảo mật, Xác thực & Phân quyền (M20 & M21):**
   - **Kiểm tra quyền thời gian thực từ CSDL:** Decorator `@roles_required` đọc `current_user.role_name` trực tiếp từ bảng `Users` trong mỗi request (thay vì chỉ tin vào claim trong JWT), đồng thời `@jwt.user_lookup_loader` kiểm tra `user.is_active`. Khi Admin khóa tài khoản hoặc hạ quyền, hiệu lực áp dụng ngay lập tức.
   - **JWT `sub` kiểu chuỗi:** `identity=str(user.id)` được dùng khi phát hành token để tương thích chuẩn RFC 7519 / PyJWT mới nhất của `Flask-JWT-Extended >= 4.6`.
   - **Chống dò mật khẩu (Brute-force):** Đăng nhập sai liên tiếp `MAX_LOGIN_ATTEMPTS` lần (mặc định 5) sẽ tự động khóa tài khoản trong `LOCK_MINUTES` phút (mặc định 15) và ghi `AuditLog` sự kiện `ACCOUNT_LOCKED`. Admin có thể mở khóa sớm qua `PATCH /api/users/<id>/status` với `{"unlock": true}`.
   - **Không tự khóa/xóa chính mình:** Các endpoint quản trị người dùng chặn Admin tự xóa, tự vô hiệu hóa hoặc tự hạ vai trò của chính tài khoản đang đăng nhập.

3. **Toàn vẹn dữ liệu nghiệp vụ thư viện (M09 & M10):**
   - **Không sửa trực tiếp `available_quantity`:** `PUT /api/books/<id>` chặn chỉnh tay `available_quantity`; số bản còn trong kho luôn được tính nhất quán từ `quantity - borrowed_quantity` và tự động cập nhật khi lập phiếu mượn, trả sách, báo mất sách (`lost` sẽ giảm tổng `quantity`) hoặc nhập/thanh lý kho (`PATCH /quantity`).
   - **Bảo vệ lịch sử mượn - trả:** Không cho xóa cứng `User` hoặc `Book` đã phát sinh `BorrowRecord` (trả mã `409 Conflict` kèm hướng dẫn chuyển sang vô hiệu hóa tài khoản hoặc đổi trạng thái sách sang `discontinued`). Xóa `Category` hoặc `Author` đang có sách cũng yêu cầu xác nhận tường minh `?force=true` (chỉ gỡ liên kết, không xóa sách).
   - **Đổi tên cột `SearchHistory.search_text`:** Tránh đặt tên cột là `query` vì sẽ đè lên thuộc tính `Model.query` của Flask-SQLAlchemy.
   - **Lưu trữ file an toàn:** File tải lên tại `/api/resources` được kiểm tra phần mở rộng (`ALLOWED_EXTENSIONS`), giới hạn dung lượng (`MAX_UPLOAD_MB`), lưu bằng tên `<uuid4>_<secure_filename>` để chống Path Traversal / ghi đè file, và tự động xóa file vật lý cũ khi cập nhật/xóa bản ghi.

4. **Kiến trúc AI Hybrid (Hoạt động cả khi không có API Key):**
   - **Chế độ mặc định (`local-nlp`):** Tự chuẩn hóa tiếng Việt không dấu, lọc stopword (giữ lại các từ khóa kỹ thuật ngắn như `c`, `r`, `c++`, `c#`, `ai`, `go`, `js`, `ml`, `it`, `ui`, `ux`), bảo toàn cụm từ ghép (`cơ sở dữ liệu`, `lập trình`, `trí tuệ nhân tạo`), mở rộng từ đồng nghĩa Việt - Anh, bóc tách ràng buộc tự nhiên (trình độ `cơ bản`/`nâng cao`, tình trạng `còn sẵn`, năm xuất bản `sau/từ/trước/năm YYYY`), và chấm điểm theo trọng số trường (`title`, `keywords`, `category`, `authors`, `description`, `publisher`).
   - **Chế độ kết hợp (`gemini+local-nlp`):** Khi có `GEMINI_API_KEY` trong `.env`, hệ thống gọi Google Gemini REST API để mở rộng phân tích ngữ nghĩa và diễn đạt câu trả lời Chatbot tự nhiên dựa chặt trên dữ liệu thật của thư viện (chống bịa sách). Nếu mất mạng hoặc hết quota, hệ thống tự động fallback về `local-nlp` không gây lỗi API.

---

## 5. Danh sách các File Đã Tạo & Chỉnh sửa

Tất cả các file dưới đây được tạo mới từ đầu trong workspace `d:\code\ltw`:

| File | Trạng thái | Nội dung / Chức năng chính |
| :--- | :---: | :--- |
| `config.py` | Đã tạo | Cấu hình Flask, JWT, Upload, Nghiệp vụ mượn-trả, Backup, Gemini và hàm `build_odbc_string()` cho SQL Server |
| `requirements.txt` | Đã tạo | Khai báo phụ thuộc: `Flask`, `Flask-SQLAlchemy`, `SQLAlchemy`, `pyodbc`, `Flask-JWT-Extended`, `Flask-Cors`, `python-dotenv`, `requests` |
| `.env.example` | Đã tạo | Mẫu biến môi trường kết nối SQL Server, bảo mật, nghiệp vụ, sao lưu, AI |
| `.gitignore` | Đã tạo | Bỏ qua `.env`, `.venv/`, `uploads/`, `logs/`, `*.db`, `__pycache__/` |
| `app/__init__.py` | Đã tạo | Application Factory `create_app()`, đăng ký 10 blueprints, JWT loaders, HTTP error handlers, security headers, logging |
| `app/extensions.py` | Đã tạo | Khởi tạo singleton `db`, `jwt`, `cors` |
| `app/models.py` | Đã tạo & sửa | Định nghĩa 11 ORM models; đã đổi cột `query` -> `search_text` trong `SearchHistory` |
| `app/utils/__init__.py` | Đã tạo | Đánh dấu package `utils` |
| `app/utils/responses.py` | Đã tạo | Hàm `success()`, `error()`, `get_pagination_args()`, `paginated()` |
| `app/utils/validators.py` | Đã tạo | Hàm đọc JSON/form body, kiểm tra trường bắt buộc, email, chính sách mật khẩu, ép kiểu |
| `app/utils/decorators.py` | Đã tạo | Decorator `@login_required`, `@roles_required`, `@admin_required`, `@staff_required` |
| `app/utils/audit.py` | Đã tạo | Hàm `log_action()` ghi bảng `AuditLogs` kèm IP người gọi |
| `app/services/__init__.py` | Đã tạo | Đánh dấu package `services` |
| `app/services/ai_service.py` | Đã tạo & sửa | Toàn bộ logic AI; đã tinh chỉnh giữ cụm từ đồng nghĩa dài, trọng số từ khóa Gemini và bộ nhận diện intent cho Chatbot |
| `app/routes/__init__.py` | Đã tạo | Đánh dấu package `routes` |
| `app/routes/auth.py` | Đã tạo | API đăng ký, đăng nhập, refresh token, đăng xuất, xem/cập nhật hồ sơ, đổi mật khẩu |
| `app/routes/users.py` | Đã tạo & sửa | API CRUD người dùng, đổi vai trò, khóa/mở khóa, reset mật khẩu (đã làm gọn lời gọi `log_action`) |
| `app/routes/roles.py` | Đã tạo | API xem danh sách vai trò, ma trận phân quyền `PERMISSIONS`, cập nhật mô tả vai trò |
| `app/routes/categories.py` | Đã tạo | API CRUD thể loại sách và liệt kê sách theo thể loại |
| `app/routes/authors.py` | Đã tạo | API CRUD tác giả (hỗ trợ lọc quốc tịch, xem danh sách sách của tác giả) |
| `app/routes/books.py` | Đã tạo & sửa | API CRUD sách, tìm kiếm đa tiêu chí, cập nhật số lượng/tình trạng, thống kê kho (đã sửa truy vấn `top_borrowed` tương thích SQL Server) |
| `app/routes/resources.py` | Đã tạo | API CRUD tài nguyên học tập điện tử (upload file / URL), kiểm soát quyền `public`/`internal`, tải file |
| `app/routes/borrows.py` | Đã tạo | API lập phiếu mượn, trả sách (có xử lý mất sách/cập nhật tình trạng), gia hạn, tra cứu quá hạn |
| `app/routes/ai.py` | Đã tạo & sửa | API endpoints cho 4 tính năng AI & kiểm tra trạng thái engine (đã dọn import `request` lên đầu file) |
| `app/routes/system.py` | Đã tạo & sửa | API healthcheck (đã bổ sung `db.session.rollback()` khi lỗi), dashboard, audit logs, backup `.bak`, export `.json`, cleanup tokens |

---

## 6. Các Bước Tiếp Theo Cần Làm (Next Steps)

Thực hiện lần lượt theo thứ tự ưu tiên sau để hoàn tất 100% sản phẩm bàn giao của đề tài:

### Bước 1: Tạo Entry Point chạy ứng dụng (`run.py`)
- Tạo `d:\code\ltw\run.py` gọi `app = create_app()`, đọc `HOST` (mặc định `0.0.0.0`), `PORT` (mặc định `5000`), `FLASK_DEBUG` từ biến môi trường để khởi chạy server bằng `python run.py`.

### Bước 2: Tạo Script khởi tạo CSDL & nạp dữ liệu mẫu (`init_db.py`)
- Tự động kết nối tới `master` trên SQL Server để tạo database `LibraryDB` nếu chưa tồn tại (`CREATE DATABASE [LibraryDB]`), sau đó gọi `db.create_all()`.
- Seed dữ liệu khởi tạo (idempotent - chạy nhiều lần không bị nhân bản):
  - 3 vai trò: `Admin` (Quản trị viên), `Librarian` (Thủ thư), `Student` (Sinh viên / Bạn đọc).
  - Tài khoản mẫu cho từng vai trò (ví dụ: `admin` / `Admin@123`, `thuthu` / `Librarian@123`, `sinhvien01` / `Student@123`).
  - Bộ dữ liệu mẫu tiếng Việt (6-8 thể loại, ~10 tác giả, ~15-20 đầu sách đa dạng chủ đề CNTT/Toán/Kinh tế/Ngoại ngữ/Kỹ năng có gắn `keywords` & trình độ cơ bản/nâng cao để test rõ hiệu quả AI Smart Search, 4-5 tài nguyên học tập điện tử, và một vài phiếu mượn đang mượn / đã trả / quá hạn).

### Bước 3: Xuất Script SQL chuẩn cho Microsoft SQL Server (`database/`)
- Tạo `database/schema.sql`: Lệnh T-SQL tạo database `LibraryDB`, tạo đủ 11 bảng với kiểu `NVARCHAR`, `IDENTITY(1,1)`, khóa ngoại, ràng buộc `CHECK` và `INDEX`.
- Tạo `database/seed_data.sql`: Lệnh `INSERT` dữ liệu mẫu bằng cú pháp chuỗi Unicode `N'...'` của SQL Server để giảng viên/nhóm có thể chạy trực tiếp trong SQL Server Management Studio (SSMS).

### Bước 4: Tạo Postman Collection kiểm thử API (`postman/`)
- Tạo `postman/Library_Management_API.postman_collection.json` (chuẩn Collection v2.1):
  - Chia thư mục theo đúng 10 nhóm chức năng (`01. Auth`, `02. Users`, `03. Roles`, `04. Categories`, `05. Authors`, `06. Books`, `07. Resources`, `08. Borrows`, `09. AI Features`, `10. System & Backup`).
  - Gắn sẵn Postman Test Script ở request `POST /api/auth/login` để tự động lưu `access_token` và `refresh_token` vào Collection Variables, giúp bấm chạy tuần tự không phải copy-paste token thủ công.

### Bước 5: Viết Automated Tests (`tests/`)
- Tạo bộ test (`pytest` hoặc `unittest`) cấu hình `DATABASE_URL=sqlite:///:memory:` để kiểm thử tự động toàn bộ endpoints: đăng ký/đăng nhập, khóa tài khoản khi sai mật khẩu, phân quyền 3 vai trò (`401`/`403`), CRUD sách/tác giả/thể loại, upload & download tài nguyên, luồng mượn - gia hạn - trả - mất sách, 4 tính năng AI, audit logs và export dữ liệu.

### Bước 6: Viết Tài liệu Bàn giao (`README.md` và `docs/API_DOCUMENTATION.md`)
- `README.md`: Giới thiệu kiến trúc, yêu cầu hệ thống (Python 3.10+, SQL Server, ODBC Driver 17/18), các bước cài đặt `.venv`, cấu hình `.env`, chạy `init_db.py`, chạy `run.py`, danh sách tài khoản mẫu và hướng dẫn import Postman.
- `docs/API_DOCUMENTATION.md`: Bảng đặc tả chi tiết tất cả endpoints (Method, URL, Role yêu cầu, Query Params, Request Body JSON mẫu, Response JSON mẫu và mã lỗi HTTP).

### Bước 7: Cài đặt Môi trường & Kiểm thử Thực tế (Smoke Test)
1. Cài đặt **Python 3.10+** (tích chọn *Add Python to PATH*) và **ODBC Driver 17 (hoặc 18) for SQL Server**.
2. Tạo môi trường ảo & cài thư viện:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
3. Sao chép `.env.example` thành `.env`, chỉnh `DB_SERVER` và `DB_DRIVER` khớp với instance SQL Server trên máy.
4. Chạy `python init_db.py`, chạy bộ test tự động, khởi động `python run.py` và kiểm thử nghiệm thu trên Postman.
